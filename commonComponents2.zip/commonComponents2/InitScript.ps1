param([string]$testType,[string]$environment,[string]$numOfThreads)
Invoke-Command -ScriptBlock{
    $path = Split-Path $script:MyInvocation.MyCommand.Path # 'c:\agent\_work\1\s' 
    #Split-Path $script:MyInvocation.MyCommand.Path
    cd $path
    cd ..
    (Get-Content ".\commonComponents\Global Settings.properties") -replace 'RunConfiguration=Regression', "RunConfiguration=$testType" | Set-Content ".\commonComponents\Global Settings.properties"
    (Get-Content ".\commonComponents\Global Settings.properties") -replace 'Environment=SIT', "Environment=$environment" | Set-Content ".\commonComponents\Global Settings.properties"
    (Get-Content ".\commonComponents\Global Settings.properties") -replace 'NumberOfThreads=4', "NumberOfThreads=$numOfThreads" | Set-Content ".\commonComponents\Global Settings.properties"
    
    #cleanup env
    Stop-Process -Name chrome -Force
    Stop-Process -Name chromedriver -Force 


    #set heap max up front, uncomment the out-file to send to another location 
    java -Xmx512m -cp ".;.\commonComponents\supportlibraries\External_Jars\*" commonComponents.allocator.Allocator #| out-file "\\ddwautolab1\C$\users\tmoautomation1\applicationrepos\outputX.txt"

    #cleanup env
    Stop-Process -Name chrome -Force
    Stop-Process -Name chromedriver -Force 

    #set back to beable to run multiple times without clone again
    (Get-Content ".\commonComponents\Global Settings.properties") -replace "RunConfiguration=$testType", 'RunConfiguration=Regression' | Set-Content ".\commonComponents\Global Settings.properties"
    (Get-Content ".\commonComponents\Global Settings.properties") -replace "Environment=$environment", 'Environment=SIT' | Set-Content ".\commonComponents\Global Settings.properties"
    (Get-Content ".\commonComponents\Global Settings.properties") -replace "NumberOfThreads=$numOfThreads", 'NumberOfThreads=4' | Set-Content ".\commonComponents\Global Settings.properties"
    
	exit 0
}

