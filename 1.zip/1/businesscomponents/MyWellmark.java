package businesscomponents;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.sql.*;
import java.util.*;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import commonComponents.com.cognizant.framework.Status;
import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;

import commonComponents.supportlibraries.ScriptHelper;
import uimap.MyWellmark_OR;

public class MyWellmark extends MyWellmark_CommonFunctions  {

	public MyWellmark(ScriptHelper scriptHelper) {
		super(scriptHelper);		
	}
	public void options_displayed_under_Sort_dropdown_in_Claim_listpage(){
		if (findElement(MyWellmark_OR.myWellmark)==true) {
			performAction(MyWellmark_OR.myWellmark, "SCROLLANDCLICK","" );
		}

		performAction(MyWellmark_OR.claimsLink, "SCROLLANDCLICK","" );

		waitFor(10, MyWellmark_OR.lbl_ClaimsPage);
		//performAction(MyWellmark_OR.claimsLink, "SCROLLANDCLICK","" );
		validateSortingByStatus();
		validateSortingByDate("NewestToOld");
		validateSortingByDate("OldToNewest");
		validateSortingByYouPay("LowToHigh");
		validateSortingByYouPay("HighToLow");

	}
	public void options_displayed_under_Status_dropdown_in_Claim_listpage() throws InterruptedException{
		if (findElement(MyWellmark_OR.myWellmark)==true) {
			performAction(MyWellmark_OR.myWellmark, "SCROLLANDCLICK","" );
		}
		//		Thread.sleep(2000);
		performAction(MyWellmark_OR.claimsLink, "SCROLLANDCLICK","" );
		//performAction(MyWellmark_OR.claimsLink, "SCROLLANDCLICK","" );
		waitFor(10, MyWellmark_OR.lbl_ClaimsPage);
		List<WebElement> statusList = driver.findElements(MyWellmark_OR.statusOption);
		//Thread.sleep(2000);
		for (WebElement webElement : statusList) {
			String status = webElement.getText().trim();
			if(status.equalsIgnoreCase("All")){
				validateStatusAllFilter();
			}
			else if(status.equalsIgnoreCase("Paid")){
				validateStatusFilter("Paid");
			}
			else if(status.equalsIgnoreCase("Pending")){
				validateStatusFilter("Pending");
			}
			else if(status.equalsIgnoreCase("Denied")){
				validateStatusFilter("Denied");
			}
		}
	}
	public void claim_list_details_for_Tier1_members(){
		if (driver.isElementVisible(MyWellmark_OR.myWellmark,5)) {
			performAction(MyWellmark_OR.myWellmark, "SCROLLANDCLICK","" );	
		}

		/*		//Integrating with Fluent wait here
		FluentWait<WebDriver> fluwait = new FluentWait<WebDriver>((WebDriver) driver)
				.withTimeout(30, TimeUnit.SECONDS)
				.pollingEvery(5, TimeUnit.SECONDS)
				.ignoring(NoSuchElementException.class);

		WebElement element = fluwait.until(new Function<WebDriver, WebElement>() {

			@Override
			public WebElement apply(WebDriver driver) {
				WebElement element = driver.findElement(By.xpath("(//div[@class[contains(.,'latest-claims-container')]]//following-sibling::*)[1]"));
				if (driver.) {

				}
				return null;
			}

		});*/

		driver.manage().timeouts().implicitlyWait(10000, TimeUnit.SECONDS);

		performAction(MyWellmark_OR.claimsLink, "SCROLLANDCLICK","" );
		driverUtil.waitFor(2000);
		//selectValueFromDropdownForGivenId(MyWellmark_OR.statusDrp,2) ;
		selectValueFromDropdownForGivenText(MyWellmark_OR.statusDrp, "Paid");
		driverUtil.waitFor(2000);
		List<WebElement> paidClaims = driver.findElements(MyWellmark_OR.claims);
		for (WebElement webElement : paidClaims) {
			String date = webElement.findElement(MyWellmark_OR.paidDate).getText();
			if (!date.equals(null)) {
				report.updateTestLog("Paid - Service Date", "Service Date is displayed", Status.PASS);
			} else {
				report.updateTestLog("Paid - Service Date", "Service Date not displayed", Status.FAIL);
			}
			String patientName = webElement.findElement(MyWellmark_OR.patientName).getText();
			if (!patientName.equals(null)) {
				report.updateTestLog("Paid - Patient Name", "Patient Name is displayed", Status.PASS);
			} else {
				report.updateTestLog("Paid - Patient Name", "Patient Name not displayed", Status.FAIL);
			}
			String youPay = webElement.findElement(MyWellmark_OR.youPay).getText();
			if (!youPay.equals(null)) {
				report.updateTestLog("Paid - You Pay", "You Pay is displayed", Status.PASS);
			} else {
				report.updateTestLog("Paid - You Pay", "You Pay not displayed", Status.FAIL);
			}
			String status = webElement.findElement(MyWellmark_OR.status).getText();
			if (!status.equals(null)) {
				report.updateTestLog("Paid - Claim Status", "Claim Status is displayed", Status.PASS);
			} else {
				report.updateTestLog("Paid - Claim Status", "Claim Status not displayed", Status.FAIL);
			}
		}
		selectValueFromDropdownForGivenId(MyWellmark_OR.statusDrp,1) ;
		driverUtil.waitFor(2000);
		List<WebElement> pendingClaims = driver.findElements(MyWellmark_OR.claims);
		for (WebElement webElement : pendingClaims) {
			String date = webElement.findElement(MyWellmark_OR.paidDate).getText();
			if (!date.equals(null)) {
				report.updateTestLog("Paid - Service Date", "Service Date is displayed", Status.PASS);
			} else {
				report.updateTestLog("Paid - Service Date", "Service Date not displayed", Status.FAIL);
			}
			String patientName = webElement.findElement(MyWellmark_OR.patientName).getText();
			if (!patientName.equals(null)) {
				report.updateTestLog("Paid - Patient Name", "Patient Name is displayed", Status.PASS);
			} else {
				report.updateTestLog("Paid - Patient Name", "Patient Name not displayed", Status.FAIL);
			}
			/*String youPay = webElement.findElement(MyWellmark_OR.youPay).getText();
			if (!youPay.equals(null)) {
				report.updateTestLog("Paid - You Pay", "You Pay is displayed", Status.FAIL);
			} else {
				report.updateTestLog("Paid - You Pay", "You Pay not displayed", Status.PASS);
			}*/
			String status = webElement.findElement(MyWellmark_OR.status).getText();
			if (!status.equals(null)) {
				report.updateTestLog("Paid - Claim Status", "Claim Status is displayed", Status.PASS);
			} else {
				report.updateTestLog("Paid - Claim Status", "Claim Status not displayed", Status.FAIL);
			}
		}
	}
	public void message_displayed_in_model_window_for_the__denied_claim(){
		performAction(MyWellmark_OR.claimsLink, "SCROLLANDCLICK","" );
		waitFor(10, MyWellmark_OR.lbl_ClaimsPage);
		selectValueFromDropdownForGivenTextContains(MyWellmark_OR.statusDrp,"Denied");
		driverUtil.waitFor(1000);
		performAction(MyWellmark_OR.deniedClaim, "SCROLLANDCLICK","" );
		if(driver.isElementVisible(MyWellmark_OR.deniedClaimReason, 150)!=false) {
			report.updateTestLog("Denied Claim", "Denied Claim Reason is displyed successfully", Status.PASS);
		}
		else{
			report.updateTestLog("Denied Claim", "Denied Claim Reason is not displyed successfully", Status.FAIL);
		}
	}
	public void claim_line_details_displayed_in_claim_details_page_MyWellmark(){
		performAction(MyWellmark_OR.claimsLink, "SCROLLANDCLICK","" );
		performAction(MyWellmark_OR.claimDetailsLink, "SCROLLANDCLICK","" );
		performAction(MyWellmark_OR.expandCostDetails, "SCROLLANDCLICK","" );
		String number = driver.findElement(MyWellmark_OR.claimNumber).getText();
		String claimNumber = number.substring(6);
		String amountBilled = driver.findElement(MyWellmark_OR.amountBilled).getText();
		String wellmarkDiscount = driver.findElement(MyWellmark_OR.wellmarkDiscount).getText();
		String wellmarkPaid = driver.findElement(MyWellmark_OR.wellmarkPaid).getText();
		String youPayClaim = driver.findElement(MyWellmark_OR.youPayClaim).getText();
		String deductible = driver.findElement(MyWellmark_OR.deductible).getText();
		String Copay = driver.findElement(MyWellmark_OR.Copay).getText();
		String Coinsurance = driver.findElement(MyWellmark_OR.Coinsurance).getText();
		String AmountNotCovered = driver.findElement(MyWellmark_OR.AmountNotCovered).getText();
		PrintWriter writer = null;
		try {
			writer = new PrintWriter("C:\\ClaimNumber.txt", "UTF-8");
		} catch (FileNotFoundException | UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		writer.println(claimNumber);
		writer.println(amountBilled.replace("$", ""));
		writer.println(wellmarkDiscount.replace("$", ""));
		writer.println(wellmarkPaid.replace("$", ""));
		writer.println(youPayClaim.replace("$", ""));
		writer.println(deductible.replace("$", ""));
		writer.println(Copay.replace("$", ""));
		writer.println(Coinsurance.replace("$", ""));
		writer.println(AmountNotCovered.replace("$", ""));
		writer.close();
	}
	public void claim_line_details_displayed_in_claim_details_page_CSI() throws ClassNotFoundException, SQLException, InterruptedException{
		String line = null;
		FileReader fileReader;
		ArrayList<String> claimDetailsArr = new ArrayList<String>();
		try {
			fileReader = new FileReader("C:\\ClaimNumber.txt");
			BufferedReader bufferedReader = 
					new BufferedReader(fileReader);
			//claimNumber = bufferedReader.readLine();
			while((line = bufferedReader.readLine()) != null) {
				claimDetailsArr.add(line);
			}  
			bufferedReader.close(); 
		} catch (IOException e) {
			e.printStackTrace();
		}
		String subscriberId = null;
		String query = "Select A.CLCL_ID,C.SBSB_ID from CMC_CLCL_CLAIM as A join CMC_MEME_MEMBER as B on A.MEME_CK=B.MEME_CK join CMC_SBSB_SUBSC as C on B.SBSB_CK=C.SBSB_CK where A.CLCL_ID='"+claimDetailsArr.get(0)+"'";
		ResultSet rs = executeQuery(query);
		try {
			while(rs.next()) {
				subscriberId = rs.getString("SBSB_ID").trim();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}      
		performAction(MyWellmark_OR.lbl_CheckClaim_CSI, "SCROLLANDCLICK", "");
		performAction(MyWellmark_OR.memberId_CSI, "sendkeys",subscriberId );
		performAction(MyWellmark_OR.claimNumber_CSI, "sendkeys",claimDetailsArr.get(0) );
		performAction(MyWellmark_OR.buttonSearch_CSI, "SCROLLANDCLICK","" );
		waitFor(10, MyWellmark_OR.obj_ResultsPanel);
		performAction(MyWellmark_OR.claimLink_CSI, "SCROLLANDCLICK","" );
		waitFor(10, MyWellmark_OR.lbl_ClaimSummary);
		String amountCharged = driver.findElement(MyWellmark_OR.lbl_amtCharged_CSI).getText();
		String amountPaid = driver.findElement(MyWellmark_OR.lbl_amtPaid_CSI).getText();
		String deductible = driver.findElement(MyWellmark_OR.lbl_Ded_CSI).getText();
		String coPayment = driver.findElement(MyWellmark_OR.lbl_Copay_CSI).getText();
		String coInsurance = driver.findElement(MyWellmark_OR.lbl_Coinsurance_CSI).getText();
		String memberResponsibility = driver.findElement(MyWellmark_OR.lbl_memResp_CSI).getText();
		String networkSavings = driver.findElement(MyWellmark_OR.lbl_nwrkSavings).getText();
		if(amountCharged.equals(claimDetailsArr.get(1)) && networkSavings.equals(claimDetailsArr.get(2)) 
				&& amountPaid.equals(claimDetailsArr.get(3)) && memberResponsibility.equals(claimDetailsArr.get(4)) 
				&& deductible.equals(claimDetailsArr.get(5)) && coPayment.equals(claimDetailsArr.get(6))
				&& coInsurance.equals(claimDetailsArr.get(7))){
			report.updateTestLog("Claim Details CSI", "Claim Details are matched with CSI", Status.PASS);
		}
		else{
			report.updateTestLog("Claim Details CSI", "Claim Details are not matched with CSI", Status.FAIL);
		}
	}
	public void order_Dental_ID_Card_PPO() throws ClassNotFoundException, SQLException{
		//String subsId = findSubscriber();
		/*String subsId = "W00075544";
		extractdata(subsId);
		selectType();
		registerMember();
		registerMemberStep2(subsId);*/
		/*int welcome_msg = driver.findElements(MyWellmark_OR.lbl_Welcomemsg).size();
		if (welcome_msg==1) {
			performAction(MyWellmark_OR.link_avoidShowingTips, "SCROLLANDCLICK", "");
		}*/


		performAction(MyWellmark_OR.myPlansLink, "SCROLLANDCLICK","" );
		performAction(MyWellmark_OR.viewIdCard, "SCROLLANDCLICK","" );
		if(driver.isElementVisible(MyWellmark_OR.dentalCard, 150)!=false &&  driver.isElementVisible(MyWellmark_OR.dental_IdCardFrontSide, 150)!=false && driver.isElementVisible(MyWellmark_OR.dental_IdCardBackSide, 150)!=false) {
			report.updateTestLog("View Id Card", "Id Card Front and Back are displayed", Status.PASS);
		}
		else{
			report.updateTestLog("View Id Card", "Id Card Front and Back are not displayed", Status.FAIL);
		}
		if(driver.isElementVisible(MyWellmark_OR.dentalOrderButton, 150)==false) {
			report.updateTestLog("Order Button", "Order Button are not displayed", Status.PASS);
		}
		else{
			report.updateTestLog("Order Button", "Order Button are displayed", Status.FAIL);
		}
		//performAction(MyWellmark_OR.orderButton, "SCROLLANDCLICK","" );
	}
	public void order_Medical_ID_Card_Future_effective_member() throws ClassNotFoundException, SQLException{
		//String subsId = findSubscriber();

		//memRegistration_withDB();
		/*int welcome_msg = driver.findElements(MyWellmark_OR.lbl_Welcomemsg).size();
		if (welcome_msg==1) {
			performAction(MyWellmark_OR.link_avoidShowingTips, "SCROLLANDCLICK", "");
		}*/



		/*extractdata(subsId);
		selectType();
		registerMember();
		registerMemberStep2(subsId);*/
		performAction(MyWellmark_OR.myPlansLink, "SCROLLANDCLICK","" );
		performAction(MyWellmark_OR.viewIdCard, "SCROLLANDCLICK","" );
		if(driver.isElementVisible(MyWellmark_OR.medicalCard, 150)!=false ||  driver.isElementVisible(MyWellmark_OR.dental_IdCardFrontSide, 150)!=false || driver.isElementVisible(MyWellmark_OR.dental_IdCardBackSide, 150)!=false) {
			report.updateTestLog("View Id Card", "Id Card Front and Back are displayed", Status.PASS);
		}
		else{
			report.updateTestLog("View Id Card", "Id Card Front and Back are not displayed", Status.FAIL);
		}
		if(driver.isElementVisible(MyWellmark_OR.medicalOrderButton, 150)==false) {
			report.updateTestLog("Order Button", "Order Button is not displayed for Medical", Status.FAIL);
		}
		else{
			report.updateTestLog("Order Button", "Order Button is displayed for Medical", Status.PASS);
		}
		//performAction(MyWellmark_OR.orderButton, "SCROLLANDCLICK","" );
	}
	public void medical_ID_card_for_Cancelled_Member() throws ClassNotFoundException, SQLException{
		//String subsId = findSubscriber();
		/*String subsId = "WS0212747";
		extractdata(subsId);
		selectType();
		registerMember();
		registerMemberStep2(subsId);*/
		/*int welcome_msg = driver.findElements(MyWellmark_OR.lbl_Welcomemsg).size();
		if (welcome_msg==1) {
			performAction(MyWellmark_OR.link_avoidShowingTips, "SCROLLANDCLICK", "");
		}*/


		performAction(MyWellmark_OR.myPlansLink, "SCROLLANDCLICK","" );
		//performAction(MyWellmark_OR.viewIdCard, "SCROLLANDCLICK","" );
		if(driver.isElementVisible(MyWellmark_OR.viewIdCard, 150)) {
			report.updateTestLog("View Id Card", "View Id Card are displayed", Status.PASS);
		}
		else{
			report.updateTestLog("View Id Card", "View Id Card are not displayed", Status.FAIL);
		}
	}
	public void dental_ID_card_Layout_for_IA_PPO_Plan() throws ClassNotFoundException, SQLException{
		//String subsId = findSubscriber();
		/*String subsId = "W00431604";
		extractdata(subsId);
		selectType();
		registerMember();
		registerMemberStep2(subsId);*/
		//enterCredentials();
		int welcome_msg = driver.findElements(MyWellmark_OR.lbl_Welcomemsg).size();
		if (welcome_msg==1) {
			performAction(MyWellmark_OR.link_avoidShowingTips, "SCROLLANDCLICK", "");
		}


		performAction(MyWellmark_OR.myPlansLink, "SCROLLANDCLICK","" );
		driver.waitTillPageLoaded();
		driver.waitTillPageLoaded();
		performAction(MyWellmark_OR.viewIdCard, "SCROLLANDCLICK","" );
		if(driver.isElementVisible(MyWellmark_OR.dentalCard, 150)!=false &&  driver.isElementVisible(MyWellmark_OR.dental_IdCardFrontSide, 150)!=false && driver.isElementVisible(MyWellmark_OR.dental_IdCardBackSide, 150)!=false) {
			report.updateTestLog("View Id Card", "Id Card Front and Back are displayed", Status.PASS);
		}
		else{
			report.updateTestLog("View Id Card", "Id Card Front and Back are not displayed", Status.FAIL);
		}
		dentalIdCard_FrontSideValidation();
		dentalIdCard_BackSideValidation();
		driver.manage().deleteAllCookies();
		invokeEVBI();
		validateEVBI_MemberDetails();
	}
	public void medical_ID_card_Layout_for_Value_Health() throws ClassNotFoundException, SQLException{
		//String subsId = findSubscriber();
		String subsId = "W00431604";
		extractdata(subsId);
		selectType();
		registerMember(subsId);
		registerMemberStep2(subsId);
		enterCredentials();
		performAction(MyWellmark_OR.myPlansLink, "SCROLLANDCLICK","" );
		driver.waitTillPageLoaded();
		driver.waitTillPageLoaded();
		performAction(MyWellmark_OR.viewIdCard, "SCROLLANDCLICK","" );
		if(driver.isElementVisible(MyWellmark_OR.medicalCard, 150)!=false &&  driver.isElementVisible(MyWellmark_OR.dental_IdCardFrontSide, 150)!=false && driver.isElementVisible(MyWellmark_OR.dental_IdCardBackSide, 150)!=false) {
			report.updateTestLog("View Id Card", "Id Card Front and Back are displayed", Status.PASS);
		}
		else{
			report.updateTestLog("View Id Card", "Id Card Front and Back are not displayed", Status.FAIL);
		}

	}
	public void search_for_a_Provider_Widget_for_member_with_dental_only_plan(){
		checkMyplanLink();
		validateDentistIcon();
		validateDentistUrl();
	}
	public void search_for_a_Provider_Widget_for_member_with_all_benefits(){
		checkMyplanLink();
		validateDoctorIcon();
		validateDoctorUrl();
		validateFaciltyIcon();
		validateFaciltyUrl();
		validatePharmacyIcon();
		validatePharmacyUrl();
		validateDentistIcon();
		validateDentistUrl();
	}
	public void claim_list_details_for_Tier_2_members(){
		checkClaimLink();
		checkClaimDetails();		
	}
	public void homepage_Hyvee_narrow_network() throws ClassNotFoundException, SQLException{
		/*String subsId = findSubscriber();
		extractdata(subsId);
		selectType();
		registerMember();
		registerMemberStep2(subsId);*/
		/*int welcome_msg = driver.findElements(MyWellmark_OR.lbl_Welcomemsg).size();
		if (welcome_msg==1) {
			performAction(MyWellmark_OR.link_avoidShowingTips, "SCROLLANDCLICK", "");
		}*/

		checkHighPerformanceLink();
	}
	public void homepage_Future_Effective_Policy() throws ClassNotFoundException, SQLException{
		//String subsId = findSubscriber();
		/*String subsId = "W00172723";
		extractdata(subsId);
		selectType();
		registerMember();
		registerMemberStep2(subsId);*/

		//emailVerify_PreChecks();
		validateFutureEffMsg();

	}
	public void homepage_UIGradCare_link() throws ClassNotFoundException, SQLException{
		/*extractdata();
		selectType();
		registerMember();*/

		//emailVerify_PreChecks();
		CheckUiGradeCare();
	}
	/*****Praveen******/
	public void change_username()
	{
		String userName = dataTable.getData("General_Data", "Username");
		String s1=RandomStringUtils.randomAlphanumeric(3);
		String newuser=userName.concat(s1.toUpperCase());
		dataTable.putData("General_Data", "Username", newuser);
		Changetheusername();
		logoutmywellmark();		 
		invokeApplication();
		enterCredentials();		 
		dataTable.putData("General_Data", "Username", userName);
		Changetheusername(); 
	}
	public void error_message_for_invalid_username()
	{
		Error_message_for_invalid();		 
	}
	public void change_security_question()
	{
		change_security_ques();

	}
	public void error_message_for_invalid_securityques()
	{
		Error_message_securityques();
	}
	public void change_password()
	{
		String oldpassword = dataTable.getData("General_Data", "Password");
		//String s1=RandomStringUtils.randomAlphanumeric(8);
		//String newpwd=s1.toUpperCase();
		String newpwd = dataTable.getData("General_Data", "Password") + "007";
		dataTable.putData("General_Data", "newpassword", newpwd);
		Changethepassword();
		logoutmywellmark();		 
		invokeApplication();
		enterCredentials();		 
		dataTable.putData("General_Data", "newpassword", oldpassword);
		Changethepassword(); 
	}
	public void error_message_for_invalidpwd()
	{
		error_message_invalidpwd(); 
	}
	public void medical_idcard_validation()
	{
		idcardvalidationcheckallmembers();
		idcardfrontlayout();
		idcardbacklayout();
		driver.manage().deleteAllCookies();
		invokeEVBI();
		validateEVBI_MemberDetails();		 
	}
	public void medical_idcard_validation_synergy()
	{
		idcardvalidationcheckallmembers();
		idcardfrontlayout_synergy();
		idcardbacklayout();
		driver.manage().deleteAllCookies();
		invokeEVBI();
		validateEVBI_MemberDetails();	


	}


	/*** Aravinth - START 
	 * @throws SQLException 
	 * @throws ClassNotFoundException ***/

	/*public void benefits_View_Contract_Accumulations_Non_Policy_holder() throws ClassNotFoundException, SQLException{
		//String subsId = findSubscriber();
		String subsId = "WS0212747"; //183AD4563SPOUSE00INT

		extractdata(subsId);
		selectType();
		registerMember();
		registerMemberStep2();



		//Navigate to Coverage page
		gotoCoverageLink();
		//Validate ttl members under Ded & Max_Medical
		validate_ttlmem_Med_Ded_Max();
		//Default In network toggle button
		validate_default_InNetwork_toggle();
		fieldChecks_DedMax();
		//Validate Deductible details link
		validate_DedDetails_Link();
		//Validate OOP Maximum Link
		validate_OOPMax_Link();

		cookieDelete();

		//Login to EVBI URL
		invokeEVBI();

		//Validate Policy/Non Policy member details
		searchPolicy_NonPolicyDetails();

		//No Deductibel Check
		validate_NoDedCheck();

		//No OOP Check
		validate_NoOOPCheck();



	}*/

	public void benefits_View_Medical_Coinsurance() throws ClassNotFoundException, SQLException, Exception{

		//String subsId = findSubscriber();
		/*String subsId = "W00250722"; //183AD4563SPOUSE00INT

		extractdata(subsId);
		selectType();
		registerMember();
		registerMemberStep2();*/


		/*System.setProperty("webdriver.chrome.driver", "H:\\C85\\C85_Project\\SourceCode\\libraries\\chromedriver.exe");
		WebDriver hellodriver = new ChromeDriver();

		hellodriver.manage().window().maximize();
		hellodriver.get("file:///C:/Users/CN06299/Desktop/ara.html");

		//Treeset removes duplicates
				TreeSet<String> ServiceTitles_EVBI_test = new TreeSet<>();
				//Get total values_EVBI
				int ttl_titles_test = hellodriver.findElements(By.xpath("//table//tr//td[1]")).size();
				for (int i = 1; i <= ttl_titles_test; i++) {
					String txt_Titles_test = hellodriver.findElement(By.xpath("(//table//tr//td[1])[" + i + "]")).getText().trim();
					ServiceTitles_EVBI_test.add(txt_Titles_test);
				}


				//table//tr//td[1][contains(.,'Coinsurance - Non-PPO Providers')]/following-sibling::td[contains(.,'Out-of-Network')]/following-sibling::td


				Multimap<String, String> myMultimap_percent_test = ArrayListMultimap.create();
				Collection<String> Coinsurance_percent_map_test;



		//Get total elements one-by-one
				for (String string : ServiceTitles_EVBI_test) {

					List<WebElement> In_Out_ele = hellodriver.findElements(By.xpath("//table//tr//td[1][contains(.,'" + string + "')]/following-sibling::td[2]"));
					for (WebElement webElement : In_Out_ele) {

						if (webElement.getText().trim().equals("In-Network")) {
							String coin_percent = hellodriver.findElement(By.xpath("//table//tr//td[1][contains(.,'" + string + "')]/following-sibling::td[contains(.,'In-Network')]/following-sibling::td")).getText().trim();
							myMultimap_percent_test.put(string, coin_percent);
							//Checks for Out-of-Network else put N/A
							int search_OON = hellodriver.findElements(By.xpath("//table//tr//td[1][contains(.,'" + string + "')]/following-sibling::td[contains(.,'Out-of-Network')]/following-sibling::td")).size();
							if (search_OON==0) {
								myMultimap_percent_test.put(string, "n/a");
							}
						}else if(webElement.getText().trim().equals("Out-of-Network")){
							//Checks for In-Network else put N/A
							int search_INN = hellodriver.findElements(By.xpath("//table//tr//td[1][contains(.,'" + string + "')]/following-sibling::td[contains(.,'In-Network')]/following-sibling::td")).size();
							if (search_INN==0) {
								myMultimap_percent_test.put(string, "n/a");
							}
							String coin_percent = hellodriver.findElement(By.xpath("//table//tr//td[1][contains(.,'" + string + "')]/following-sibling::td[contains(.,'Out-of-Network')]/following-sibling::td")).getText().trim();
							myMultimap_percent_test.put(string, coin_percent);
						}
					}


				}


		System.out.println(myMultimap_percent_test.get("Coinsurance - Non-PPO Providers"));
		System.out.println(myMultimap_percent_test.get("Coinsurance - PPO Providers"));*/










		//Get Active Members from EVBI
		String subsId = dataTable.getData("General_Data", "SSN/SID");
		
		//Get Active member details by logging in EVBI - Get and Put in datatable sheet
		getActiveContracts(subsId);
		
		//Login to EVBI URL
		invokeEVBI();


		//String memberIdText=dataTable.getData("General_Data", "Wellmark_Id").trim();
		String memberName=dataTable.getData("General_Data", "PolicyHolder_Name").trim();
		String[] memName_PolicyHolder = memberName.split(";");
		String[] memberName_Split = memName_PolicyHolder[0].split(" ");

		performAction(MyWellmark_OR.membreno,"SENDKEYS",subsId);
		try {
			performAction(MyWellmark_OR.searchbutton,"click","");
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			driver.navigate().refresh();
			waitFor(20, MyWellmark_OR.lbl_ActiveMem_Header);
		}
		waitFor(20, MyWellmark_OR.lbl_ActiveMem_Header);


		//Clicks on appropriate member w.r.to the member given in datatable
		try {
			performAction(By.xpath("//table[@rules='all' and .//td[contains(.,'Active')]]//following-sibling::tbody//tr//td[1]//a[contains(.,'" + memberName_Split[0].trim() + "')][contains(.,'" + memberName_Split[1].trim() + "')]"), "SCROLLANDCLICK", "");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			driver.navigate().refresh();
			waitFor(30, MyWellmark_OR.lbl_ViewEligBen);
		}
		waitFor(30, MyWellmark_OR.lbl_ViewEligBen);

		//Navigate to element
		performAction(MyWellmark_OR.lbl_Coin_NonInsProvider, "SCROLLDOWN", "");


		//Treeset removes duplicates
		TreeSet<String> ServiceTitles_EVBI_1 = new TreeSet<>();
		//Get total values_EVBI
		//int ttl_titles_1 = driver.findElements(MyWellmark_OR.lbl_EVBI_ttlServiceTitles).size();
		int ttl_titles_1 = driver.findElements(By.xpath("//tbody[./tr/th[contains(.,'Percent')]]//tr//td[1]")).size();
		for (int i = 1; i <= ttl_titles_1; i++) {
			String txt_Titles_1 = driver.findElement(By.xpath("(//tbody[./tr/th[contains(.,'Percent')]]//tr//td[1])[" + i + "]")).getText().trim();
			if (!txt_Titles_1.equals("")) {
				ServiceTitles_EVBI_1.add(txt_Titles_1);
			}
		}

		//Creating a Multimap reference object for EVBO 
		Multimap<String, String> myMultimap_percent = ArrayListMultimap.create();

		//Get total elements one-by-one
		for (String string : ServiceTitles_EVBI_1) {

			List<WebElement> In_Out_ele = driver.findElements(By.xpath("//tbody[./tr/th[contains(.,'Percent')]]//tr//td[1][contains(.,'" + string + "')]/following-sibling::td[2]"));
			for (WebElement webElement : In_Out_ele) {

				if (webElement.getText().trim().equals("In-Network")) {
					String coin_percent = driver.findElement(By.xpath("(//tbody[./tr/th[contains(.,'Percent')]]//tr//td[1][contains(.,'" + string + "')]/following-sibling::td[contains(.,'In-Network')]/following-sibling::td)")).getText().trim();
					myMultimap_percent.put(string, coin_percent.replace(" %", "%"));
					//Checks for Out-of-Network else put N/A
					int search_OON = driver.findElements(By.xpath("(//tbody[./tr/th[contains(.,'Percent')]]//tr//td[1][contains(.,'" + string + "')]/following-sibling::td[contains(.,'Out-of-Network')]/following-sibling::td)")).size();
					if (search_OON==0) {
						myMultimap_percent.put(string, "n/a");
					}
				}else if(webElement.getText().trim().equals("Out-of-Network")){
					//Checks for In-Network else put N/A
					int search_INN = driver.findElements(By.xpath("(//tbody[./tr/th[contains(.,'Percent')]]//tr//td[1][contains(.,'" + string + "')]/following-sibling::td[contains(.,'In-Network')]/following-sibling::td)")).size();
					if (search_INN==0) {
						myMultimap_percent.put(string, "n/a");
					}
					String coin_percent = driver.findElement(By.xpath("(//tbody[./tr/th[contains(.,'Percent')]]//tr//td[1][contains(.,'" + string + "')]/following-sibling::td[contains(.,'Out-of-Network')]/following-sibling::td)")).getText().trim();
					myMultimap_percent.put(string, coin_percent.replace(" %", "%"));
				}
			}


		}

		//Invoking Application URL
		driver.manage().deleteAllCookies();
		invokeApplication();
		enterCredentials();

		//Navigate to Coverage page
		gotoCoverageLink();

		//Clicks on Copay & Coinsurance
		//Selects Medical tab if not
		if (findElement(MyWellmark_OR.link_Med_Cov)==false) {
			performAction(MyWellmark_OR.link_Med_Cov, "SCROLLANDCLICK", "");
		}
		//Clicks on Copays & Coinsurance link and navigate to the page
		if (findElement(MyWellmark_OR.link_Med_Copay_CoInsurance)==true) {
			performAction(MyWellmark_OR.link_Med_Copay_CoInsurance, "SCROLLANDCLICK", "");
			waitFor(10, MyWellmark_OR.lbl_CopaysPage);
			report.updateTestLog("Copays&Coinsurance_Medical Page", "Navigated to Copays and Coinsurance page successful", Status.PASS);
		}
		//Choose the Benefit period
		selectValueFromDropdownForGivenTextContains(MyWellmark_OR.drp_Med_BenPeriod, "Current");
		waitFor(20, MyWellmark_OR.lbl_Med_CoIns_Ser_Title);
		report.updateTestLog("Benefit Period", "Current Date is choosen over the Benefit period dropdown", Status.PASS);

		//Navigating to CoInsurance Section
		performAction(MyWellmark_OR.lbl_Med_CoIns_Ser_Title, "SCROLLDOWN", "");
		driverUtil.waitFor(2000);

		//Checks for the service title under CoInsurance section
		int serviceTitle_Coinsurance = 0;
		try {
			serviceTitle_Coinsurance = driver.findElements(MyWellmark_OR.lbl_Med_CoIns_Ser_Title).size();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (serviceTitle_Coinsurance>0) {
			for (WebElement element : driver.findElements(MyWellmark_OR.lbl_Med_CoIns_Ser_Title)) {
				report.updateTestLog("CoInsurance Service Title_" + element.getText().split("\\n")[0].trim(), 
						"CoInsurance Service title is displayed", Status.PASS);
			}
		}else{
			report.updateTestLog("CoInsurance Service Title", "No CoInsurance Service Title is displayed as expected", Status.FAIL);
		}

		//Checks for CoInsurance Details link and access it
		if (findElement(MyWellmark_OR.link_Med_ViewCoIns_Details)==true) {
			performAction(MyWellmark_OR.link_Med_ViewCoIns_Details, "SCROLLDOWN", "");
			performAction(MyWellmark_OR.link_Med_ViewCoIns_Details, "SCROLLANDCLICK", "");
			if (findElement(MyWellmark_OR.modal_CoIns_Details)==true) {
				report.updateTestLog("CoInsurance Details Modal", "CoInsurance Details Modal gets displayed as expected", Status.PASS);
			}
			performAction(MyWellmark_OR.modal_CoIns_Details_Close, "SCROLLANDCLICK", "");
			waitFor(10, MyWellmark_OR.link_Med_ViewCoIns_Details);
		} else {
			report.updateTestLog("CoInsurance Details Modal", "CoInsurance Details Modal not displayed", Status.FAIL);
		}

		//Getting Service title names
		String InNtwrk, OutNtwrk, title_name = null;

		//Creating Multimap reference for Application URL
		Multimap<String, String> myMultimap_Coinsurance = ArrayListMultimap.create();

		int CoIn_Serv_Title_Names = driver.findElements(MyWellmark_OR.lbl_Med_CoIns_Ser_Title).size();
		int CoIn_Serv_Title_Names_EVBI = ServiceTitles_EVBI_1.size();

		if (CoIn_Serv_Title_Names == CoIn_Serv_Title_Names_EVBI) {
			report.updateTestLog("Service Title Names", "Total number of Service title names gets matched with EVBI", Status.PASS);

			//Checking for the name match
			int g = 0;
			for (String string : ServiceTitles_EVBI_1) {
				title_name = driver.findElements(MyWellmark_OR.lbl_Med_CoIns_Ser_Title).get(g).getText().split("\\n")[0].trim();
				if (ServiceTitles_EVBI_1.contains(title_name)) {
					report.updateTestLog("Service Title Name_" + string, "Service title names gets matched with EVBI", Status.PASS);
				}else{
					report.updateTestLog("Service Title Name_" + string, "Service title names gets mismatched with EVBI", Status.FAIL);
				}
				g++;
			}

		} else {
			report.updateTestLog("Service Title Names", "Total number of Service title names gets mismatched with EVBI", Status.FAIL);
		}

		//Storing all the Multimap values in Collections
		Collection<String> Coinsurance_percent_map_EVBI;
		Collection<String> Coinsurancemap_UI;

		//Iterating for comparison
		for (int h = 0; h < CoIn_Serv_Title_Names; h++) {
			title_name = driver.findElements(MyWellmark_OR.lbl_Med_CoIns_Ser_Title).get(h).getText().split("\\n")[0].trim();

			Coinsurance_percent_map_EVBI = myMultimap_percent.get(title_name);
			InNtwrk = driver.findElement(By.xpath("(//div[@class='panel panel-coinsurance']//tr[contains(.,'" + title_name + "')]//td/span)[1]")).getText().trim();
			OutNtwrk = driver.findElement(By.xpath("(//div[@class='panel panel-coinsurance']//tr[contains(.,'" + title_name + "')]//td/span)[2]")).getText().trim();

			myMultimap_Coinsurance.put(title_name, InNtwrk);
			myMultimap_Coinsurance.put(title_name, OutNtwrk);

			Coinsurancemap_UI = myMultimap_Coinsurance.get(title_name);

			if (Coinsurance_percent_map_EVBI.equals(Coinsurancemap_UI)) {
				report.updateTestLog("Details for_" + title_name, title_name + " details and their percentage gets matached with EVBI", Status.PASS);
			} else {
				report.updateTestLog("Details for_" + title_name, title_name + " details and their percentage gets mismatached with EVBI", Status.FAIL);
			}



		}

	}



	/*public void related_Info_widget_Pharmacy_Benefits(){

		switchToPharmacy_CoveragePage();
		validate_DedDetails_Link();
		relatedInfo_GetNames();
		relatedInfo_apprNameList();
		//Verify All
		verifyall_RelatedInfoLinks();

	}*/


	/*** Aravinth - END ***/

}