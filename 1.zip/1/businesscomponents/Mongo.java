package businesscomponents;

import com.mongodb.BasicDBObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.client.MongoDatabase;
import commonComponents.supportlibraries.ScriptHelper;
import net.sourceforge.htmlunit.corejs.javascript.regexp.SubString;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Properties;

import org.bson.Document;

public class Mongo extends MyWellmark_CommonFunctions {
	// Initializing the variable 
	MongoClient mongoClient = null;
	MongoDatabase database = null;

	public Mongo(ScriptHelper scriptHelper) 
	{
		super(scriptHelper);
	}

	boolean status;
	String Subscriber_ID;
	String webSecurity_Userid;
	String subscriberID_facets;
	ArrayList<String> listnm=new ArrayList<String>();
	ArrayList<String> listwebSecurity=new ArrayList<String>();
	String subscriberID_websecurity;
	String[] arrayDB=new String[2];
	int i=0;
	Object subscriberID_mongo = null;
	public String[] validateSubscriberID_FacetsandMongoDB(String curTCName_Mongo) throws ClassNotFoundException, SQLException, NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, IOException{

		/** By Aravinth - START ***/

		// Creating a mongo client
		String mongoUsername = getmongoData(curTCName_Mongo, "General_Data", "MongoUserName");
		String mongoPwd = getmongoData(curTCName_Mongo, "General_Data", "MongoPassowrd");
		String mongoServer = getmongoData(curTCName_Mongo, "General_Data", "MongoServerName");
		String mongoName = getmongoData(curTCName_Mongo, "General_Data", "MongoName"); 
		String facetsquery = getmongoData(curTCName_Mongo, "General_Data", "Mongo_SearchMember");
		//get data from web security_Modified According to Runtime Environment_Aravinth
		/*String globalPropFile = "Global Settings.properties";
		String dataTablepath = System.getProperty("user.dir");
		FileInputStream propfile = new FileInputStream(new File(dataTablepath+"/commonComponents/" + globalPropFile));
		Properties prop = new Properties();
		prop.load(propfile);*/
		
		String websecurityquery = getmongoData(curTCName_Mongo, "General_Data", "WebSecurity_Query");
				//.replace("<<ENV>>", prop.getProperty("Environment"));



		/** By Aravinth - END ***/

		MongoClientURI uri = new MongoClientURI("mongodb://" + mongoUsername + ":" + 
				mongoPwd + "@" + mongoServer + "/?authSource=" + mongoName);
		mongoClient = new MongoClient(uri);

		//Get data from Facets and save in Recordset
		ResultSet result_fs = executeQuery_facets_Mongo(curTCName_Mongo,facetsquery);
		ResultSet result_ws = null;

		result_ws = executeQuery_websecurity_Mongo(curTCName_Mongo,websecurityquery);	
		while(result_fs.next())
		{
			String sbbs=result_fs.getString("SBSB_ID");
			listnm.add(sbbs);

		}
		status=false;
		webSecurityLoop:
			while(result_ws.next())
			{	

				webSecurity_Userid = result_ws.getString("WellmarkUserId");	
				subscriberID_websecurity=result_ws.getString("MemberNumber");

				//Add SID in Arraylist taken from WebSecurity DB
				listwebSecurity.add(subscriberID_websecurity);

				for(int k=0;k < listnm.size();k++){			
					// get subscriber id from Facets database
					subscriberID_facets = listnm.get(k);
					arrayDB[0]=subscriberID_websecurity;
					arrayDB[1]=webSecurity_Userid;
					if (subscriberID_facets.equalsIgnoreCase(subscriberID_websecurity)){	
						// Accessing the mongo database 
						database= mongoClient.getDatabase("members");
						BasicDBObject basicdbobjectquery = new BasicDBObject("sourceSystemId",subscriberID_facets);
						Document getqueryval = database.getCollection("contracts").find(basicdbobjectquery).first();
						try {
							subscriberID_mongo = getqueryval.get("sourceSystemId");
							if (subscriberID_mongo.toString().trim().equalsIgnoreCase(subscriberID_facets.trim()));
							{					
								Subscriber_ID=subscriberID_facets;
								status=true;
								break webSecurityLoop;								
							}					
						}

						catch (Exception e) {
							e.printStackTrace();
						}

					}
					
				}

			}
		System.out.println("");
		if (status==false) {
			System.out.println("Overall no records");
		}
		

		/** FOR NEW MEMBER REGISTRATION
		 * Taking SID from Facets - It should not present in WebScurity and should present in Facets DB
		 */
		if (status==false) {
			//Iterating SID from Facets
			for (String FacetsSID : listnm) {
				//Checks the data shouldn't present in WebSecurity DB
				for (String WebSecuritySID : listwebSecurity) {
					if (!WebSecuritySID.equals(FacetsSID)) {
						if (subscriberID_mongo.toString().trim().equals(FacetsSID)) {
							//Taking this SID for registration
							memRegistration_withDB_Mongo(FacetsSID);
						}

					}
				}
			}



		}
		
		result_fs.close();
		result_ws.close();

		return arrayDB;
		
		

	}


}
