package businesscomponents;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Properties;
import java.util.Random;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.TimeUnit;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;

import commonComponents.allocator.Allocator;
import commonComponents.com.cognizant.framework.CraftDataTable;
import commonComponents.com.cognizant.framework.ExcelDataAccess;
import commonComponents.com.cognizant.framework.FrameworkException;
import commonComponents.com.cognizant.framework.Status;
import commonComponents.com.cognizant.framework.TestParameters;
import commonComponents.com.cognizant.framework.selenium.UtilityFunctions;
import commonComponents.supportlibraries.DriverScript;
import commonComponents.supportlibraries.ScriptHelper;
import uimap.MyWellmark_OR;


public class MyWellmark_CommonFunctions extends UtilityFunctions {
	/*** Aravinth additionaly added - START ***/
	//Using multimap where Key is the primary key to get values later
	Multimap<String, String> myMultimap = ArrayListMultimap.create();
	Collection<String> SIDmap;
	String subsIdvl[];
	//For Related Info check
	public String page_Name;
	public ArrayList<String> contents_RelatedInfoUI = new ArrayList<>();
	List<WebElement> relatedInfo_text = null;
	String websecurityuserid;
	String verifyAll_page_Name = null;
	List<WebElement> verifyAll_relatedInfo_text = null;
	String curTCName_Mongo = new String();
	//Put all the test cases in Collection_From RunManger for Mongo
	ArrayList<String> colFlagTC = new ArrayList<>();

	/*** Aravinth additionaly added - END ***/

	String parentWindowHandler1;
	public static String bMedProdSlcted = null;
	public static String brxProdSlcted  = null;
	public static String bDenProdSlcted  = null;
	public static String bHCMProdSlcted  = null;
	public static String carrierID  = null;
	public static String PCPSlcted  = null;
	String sbsbid=null;
	String ssn= null;String dob= null;String lastname = null;String firstname= null;String zipcode = null;String phone=null;
	int intTotalQuotes_retire=0;
	int intTotalQuotes=0;
	/**
	 * Constructor to initialize the component library
	 * @param scriptHelper The {@link ScriptHelper} object passed from the {@link DriverScript}
	 */
	public MyWellmark_CommonFunctions(ScriptHelper scriptHelper) {
		super(scriptHelper);

	}

	private static Connection con=null;
	private static Statement stmt=null;	
	private static ResultSet rs=null;
	//Invoke Application
	public void invokeApplication(){

		String ApplicationURL=dataTable.getData("General_Data", "ApplicationURL_Test");
		String LoginPageTitle=dataTable.getData("General_Data", "LoginPage"); //As of now changed the loginpage name
		driver.get(ApplicationURL);
		driverUtil.waitFor(4000);
		//verifies with page title
		String PageTitleLoaded = driver.getTitle();
		if (PageTitleLoaded.equals(LoginPageTitle)) {
			report.updateTestLog("Invoke Application", "Invoke Application Successful", Status.PASS);
		} 
		else {
			report.updateTestLog("Invoke Application", "Invoke Application Unsuccessful", Status.FAIL);
		}
	}
	public void selectValueFromDropdownForGivenTextContains(By by,String textToBeSelected){
		Select dropDownList = new Select(driver.findElement(by));
		boolean flag=false;
		List<WebElement> options = dropDownList.getOptions();
		for(WebElement option:options){
			if((option.getText().trim()).contains(textToBeSelected)){
				dropDownList.selectByVisibleText(option.getText().trim());
				flag=true;
				break;
			}
		}
		if(flag){
			report.updateTestLog("select Value From Dropdown For Given Text", "'"+textToBeSelected+"' is selected", Status.DONE);
		}else{
			report.updateTestLog("select Value From Dropdown For Given Text", "'"+textToBeSelected+"' is not selected", Status.FAIL);
		}
	}
	// Logout Application
	public void logOutApplication(){
		//performAction(MyWellmark_OR.btnProfile, "CLICK","" );
		//performAction(MyWellmark_OR.btnLogout, "CLICK","" );
	}	
	//Enter Credentials 
	public void enterCredentials(){		
		String userName=dataTable.getData("General_Data", "Username");
		String passWord=dataTable.getData("General_Data", "Password");
		//Login to Application
		driver.findElement(MyWellmark_OR.txtUsername).sendKeys(userName);
		driver.findElement(MyWellmark_OR.txtPassword).sendKeys(passWord);
		if (findElement(By.xpath("//button[contains(.,'Login')]"))==false) {
			performAction(MyWellmark_OR.btnLogin, "SCROLLANDCLICK","" );
			driverUtil.waitFor(3000);
			//waitFor(30, MyWellmark_OR.obj_LatestClaims);
		}else{
			performAction(By.xpath("//button[contains(.,'Login')]"), "CLICK", "");
			//driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driverUtil.waitFor(3000);
			//waitFor(30, MyWellmark_OR.obj_LatestClaims);
		}

		//Close Welcome tips if available
		//if (findElement(MyWellmark_OR.link_avoidShowingTips)==true) {
		//if(driver.isElementvisible(MyWellmark_OR.link_avoidShowingTips, 5)==true){
		//if(waitasExplicit(MyWellmark_OR.link_avoidShowingTips, 5)==true){
		if(waitFor(5, MyWellmark_OR.link_avoidShowingTips)==true){
			report.updateTestLog("Welcome Tips", "Welcome tips available for the member after login", Status.PASS);
			performAction(MyWellmark_OR.link_avoidShowingTips, "SCROLLANDCLICK", "");
			driverUtil.waitFor(2000);
		}
		
		//if (driver.isElementvisible(MyWellmark_OR.modal_OnlineEOB_HmePg, 5)==true) {
		if(waitFor(5, MyWellmark_OR.modal_OnlineEOB_HmePg)==true){
			performAction(MyWellmark_OR.modal_OnlineEOB_HmePg, "SCROLLANDCLICK", "");
			driverUtil.waitFor(1000);
		}

	}

	public void selectMember(){
		String memberSSN = dataTable.getData("General_Data", "SSN/SID");
		List<WebElement> searchResults = driver.findElements(By.xpath("//table/tbody/tr"));
		for (int i = 1; i <=searchResults.size(); i++) {
			String relation = driver.findElement(By.xpath("//table/tbody/tr["+i+"]/td[5]")).getText();
			String ssn = driver.findElement(By.xpath("//table/tbody/tr["+i+"]/td[6]")).getText();
			String status = driver.findElement(By.xpath("//table/tbody/tr["+i+"]/td[7]")).getText();
			if (ssn.trim().equals(memberSSN.trim()) && status.trim().equals("Active") && relation.trim().equals("Policyholder")) {
				performAction(By.xpath("//table/tbody/tr["+i+"]/td[1]/a"), "SCROLLANDCLICK","");
				break;
			} else {
				report.updateTestLog("Select Member", "No Member Found", Status.FAIL);	
			}
		}
	}
	public void validateStatusFilter(String status){
		List<WebElement> claims = null;
		String claimStatus = null;
		selectValueFromDropdownForGivenTextContains(MyWellmark_OR.statusDrp,status);
		if (status.equals("Denied")) {
			claims = driver.findElements(MyWellmark_OR.drp_Status_Denied);
		} else {
			claims = driver.findElements(MyWellmark_OR.claims);
		}

		int paid =0,pending=0,denied=0;

		for (WebElement claim : claims) {
			if (status.equals("Denied")) {
				claimStatus = driver.findElement(MyWellmark_OR.drp_Status_Denied_text).getText().trim();
			} else {
				claimStatus = claim.findElement(MyWellmark_OR.claimStatus).getText().trim();
			}


			if(claimStatus.contains("PAID")){
				paid =paid +1;
			}
			else if(claimStatus.equalsIgnoreCase("Pending")){
				pending = pending + 1;
			}
			else if(claimStatus.equalsIgnoreCase("Denied")){
				denied = denied + 1;
			}
		}
		if (status.equalsIgnoreCase("Paid")&& paid>0 && claims.size()==paid ) {
			report.updateTestLog("Claim list", "Paid Status Claims  are displayed", Status.PASS);
		} 
		else if (status.equalsIgnoreCase("Pending")&& pending>0 && claims.size()==pending ) {
			report.updateTestLog("Claim list", "Pending Status Claims  are displayed", Status.PASS);
		}
		else if (status.equalsIgnoreCase("Denied")&& denied>0 && claims.size()==denied ) {
			report.updateTestLog("Claim list", "Denied Status Claims  are displayed", Status.PASS);
		}
		else {
			report.updateTestLog("Claim list", "Claims Status are not displayed properly", Status.FAIL);
		}

	}
	public void validateStatusAllFilter(){
		//List<WebElement> statusList = driver.findElements(MyWellmark_OR.statusOption);
		selectValueFromDropdownForGivenTextContains(MyWellmark_OR.statusDrp,"All");
		//List<WebElement> claims = driver.findElements(MyWellmark_OR.claims);
		List<WebElement> claims = driver.findElements(MyWellmark_OR.drp_AllFilterStatus);
		int paid =0,pending=0,denied=0;
		for (WebElement claim : claims) {
			String claimStatus = claim.getText();
			if(claimStatus.equalsIgnoreCase("Paid")){
				paid =paid +1;
			}
			else if(claimStatus.equalsIgnoreCase("Pending")){
				pending = pending + 1;
			}
			else if(claimStatus.equalsIgnoreCase("Denied")){
				denied = denied + 1;
			}
		}
		if (claims.size()>0 ) {
			report.updateTestLog("Claim list", "All Status Claims  are displayed", Status.PASS);
		} 
		else {
			report.updateTestLog("Claim list", "All Status Claims  are not displayed", Status.FAIL);
		}
	}
	public void validateSortingByStatus(){
		ArrayList<String> statusClaims_actual = new ArrayList<String>();
		ArrayList<String> statusClaims_sorted = new ArrayList<String>();
		selectValueFromDropdownForGivenId(MyWellmark_OR.sortDrp,0) ;
		List<WebElement> claims = driver.findElements(MyWellmark_OR.drp_AllFilterStatus);
		for (WebElement claim : claims) {
			String claimStatus = claim.getText();
			statusClaims_actual.add(claimStatus);
			statusClaims_sorted.add(claimStatus);
		}
		Collections.sort(statusClaims_sorted);
		Collections.reverse(statusClaims_sorted);
		System.out.println(statusClaims_sorted);
		System.out.println(statusClaims_actual);
		if(statusClaims_actual.equals(statusClaims_sorted)){
			report.updateTestLog("Status Sorted", "Claims sorted by status", Status.PASS);
		}
		else{
			report.updateTestLog("Status Sorted", "Claims not sorted by status", Status.FAIL);
		}
	}
	public void validateSortingByDate(String range){
		ArrayList<Date> claims_actual = new ArrayList<Date>();
		ArrayList<Date> claims_sorted = new ArrayList<Date>();
		if(range.equals("NewestToOld")){
			selectValueFromDropdownForGivenId(MyWellmark_OR.sortDrp,1) ;
		}
		else if(range.equals("OldToNewest")){
			selectValueFromDropdownForGivenId(MyWellmark_OR.sortDrp,2) ;
		}
		List<WebElement> claims = driver.findElements(MyWellmark_OR.lbl_ClaimsDateAll);
		for (WebElement claim : claims) {
			String dateText = claim.getText();
			Date date = null;
			try {
				date = new SimpleDateFormat("MMM d,yyyy").parse(dateText);
			} catch (ParseException e) {
				e.printStackTrace();
			}
			claims_actual.add(date);
			claims_sorted.add(date);
		}

		Collections.sort(claims_sorted);
		if(range.equals("NewestToOld")){
			Collections.reverse(claims_sorted);
		}
		System.out.println(claims_sorted);
		System.out.println(claims_actual);
		if(claims_actual.equals(claims_sorted)){
			report.updateTestLog("Status Sorted", "Claims sorted by "+range, Status.PASS);
		}
		else{
			report.updateTestLog("Status Sorted", "Claims not sorted by "+range, Status.FAIL);
		}
	}
	public void validateSortingByYouPay(String range){
		ArrayList<Double> claims_actual = new ArrayList<Double>();
		ArrayList<Double> claims_sorted = new ArrayList<Double>();
		if(range.equals("LowToHigh")){
			selectValueFromDropdownForGivenId(MyWellmark_OR.sortDrp,3) ;
		}
		else if(range.equals("HighToLow")){
			selectValueFromDropdownForGivenId(MyWellmark_OR.sortDrp,4) ;
		}
		//List<WebElement> claims = driver.findElements(By.xpath("//div[@class='claims-list ng-star-inserted']//p[@class='ng-star-inserted']/span[3]"));
		List<WebElement> claims = driver.findElements(MyWellmark_OR.lbl_YouPayAll);

		for (WebElement claim : claims) {
			String amountText = claim.getText();
			Double amount = null;
			//if(statusText.equalsIgnoreCase("Paid")){
			String[] amountArr= amountText.split(":");
			amount = Double.valueOf(amountArr[1].replace("$", ""));
			claims_actual.add(amount);
			claims_sorted.add(amount);
			//}
		}

		Collections.sort(claims_sorted);
		if(range.equals("HighToLow")){
			Collections.reverse(claims_sorted);
		}
		System.out.println(claims_sorted);
		System.out.println(claims_actual);
		if(claims_actual.equals(claims_sorted)){
			report.updateTestLog("Status Sorted", "Claims sorted by "+range, Status.PASS);
		}
		else{
			report.updateTestLog("Status Sorted", "Claims not sorted by "+range, Status.FAIL);
		}
	}
	public void checkMyplanLink(){
		int size= driver.findElements(MyWellmark_OR.myplanlink).size();
		if(size==1){
			performAction(MyWellmark_OR.myplanlink, "SCROLLANDCLICK", "");
			driverUtil.waitFor(2000);
			driver.waitTillPageLoaded();
			driver.navigate().back();
			driver.waitTillPageLoaded();
			driverUtil.waitFor(5000);
			if(waitFor(5, MyWellmark_OR.modal_OnlineEOB_HmePg)==true){
				performAction(MyWellmark_OR.modal_OnlineEOB_HmePg, "SCROLLANDCLICK", "");
				driverUtil.waitFor(1000);
			}
		}
	}
	public void validateDentistIcon(){
		ArrayList<String> tabs1 = new ArrayList<String> (driver.getWindowHandles());
		driver.switchTo().window(tabs1.get(0)); 
		int imagestate = driver.findElements(MyWellmark_OR.img_DentistIcon).size();
		if (imagestate==1) {
			performAction(MyWellmark_OR.dentistlink, "SCROLLANDCLICK", "");
			report.updateTestLog("find a dentist icon ", "system displayed dentist icon and clicked succesfully", Status.PASS);
		}
		else
		{
			report.updateTestLog("find a dentist icon ", "system not displayed dentist icon and not clicked succesfully", Status.FAIL);
		}
	}
	public void validateDoctorIcon(){
		int imagestate = driver.findElements(MyWellmark_OR.img_DoctorIcon).size();
		if (imagestate==1) {
			performAction(MyWellmark_OR.doctorlink, "SCROLLANDCLICK", "");
			report.updateTestLog("find a Doctor icon ", "system displayed Doctor icon and clicked succesfully", Status.PASS);
		}
		else
		{
			report.updateTestLog("find a Doctor icon ", "system not displayed Doctor icon and not clicked succesfully", Status.FAIL);
		}
	}
	public void validateFaciltyIcon(){
		ArrayList<String> tabs1 = new ArrayList<String> (driver.getWindowHandles());
		driver.switchTo().window(tabs1.get(0)); 
		int imagestate = driver.findElements(MyWellmark_OR.img_FacilityIcon).size();
		if (imagestate==1) {
			performAction(MyWellmark_OR.fcailitylink, "SCROLLANDCLICK", "");
			report.updateTestLog("find a Facility icon ", "system displayed Facility icon and clicked succesfully", Status.PASS);
		}
		else
		{
			report.updateTestLog("find a Facility icon ", "system not displayed Facility icon and not clicked succesfully", Status.FAIL);
		}
	}
	public void validatePharmacyIcon(){
		ArrayList<String> tabs1 = new ArrayList<String> (driver.getWindowHandles());
		driver.switchTo().window(tabs1.get(0)); 
		int imagestate = driver.findElements(MyWellmark_OR.img_PharmacyIcon).size();
		if (imagestate==1) {
			performAction(MyWellmark_OR.pharmacylink, "SCROLLANDCLICK", "");
			report.updateTestLog("find a Pharmacy icon ", "system displayed Pharmacy icon and clicked succesfully", Status.PASS);
		}
		else
		{
			report.updateTestLog("find a Pharmacy icon ", "system not displayed Pharmacy icon and not clicked succesfully", Status.FAIL);
		}
	}
	public void validateDoctorUrl(){
		/*String childWindowHandler2 = driver.getWindowHandle();
		driver.switchTo().window(childWindowHandler2);
		driver.switchTo().activeElement();*/
		String paragraph = dataTable.getData("General_Data", "Paragraph");
		String doctorparagraph = driver.findElement(MyWellmark_OR.lbl_DoctorParagraph).getText();
		int continuebtn = driver.findElements(MyWellmark_OR.doctorcontinuebtn).size();
		int cancelbtn = driver.findElements(MyWellmark_OR.doctorcancelbtn).size();
		if(paragraph.contains(doctorparagraph)&&(continuebtn==1)&&(cancelbtn==1)){
			report.updateTestLog("Interstitial message", "Interstitial message is displayed with Continue and Cancel button", Status.PASS);
		}
		performAction(MyWellmark_OR.doctorcontinuebtn, "SCROLLANDCLICK", "");
		//waitFor(30, MyWellmark_OR.lbl_TermsOfUse);
		driverUtil.waitFor(20000);
		ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
		driver.switchTo().window(tabs2.get(1)); 
		//On getting Terms of Use page, it skips
		int chk_Agree_Cntn = driver.findElements(MyWellmark_OR.btn_Search_provider_cntn).size();
		if (chk_Agree_Cntn==1) {
			performAction(MyWellmark_OR.btn_Search_provider_cntn, "SCROLLANDCLICK", "");
			driverUtil.waitFor(5000);
		}
		String currenturl = driver.getCurrentUrl();
		String DoctorUrl = dataTable.getData("General_Data", "DoctorUrl");
		if(DoctorUrl.contains(currenturl)){
			report.updateTestLog("DoctorUrl", "current Url matched with given Doctor url succesfully", Status.PASS);
		}else
		{
			report.updateTestLog("DoctorUrl", "current Url not matched with given Doctor url", Status.FAIL);
		}
		driver.switchTo().window(tabs2.get(1)).close();
	}
	public void validateFaciltyUrl(){
		/*String childWindowHandler2 = driver.getWindowHandle();
		driver.switchTo().window(childWindowHandler2);
		driver.switchTo().activeElement();*/
		String paragraph = dataTable.getData("General_Data", "Paragraph");
		String doctorparagraph = driver.findElement(MyWellmark_OR.lbl_DoctorParagraph).getText();
		int continuebtn = driver.findElements(MyWellmark_OR.doctorcontinuebtn).size();
		int cancelbtn = driver.findElements(MyWellmark_OR.doctorcancelbtn).size();
		if(paragraph.contains(doctorparagraph)&&(continuebtn==1)&&(cancelbtn==1)){
			report.updateTestLog("Interstitial message", "Interstitial message is displayed with Continue and Cancel button", Status.PASS);
		}
		performAction(MyWellmark_OR.facilitycontinuebtn, "SCROLLANDCLICK", "");
		//waitFor(30, MyWellmark_OR.lbl_TermsOfUse);
		driverUtil.waitFor(20000);
		ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
		driver.switchTo().window(tabs2.get(1));
		//On getting Terms of Use page, it skips
		int chk_Agree_Cntn = driver.findElements(MyWellmark_OR.btn_Search_provider_cntn).size();
		if (chk_Agree_Cntn==1) {
			performAction(MyWellmark_OR.btn_Search_provider_cntn, "SCROLLANDCLICK", "");
			driverUtil.waitFor(5000);
		}
		String currenturl = driver.getCurrentUrl();
		String FaciltyUrl = dataTable.getData("General_Data", "FaciltyUrl");
		if(FaciltyUrl.contains(currenturl)){
			report.updateTestLog("Facilty Url ", "current Url matched with given Facilty url succesfully", Status.PASS);
		}else
		{
			report.updateTestLog("Facilty Url ", "current Url not matched with given Facilty url succesfully", Status.FAIL);
		}
		driver.switchTo().window(tabs2.get(1)).close();
	}
	public void validatePharmacyUrl(){
		/*String childWindowHandler2 = driver.getWindowHandle();
		driver.switchTo().window(childWindowHandler2);
		driver.switchTo().activeElement();*/
		String paragraph = dataTable.getData("General_Data", "PharmacyParagraph");
		String doctorparagraph = driver.findElement(MyWellmark_OR.lbl_DoctorParagraph).getText();
		int continuebtn = driver.findElements(MyWellmark_OR.doctorcontinuebtn).size();
		int cancelbtn = driver.findElements(MyWellmark_OR.doctorcancelbtn).size();
		if(paragraph.contains(doctorparagraph)&&(continuebtn==1)&&(cancelbtn==1)){
			report.updateTestLog("Interstitial message", "Interstitial message must be displayed with Continue and Cancel button", Status.PASS);
		}
		performAction(MyWellmark_OR.pharmacycontinuebtn, "SCROLLANDCLICK", "");
		String PharmURL = dataTable.getData("General_Data", "PharmacyUrl");
		if (waitFor(30, MyWellmark_OR.lbl_CVSPage)==true) {
			ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
			driver.switchTo().window(tabs2.get(1)); 
			driver.navigate().to(PharmURL);
			String currenturl = driver.getCurrentUrl();
			if(PharmURL.contains(currenturl)){
				report.updateTestLog("Pharmacy Url ", "current Url matched with given Pharmacy url succesfully", Status.PASS);
			}else
			{
				report.updateTestLog("Pharmacy Url ", "current Url not matched with given Pharmacy url succesfully", Status.FAIL);
			}
			driver.switchTo().window(tabs2.get(1)).close();
		}else{
			report.updateTestLog("Pharmacy Url ", "Pharmacy URL not loaded", Status.FAIL);
		}
		

	}
	public void validateDentistUrl(){
		/*String childWindowHandler2 = driver.getWindowHandle();
		driver.switchTo().window(childWindowHandler2);
		driver.switchTo().activeElement();*/
		ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
		driver.switchTo().window(tabs2.get(1)); 
		driverUtil.waitFor(10000);
		String currenturl = driver.getCurrentUrl();
		String dentalurl = dataTable.getData("General_Data", "DentalUrl");
		if(dentalurl.contains(currenturl)){
			report.updateTestLog("Dentist Url ", "current Url matched with given Dentist url succesfully", Status.PASS);
		}else
		{
			report.updateTestLog("Dentist Url ", "current Url not matched with given Dentist url succesfully", Status.FAIL);
		}
	}
	public void checkClaimLink(){
		int size= driver.findElements(MyWellmark_OR.claimslink).size();
		if(size==1){
			performAction(MyWellmark_OR.claimslink, "SCROLLANDCLICK", "");
			waitFor(10, MyWellmark_OR.lbl_ClaimsPage);
			int state=  driver.findElements(MyWellmark_OR.lbl_ClaimsPage_header).size();
			if(state==1) {
				report.updateTestLog("Claim page ", "System navigated to claim page succesfully", Status.PASS);
			} else {
				report.updateTestLog("Claim page ", "System is not navigated to claim page succesfully", Status.FAIL);
			}
		}
	}
	public void checkClaimDetails(){
		int servicedate= driver.findElements(MyWellmark_OR.lbl_ServiceDate).size();
		String patientname = null;String providername=null;
		//String youpay=null;
		String status= null;
		try {
			patientname = driver.findElement(MyWellmark_OR.lbl_ClaimDetails_patientName).getText();
			providername= driver.findElement(MyWellmark_OR.lbl_ClaimDetails_providerName).getText();
			//youpay= driver.findElement(By.xpath("((//div[@class='claims-list ng-star-inserted'])[1]//p)[4]")).getText();
			status= driver.findElement(MyWellmark_OR.lbl_ClaimDetails_status).getText();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String [] patientnamelist= patientname.split(":");
		String [] providernamelist= providername.split(":");
		//String [] youpaylist= youpay.split(":");
		String [] statuslist= status.split(":");
		//&&(youpaylist[1]!=null)
		//youpay:"+youpaylist[1]+", 
		if ((servicedate==1)&&(patientnamelist[1]!=null)&&(providernamelist[1]!=null)&&(statuslist[1]!=null)) {
			report.updateTestLog("Claim details ", "System displayed Claim details with patientname:"+patientnamelist[1]+", providername:"+providernamelist[1]+", status:"+statuslist[1]+" succesfully", Status.PASS);
		} else {
			report.updateTestLog("Claim details ", "System is not displayed Claim details with patientname:"+patientnamelist[1]+", providername:"+providernamelist[1]+", status:"+statuslist[1]+" succesfully", Status.FAIL);
		}
	}
	public void selectType(){
		int drp_usertype = driver.findElements(By.xpath("//select[@id='ctl00_body_ddlRegisterNow']")).size();
		if (drp_usertype==1) {
			selectValueFromDropdownForGivenId(MyWellmark_OR.usertype,1) ;	
		}
		int btn_reg =driver.findElements(MyWellmark_OR.btn_Registration).size();
		if (btn_reg==1) {
			performAction(MyWellmark_OR.btn_Registration, "SCROLLANDCLICK", "");
		}else{
			performAction(MyWellmark_OR.regbtn, "SCROLLANDCLICK", "");
		}


		driverUtil.waitFor(2000);
	}
	public void extractdata(String sid) throws SQLException, ClassNotFoundException{
		String query = dataTable.getData("General_Data", "ExtractQuery");
		String Server_Name_DB = dataTable.getData("General_Data", "DBServer");
		String Name_DB = dataTable.getData("General_Data", "DBName");
		String UName_DB = dataTable.getData("General_Data", "DBUsername");
		String Pwd_DB = dataTable.getData("General_Data", "DBPassword");


		query = query.replace("<<SBSB_ID>>", sid);
		//Newly added_Aravinth
		openDBConnection(Server_Name_DB +  
				"databaseName=" + Name_DB,UName_DB,Pwd_DB);
		/////ResultSet rs = executeQuery(query);
		ResultSet rs = getRecordSet(query);


		try {
			while(rs.next()) {
				sbsbid = rs.getString("SBSB_ID").trim();
				lastname = rs.getString("SBSB_LAST_NAME").trim();
				firstname = rs.getString("SBSB_FIRST_NAME").trim();
				ssn = rs.getString("MEME_SSN").trim();
				dob = rs.getString("MEME_BIRTH_DT").trim();
				zipcode = rs.getString("SBAD_ZIP").trim();
				phone = rs.getString("SBAD_PHONE").trim();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (ssn!=null){
			ssn=ssn.substring(5, 9);
		}
		/*if (phone.equals("")){
			phone=phone.replace("", "6418427336");
		}*/
	}

	public void extractdata_Mongo(String curTCName_Mongo,String sid) throws SQLException, ClassNotFoundException, NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException{
		String query = getmongoData(curTCName_Mongo, "General_Data", "ExtractQuery");
		String Server_Name_DB = getmongoData(curTCName_Mongo, "General_Data", "DBServer");
		String Name_DB = getmongoData(curTCName_Mongo, "General_Data", "DBName");
		String UName_DB = getmongoData(curTCName_Mongo, "General_Data", "DBUsername");
		String Pwd_DB = getmongoData(curTCName_Mongo, "General_Data", "DBPassword");

		//sid = dataTable.getData("General_Data", "Username");
		query = query.replace("<<SBSB_ID>>", sid);
		//Newly added_Aravinth
		openDBConnection(Server_Name_DB +  
				"databaseName=" + Name_DB,UName_DB,Pwd_DB);
		/////ResultSet rs = executeQuery(query);
		ResultSet rs = getRecordSet(query);


		try {
			while(rs.next()) {
				sbsbid = rs.getString("SBSB_ID").trim();
				lastname = rs.getString("SBSB_LAST_NAME").trim();
				firstname = rs.getString("SBSB_FIRST_NAME").trim();
				ssn = rs.getString("MEME_SSN").trim();
				dob = rs.getString("MEME_BIRTH_DT").trim();
				zipcode = rs.getString("SBAD_ZIP").trim();
				phone = rs.getString("SBAD_PHONE").trim();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (ssn!=null){
			ssn=ssn.substring(5, 9);
		}
		/*if (phone.equals("")){
			phone=phone.replace("", "6418427336");
		}*/
	}

	public void registerMember(String subsId){
		//Switching tabs
		ArrayList<String> tabs = new ArrayList<>(driver.getWindowHandles());
		System.out.println(tabs.size());
		if (tabs.size() > 1) {
			driver.switchTo().window(tabs.get(1));
		}else{
			driver.switchTo().window(tabs.get(0));
		}

		if (driver.isElementvisible(MyWellmark_OR.nextbtn)){
			//performAction(MyWellmark_OR.wid, "SCROLLCLICKANDSENDKEYS", sbsbid);
			performAction(By.xpath("//div[@class='wmk-card']//label[contains(.,'Wellmark ID')]/following-sibling::input"), "SENDKEYS", sbsbid);
			performAction(MyWellmark_OR.fname, "SCROLLCLICKANDSENDKEYS", firstname);
			performAction(MyWellmark_OR.lname, "SCROLLCLICKANDSENDKEYS", lastname);
			selectValueFromDropdownForGivenId(MyWellmark_OR.relationship,1);
			performAction(MyWellmark_OR.ssn, "SCROLLCLICKANDSENDKEYS", ssn);
			performAction(MyWellmark_OR.dob, "SCROLLCLICKANDSENDKEYS", dob);
			performAction(MyWellmark_OR.zipcode, "SCROLLCLICKANDSENDKEYS", zipcode);
			if(phone.equals("")){
				phone=dataTable.getData("General_Data", "Phone");
			}
			performAction(MyWellmark_OR.phone, "SCROLLCLICKANDSENDKEYS", phone);
			String name = firstname.concat(lastname).concat("@").concat("wellmark.com");
			performAction(MyWellmark_OR.emailid, "SCROLLCLICKANDSENDKEYS", name);
			performAction(MyWellmark_OR.nextbtn, "SCROLLANDCLICK", "");
			int state1 = driver.findElements(MyWellmark_OR.lbl_memReg).size();
			if(state1==1){
				report.updateTestLog("Registration First Step", "Registration First Step is completedly sucessfully", Status.PASS);
			}else
			{
				report.updateTestLog("Registration First Step", "Registration First Step is not completedly sucessfully", Status.FAIL);
			}
		}
	}
	public void registerMemberStep2(String subsId){
		int state = driver.findElements(MyWellmark_OR.lbl_memReg).size();
		if(state==1){
			//String username = randomIdentifier();
			String username = subsId + "SELF";
			String Password = dataTable.getData("General_Data", "Password");
			String securityans = dataTable.getData("General_Data", "securityans");
			dataTable.putData("General_Data", "Username", username);
			/*String randomvalue= "kar";
			if(username!=null){
				username= username.concat(randomvalue);
			}*/  //DIUVVHMVYDIUVVHMVY
			performAction(MyWellmark_OR.userid, "SENDKEYS", username);
			performAction(MyWellmark_OR.passwd, "SENDKEYS", Password);
			performAction(MyWellmark_OR.confirmpasswd, "SENDKEYS", Password);
			selectValueFromDropdownForGivenId(MyWellmark_OR.securityques1,1);
			performAction(MyWellmark_OR.securityans1, "SENDKEYS", securityans);
			selectValueFromDropdownForGivenId(MyWellmark_OR.securityques2,2);
			performAction(MyWellmark_OR.securityans2, "SENDKEYS", securityans);
			driver.findElement(MyWellmark_OR.cerifyidentity).sendKeys(Keys.SPACE);	
			driver.findElement(MyWellmark_OR.termscondition).sendKeys(Keys.SPACE);		
			performAction(MyWellmark_OR.submitbtn, "SCROLLANDCLICK", "");
			driverUtil.waitFor(1000);
			report.updateTestLog("Registration Second Step", "Registration Second Step is completedly sucessfully", Status.PASS);
		}
		else{
			report.updateTestLog("Registration Second Step", "Registration Second Step is not completedly sucessfully", Status.FAIL);
		}
		int state1 =driver.findElements(MyWellmark_OR.regsucessmsg).size();
		//performAction(MyWellmark_OR.continuebtn, "SCROLLANDCLICK", "");
		driver.waitTillPageLoaded();
		if(state1==1){
			report.updateTestLog("Registration", "Registration is completedly sucessfully", Status.PASS);
		}else{
			report.updateTestLog("Registration", "Registration is not completedly sucessfully", Status.FAIL);
		}
	}
	public void validateFutureEffMsg(){

		int policymsg = driver.findElements(MyWellmark_OR.lbl_policymsg).size();
		//int benefitmsg = driver.findElements(MyWellmark_OR.lbl_benefitmsg).size();
		//int welcomenote = driver.findElements(MyWellmark_OR.lbl_welcomeNote).size();
		int doctorlink = driver.findElements(MyWellmark_OR.doctorlink).size();
		int fcailitylink = driver.findElements(MyWellmark_OR.fcailitylink).size();
		int pharmacylink = driver.findElements(MyWellmark_OR.pharmacylink).size();
		int dentistlink = driver.findElements(MyWellmark_OR.dentistlink).size();
		if ((policymsg==1)/*&&(benefitmsg==1)&&(welcomenote==1)*/) {
			report.updateTestLog("Messages", "policymsg, benefitmsg, welcomenote is displayed sucessfully", Status.PASS);
		} else {
			report.updateTestLog("Messages", "policymsg, benefitmsg, welcomenote is not displayed sucessfully", Status.FAIL);
		}
		if ((doctorlink!=1)&&(fcailitylink!=1)&&(pharmacylink!=1)&&(dentistlink!=1)) {
			report.updateTestLog("Home Page", "Home Page is not displayed any widgets regarding benefits,claims,id card and Find care sucessfully", Status.PASS);
		} else {
			report.updateTestLog("Home Page", "Home Page is displayed any widgets regarding benefits,claims,id card and Find care sucessfully", Status.FAIL);
		}
	}
	public void checkHighPerformanceLink(){
		performAction(MyWellmark_OR.highperformancelink, "SCROLLANDCLICK", "");
		driverUtil.waitFor(10000);
		driver.waitTillPageLoaded();
		ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
		driver.switchTo().window(tabs2.get(1)); 
		//String currenturl = driver.getCurrentUrl();
		int state = driver.findElements(MyWellmark_OR.lbl_HyVee).size();
		if (state==1){
			report.updateTestLog("High Performance network ", "System displayed PDF of their plan's provider directory succesfully", Status.PASS);
		}else
		{
			report.updateTestLog("High Performance network ", "System is not displayed PDF of their plan's provider directory succesfully", Status.FAIL);
		}	
	}
	public void CheckUiGradeCare(){

		performAction(MyWellmark_OR.findcarelink, "SCROLLANDCLICK", "");
		driver.waitTillPageLoaded();
		performAction(MyWellmark_OR.uigraedecategorylink, "SCROLLANDCLICK", "");
		driver.waitTillPageLoaded();
		ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
		driver.switchTo().window(tabs2.get(1)); 
		String uigradeURL=dataTable.getData("General_Data", "uigradcare_url");
		String currenturl = driver.getCurrentUrl();
		int state = driver.findElements(MyWellmark_OR.lbl_UIGRADDir).size();
		if ((state==1)&&(uigradeURL.contains(currenturl))){
			report.updateTestLog("UIGRADCare ", "System displayed UIGRADCare directory succesfully", Status.PASS);
		}else
		{
			report.updateTestLog("UIGRADCare ", "System is not displayed UIGRADCare directory succesfully", Status.FAIL);
		}
	}
	/*** Aravinth - START ***/
	public void emailVerify_PreChecks(){
		//Flow Change (Reloginwith current credentials_Aravinth) - START
		int reloginCheck = driver.findElements(MyWellmark_OR.obj_ReloginPage).size();
		if (reloginCheck==1) {
			performAction(MyWellmark_OR.txt_Relogin_Username, "SENDKEYS", dataTable.getData("General_Data", "Username"));
			performAction(MyWellmark_OR.txt_Relogin_Pwd, "SENDKEYS", dataTable.getData("General_Data", "Password"));
			performAction(MyWellmark_OR.btn_Relogin_Login, "SCROLLANDCLICK", "");
			driverUtil.waitFor(2000);
		}
		//Check for Email
		int emailVerify = driver.findElements(MyWellmark_OR.txtEmailVerify).size();
		if (emailVerify==1) {
			performAction(MyWellmark_OR.txtEmailVerify, "SENDKEYS", "SubramanianB@wellmark.com");
			performAction(MyWellmark_OR.btnEmailVerifySubmit, "SCROLLANDCLICK", "");
			driverUtil.waitFor(2000);

			int ev_success = driver.findElements(MyWellmark_OR.lblEmailVerifySuccessmsg).size();
			if (ev_success==1) {
				report.updateTestLog("Email Verification", "Email Verfication done successful", Status.PASS);
			}else{
				report.updateTestLog("Email Verification", "Email Verfication Unsuccessful", Status.FAIL);
			}


			//Continue to My Wellmark
			performAction(MyWellmark_OR.btnEmailVerifyContinue, "SCROLLANDCLICK", "");
			driverUtil.waitFor(8000);

			int welcome_msg = driver.findElements(MyWellmark_OR.lbl_Welcomemsg).size();
			if (welcome_msg==1) {
				report.updateTestLog("Welcome Message popup", "Welcomes message displayed successful", Status.PASS);
			} else {
				report.updateTestLog("Welcome Message popup", "Welcomes message not displayed", Status.FAIL);
			}	
		}

		//Flow Change (Reloginwith current credentials_Aravinth) - END
	}
	/*** Aravinth - END ***/
	/* Praveen***********************/
	public void Changethepassword()
	{
		performAction(MyWellmark_OR.profile,"click","");
		driverUtil.waitFor(5000);
		int sizeedit=driver.findElements(MyWellmark_OR.passwordeditlink).size();

		if(sizeedit==1)
		{
			report.updateTestLog("Edit Link", "Click on Edit link near the username in ACCOUNT SECURITY widget", Status.PASS);	
		}
		else
		{
			report.updateTestLog("Edit Link", "Click on Edit link near the username in ACCOUNT SECURITY widget", Status.FAIL);
		}
		performAction(MyWellmark_OR.passwordeditlink,"SCROLLANDCLICK","");
		driverUtil.waitFor(5000);
		String newpassword = dataTable.getData("General_Data", "newpassword");
		String oldpassword = dataTable.getData("General_Data", "Password");
		driver.findElement(MyWellmark_OR.currentpwd).sendKeys(oldpassword);
		driver.findElement(MyWellmark_OR.newpwd).sendKeys(newpassword);
		driver.findElement(MyWellmark_OR.confirmpwd).sendKeys(newpassword);
		performAction(MyWellmark_OR.savebutton,"click","");
		driverUtil.waitFor(10000);
		int sizesucc=driver.findElements(MyWellmark_OR.passsuccessful).size();
		if(sizesucc==1)
		{
			report.updateTestLog("Change Password", "The confirmation message will be displayed in profile page for changing the Password", Status.PASS);
			dataTable.putData("General_Data", "Password", newpassword);
		}
		else
		{
			report.updateTestLog("Change Password", "The confirmation message will be displayed in profile page for changing the Password", Status.FAIL);
		}
	}
	public void Changetheusername()
	{
		performAction(MyWellmark_OR.profile,"click","");
		driverUtil.waitFor(5000);
		int sizeedit=driver.findElements(MyWellmark_OR.usernameeditlink).size();

		if(sizeedit==1)
		{
			report.updateTestLog("Edit Link", "Click on Edit link near the username in ACCOUNT SECURITY widget", Status.PASS);	
		}
		else
		{
			report.updateTestLog("Edit Link", "Click on Edit link near the username in ACCOUNT SECURITY widget", Status.FAIL);
		}

		performAction(MyWellmark_OR.usernameeditlink,"SCROLLANDCLICK","");
		driverUtil.waitFor(5000);
		String userName = dataTable.getData("General_Data", "Username");
		String password = dataTable.getData("General_Data", "Password");
		driver.findElement(MyWellmark_OR.verifypassword).sendKeys(password);
		driver.findElement(MyWellmark_OR.newuserid).sendKeys(userName);
		performAction(MyWellmark_OR.savebutton,"click","");
		driverUtil.waitFor(10000);
		int sizesucc=driver.findElements(MyWellmark_OR.useridsuccessful).size();
		if(sizesucc==1)
		{
			report.updateTestLog("Change Username", "The confirmation message will be displayed in profile page for changing the username", Status.PASS);	
		}
		else
		{
			report.updateTestLog("Change Username", "The confirmation message will be displayed in profile page for changing the username", Status.FAIL);
		}
	}
	public void error_message_invalidpwd()
	{
		if (driver.isElementVisible(MyWellmark_OR.link_avoidShowingTips)) {
			performAction(MyWellmark_OR.link_avoidShowingTips, "SCROLLANDCLICK", "");
			driverUtil.waitFor(2000);
		}
		performAction(MyWellmark_OR.profile,"click","");
		waitFor(10, MyWellmark_OR.lbl_accProfile);
		int sizeedit=driver.findElements(MyWellmark_OR.passwordeditlink).size();

		if(sizeedit==1)
		{
			report.updateTestLog("Edit Link", "Click on Edit link near the username in ACCOUNT SECURITY widget", Status.PASS);	
		}
		else
		{
			report.updateTestLog("Edit Link", "Click on Edit link near the username in ACCOUNT SECURITY widget", Status.FAIL);
		}
		performAction(MyWellmark_OR.passwordeditlink,"SCROLLANDCLICK","");
		waitFor(10, MyWellmark_OR.lbl_EditPwd);
		String password = dataTable.getData("General_Data", "Password");
		String newpassword = dataTable.getData("General_Data", "newpassword");		
		driver.findElement(MyWellmark_OR.currentpwd).sendKeys(password);
		driver.findElement(MyWellmark_OR.newpwd).sendKeys(newpassword);
		driver.findElement(MyWellmark_OR.confirmpwd).sendKeys(newpassword);
		performAction(MyWellmark_OR.savebutton,"click","");

		List<WebElement> errormess=driver.findElements(MyWellmark_OR.pwderror);		
		String pwderrormessgae = dataTable.getData("General_Data", "invalidinputerror");
		String[] errormessageactual = new String[]{null,null};
		int i=0;
		for (WebElement errormess_Element : errormess) {
			errormessageactual[i]=errormess_Element.getText();
			i++;
		}
		if((errormessageactual[0].equals(pwderrormessgae)) && (errormessageactual[1].equals(pwderrormessgae)))
		{
			report.updateTestLog("Invalid Password error", "Error message is displayed for password: "+newpassword+" as "+pwderrormessgae, Status.PASS);	
		}
		else
		{
			report.updateTestLog("Invalid Password error", "Error message is not displayed for password: "+newpassword, Status.FAIL);

		}		
	}

	public void logoutmywellmark()
	{
		performAction(MyWellmark_OR.logoutbutton,"click","");
		driverUtil.waitFor(2000);
		//int logoutsize=driver.findElements(MyWellmark_OR.logoutpagetext).size();
		if(driver.isElementVisible(MyWellmark_OR.btn_Relogin_Login))
		{
			report.updateTestLog("Logout", "User must be logged out", Status.PASS);	
		}
		else
		{
			report.updateTestLog("Logout", "User is not logged out", Status.FAIL);
		}
		//		driver.manage().deleteAllCookies();
		//		driver.quit();
	}
	public void Error_message_for_invalid()
	{
		performAction(MyWellmark_OR.profile,"click","");
		waitFor(10, MyWellmark_OR.lbl_accProfile);
		int sizeedit=driver.findElements(MyWellmark_OR.usernameeditlink).size();
		if(sizeedit==1)
		{
			report.updateTestLog("Edit Link", "Click on Edit link near the username in ACCOUNT SECURITY widget", Status.PASS);	
		}
		else
		{
			report.updateTestLog("Edit Link", "Click on Edit link near the username in ACCOUNT SECURITY widget", Status.FAIL);
		}
		performAction(MyWellmark_OR.usernameeditlink,"SCROLLANDCLICK","");
		waitFor(10, MyWellmark_OR.lbl_ChgUser);
		String password = dataTable.getData("General_Data", "Password");		
		String[] invalid=new String[]{"we2","rghwueirvygeyfgvnehfefhgvnbhfvbfsvsfnhbvehvbhfbvhbbgrbehr","abcdefghi@"};
		String useriderrormessgae = dataTable.getData("General_Data", "invalidinputerror");
		String errormessage[]=useriderrormessgae.split(";");

		int size=invalid.length;
		for(int i=0;i<size;i++)
		{
			driver.findElement(MyWellmark_OR.verifypassword).clear();
			driver.findElement(MyWellmark_OR.verifypassword).sendKeys(password);
			driver.findElement(MyWellmark_OR.newuserid).clear();
			driver.findElement(MyWellmark_OR.newuserid).sendKeys(invalid[i]);
			performAction(MyWellmark_OR.savebutton,"click","");
			String errormess=driver.findElement(MyWellmark_OR.useriderror).getText();

			if(errormessage[i].equals(errormess))
			{
				report.updateTestLog("Invalid user error", "Error message is displayed for username: "+invalid[i]+" as "+errormess, Status.PASS);	
			}
			else
			{
				report.updateTestLog("Invalid user error", "Error message is not displayed for username: "+invalid[i], Status.FAIL);
				break;
			}

		}
	}
	public void change_security_ques()
	{
		performAction(MyWellmark_OR.profile,"click","");
		waitFor(10, MyWellmark_OR.lbl_accProfile);
		int sizeedit=driver.findElements(MyWellmark_OR.securityquesedit).size();
		if(sizeedit==1)
		{
			report.updateTestLog("Edit Link", "Click on Edit link near the Security Questions in ACCOUNT SECURITY widget", Status.PASS);	
		}
		else
		{
			report.updateTestLog("Edit Link", "Click on Edit link near the Security Questions in ACCOUNT SECURITY widget", Status.FAIL);
		}
		performAction(MyWellmark_OR.securityquesedit,"SCROLLANDCLICK","");
		waitFor(10, MyWellmark_OR.lbl_SecurityQn);
		Random rand=new Random();
		int max=17,min=2;		
		int first=min+rand.nextInt(max-min+1);
		driver.findElement(By.xpath("//select[@id='securityQuestionOne']/option["+first+"]")).click();
		driver.findElement(MyWellmark_OR.secanswer1).sendKeys("wellmark");
		int second=2+rand.nextInt(17-2+1);
		if(first==second)
			second=min+rand.nextInt(max-min+1);
		driver.findElement(By.xpath("//select[@id='securityQuestionTwo']/option["+second+"]")).click();
		driver.findElement(MyWellmark_OR.secanswer2).sendKeys("wellmark");
		report.updateTestLog("Security Questions","Questions are  selected from the 'Security question #1/2' and answers are entered in 'Security answer #2'", Status.SCREENSHOT);
		performAction(MyWellmark_OR.savebutton,"click","");
		int sizesucc=driver.findElements(MyWellmark_OR.secquessuccessful).size();
		if(sizesucc==1)
		{
			report.updateTestLog("Change Security Question", "The confirmation message is  displayed in profile page for changing the security questions", Status.PASS);	
		}
		else
		{
			report.updateTestLog("Change Security Question", "The confirmation message is not displayed in profile page for changing the security questions", Status.FAIL);
		}			
	}
	public void  Error_message_securityques()
	{
		performAction(MyWellmark_OR.profile,"click","");
		waitFor(10, MyWellmark_OR.lbl_accProfile);
		int sizeedit=driver.findElements(MyWellmark_OR.securityquesedit).size();
		if(sizeedit==1)
		{
			report.updateTestLog("Edit Link", "Click on Edit link near the Security Questions in ACCOUNT SECURITY widget", Status.PASS);	
		}
		else
		{
			report.updateTestLog("Edit Link", "Click on Edit link near the Security Questions in ACCOUNT SECURITY widget", Status.FAIL);
		}
		performAction(MyWellmark_OR.securityquesedit,"SCROLLANDCLICK","");
		waitFor(10, MyWellmark_OR.lbl_SecurityQn);
		Random rand=new Random();
		int max=17,min=2;		
		int first=min+rand.nextInt(max-min+1);
		driver.findElement(By.xpath("//select[@id='securityQuestionOne']/option["+first+"]")).click();
		driver.findElement(MyWellmark_OR.secanswer1).sendKeys("wellmark");
		driver.findElement(By.xpath("//select[@id='securityQuestionTwo']/option["+first+"]")).click();
		driver.findElement(MyWellmark_OR.secanswer2).sendKeys("wellmark");
		report.updateTestLog("Security Questions","Same Questions are  selected in  the 'Security question #1/2'", Status.SCREENSHOT);
		performAction(MyWellmark_OR.savebutton,"click","");
		String errormessage = dataTable.getData("General_Data", "invalidinputerror");
		String errormess=driver.findElement(MyWellmark_OR.useriderror).getText();
		if(errormessage.equals(errormess))
			report.updateTestLog("Invalid user error", "Error message is displayed as : "+errormess, Status.PASS);	
		else	
			report.updateTestLog("Invalid user error", "Error message is not displayed as : "+errormess, Status.FAIL);
	}
	public void idcardvalidationcheckallmembers() 
	{
		String name=driver.findElement(MyWellmark_OR.welcomeText).getText();
		String firstName=name.substring(8);
		dataTable.putData("General_Data", "PolicyHolder_Name", firstName);
		performAction(MyWellmark_OR.myPlansLink,"SCROLLANDCLICK","");
		driverUtil.waitFor(5000);	
		/*driver.findElement(MyWellmark_OR.benefitPeriod).sendKeys(Keys.PAGE_DOWN);
		driverUtil.waitFor(2000);*/
		int sizeidcard=driver.findElements(MyWellmark_OR.viewidcardslink).size();
		if(sizeidcard==1)
		{
			report.updateTestLog("View ID Cards", "View ID card link is available", Status.PASS);

		}
		else
		{
			report.updateTestLog("Edit Link", "View ID card link is not available", Status.FAIL);
		}
		performAction(MyWellmark_OR.viewidcardslink,"SCROLLANDCLICK","");
		driverUtil.waitFor(5000);
		List<WebElement> idcardlinks=driver.findElements(MyWellmark_OR.IDcardsLink);
		int i=0;
		int sizenoofidcard=idcardlinks.size();
		String[] membernameslink=new String[sizenoofidcard];
		String[] membernamesidcard=new String[sizenoofidcard];
		String[] membernamesidcard_woInitials = null;
		String membernamesidcard_woInitials_new = null;
		if(sizenoofidcard!=0)
		{
			for (WebElement id : idcardlinks) 
			{
				membernameslink[i]=id.getText().split("\\n")[0];
				id.click();
				driverUtil.waitFor(1000);
				//membernamesidcard[i]=driver.findElement(MyWellmark_OR.idcardname).getText().split("\\s+")[0]+" ".concat(driver.findElement(MyWellmark_OR.idcardname).getText().split("\\s+")[2]);
				membernamesidcard[i]=driver.findElement(MyWellmark_OR.idcardname).getText().trim();
				membernamesidcard_woInitials = membernamesidcard[i].split(" ");
				if (membernamesidcard_woInitials.length==3) {
					membernamesidcard_woInitials_new = membernamesidcard_woInitials[0] + " " + membernamesidcard_woInitials[2];	
				}else{
					membernamesidcard_woInitials_new = membernamesidcard_woInitials[0] + " " + membernamesidcard_woInitials[1];
				}
				
				if(membernameslink[i].contains(membernamesidcard_woInitials_new))
					report.updateTestLog("Member ID Cards", "ID card is displayed for Member "+i, Status.PASS);
				else
					report.updateTestLog("Member ID Cards", "ID card is displayed not  for Member "+i, Status.FAIL);				
				i++;
			}
		}
		else
		{
			String welcomeName=dataTable.getData("General_Data", "PolicyHolder_Name").toUpperCase();
			String memberNamesIdCardOne= driver.findElement(MyWellmark_OR.idcardname).getText().split("\\s+")[0].toUpperCase();
			if(welcomeName.contains(memberNamesIdCardOne))
				report.updateTestLog("Member ID Cards", "ID card is displayed for Member "+welcomeName, Status.PASS);
			else
				report.updateTestLog("Member ID Cards", "ID card is displayed not  for Member "+welcomeName, Status.FAIL);
		}
	}
	public void idcardfrontlayout()
	{	
		List<WebElement> idcardlinks=driver.findElements(MyWellmark_OR.IDcardsLink);
		if(idcardlinks.size()!=0)
		{
			idcardlinks.get(0).click();	
			idcardlinks.get(0).sendKeys(Keys.ARROW_DOWN);
			idcardlinks.get(0).sendKeys(Keys.ARROW_DOWN);
			idcardlinks.get(0).sendKeys(Keys.ARROW_DOWN);
		}
		int frontlogo=driver.findElements(MyWellmark_OR.idcardfrontlogo).size();
		int backlogo=driver.findElements(MyWellmark_OR.idcardbacklogo).size();
		if(frontlogo==1&&backlogo==1)
		{
			report.updateTestLog("BCBS Logo", " Blue Cross Blue shield Logo is displayed in the Front and back side of the ID card", Status.PASS);

		}
		else
		{
			report.updateTestLog("BCBS Logo", " Blue Cross Blue shield Logo is displayed in the Front and back side of the ID card", Status.FAIL);
		}
		int plancodedisp=driver.findElements(MyWellmark_OR.plancode).size();
		//String plancode = dataTable.getData("General_Data", "plancode");
		if(plancodedisp==1)
		{
			report.updateTestLog("Plan Code", "Plan Code is  displayed in front of the ID card", Status.PASS);					
		}
		else
		{
			report.updateTestLog("Benefit Info", "Plan Code is   not displayed in front of the ID card", Status.FAIL);
		}		
		String benefittext=driver.findElement(MyWellmark_OR.benefitinfo).getText();
		String benefit = dataTable.getData("General_Data", "benefitinfo");
		if(benefittext.equalsIgnoreCase(benefit))
		{
			report.updateTestLog("Benefit Info", "Benefit Information content is  displayed in front of the ID card", Status.PASS);					
		}
		else
		{
			report.updateTestLog("Benefit Info", "Benefit Information content is  not displayed in front of the ID card", Status.FAIL);
		}		
		String rxbin = dataTable.getData("General_Data", "rxbin");
		String rxpcn = dataTable.getData("General_Data", "rxpcn");
		String rxgrp = dataTable.getData("General_Data", "rxgrp");
		String rxbindisp= driver.findElement(MyWellmark_OR.idcardBIN).getText();
		String rxpcndisp= driver.findElement(MyWellmark_OR.idcardPCN).getText();
		String rxgrpdisp= driver.findElement(MyWellmark_OR.idcardGrp).getText();
		if (rxbin.equalsIgnoreCase(rxbindisp)&&rxpcn.equalsIgnoreCase(rxpcndisp)&&rxgrp.equalsIgnoreCase(rxgrpdisp))
		{
			report.updateTestLog("Rx Details", " RxBIN, RxPCN and RxGrp Details are displayed  in Front of ID card ", Status.PASS);

		}
		else
		{
			report.updateTestLog("Rx Details", " RxBIN, RxPCN and RxGrp Details are not displayed  in Front of ID card", Status.FAIL);
		}
		/*String suitCaseText = dataTable.getData("General_Data", "suitCase");		
		int suitCaseSize=driver.findElements(By.xpath("//div[@class='panel dyk-panel id-card-linklist']//div[@class='id-card id-card-front']//img[@alt='"+suitCaseText+"']")).size();
		if(suitCaseSize==1)
		{
			report.updateTestLog("Suit Case Image", suitCaseText+"is displayed in the Front side of the ID card", Status.PASS);

		}
		else
		{
			report.updateTestLog("Suit Case Image", suitCaseText+" is not displayed in the Front  side of the ID card", Status.FAIL);
		}*/
		String Groupno=driver.findElement(MyWellmark_OR.idcardgroupno).getText();
		String wid=driver.findElement(MyWellmark_OR.idno).getText();
		dataTable.putData("General_Data", "Group_Number", Groupno);
		dataTable.putData("General_Data", "Wellmark_Id", wid);
		String memname=driver.findElement(MyWellmark_OR.idcardname).getText();
		dataTable.putData("General_Data", "PolicyHolder_Name", memname);			
	}
	public void idcardbacklayout()
	{
		String websitedisp=driver.findElement(MyWellmark_OR.website).getText();
		String website="www.wellmark.com";		 		
		//String custno ="1-800-355-2031";
		String custnodisp=driver.findElement(MyWellmark_OR.custno).getText();
		int custSize=driver.findElements(MyWellmark_OR.custno).size();
		if (custSize==1&&website.equalsIgnoreCase(websitedisp) )
		{
			report.updateTestLog("Customer Service and Website", "Cus Service Number and website is displayed in Back of ID card", Status.PASS);

		}
		else
		{
			report.updateTestLog("Customer Service no", "Cus Service Number and website is not displayed in Back of ID card", Status.FAIL);
		}
		dataTable.putData("General_Data", "CustomerServiceNumber", custnodisp);
		String membertext=driver.findElement(MyWellmark_OR.instextmembers).getText();
		String provtext=driver.findElement(MyWellmark_OR.instextproviders).getText();
		String instext = dataTable.getData("General_Data", "instext");
		String insttextinp[]=instext.split(";");
		if(membertext.equalsIgnoreCase(insttextinp[0])&&provtext.equalsIgnoreCase(insttextinp[1]))
		{
			report.updateTestLog("Instructional Text", "Instructional Text for members and providers are  displayed in Back of ID card", Status.PASS);						
		}
		else
		{
			report.updateTestLog("Instructional Text", "Instructional Text for members and providers are not displayed in Back of ID card", Status.FAIL);			
		}

		if (driver.findElements(MyWellmark_OR.rxindex).size()==1) {
			String rxtext=driver.findElement(MyWellmark_OR.rxindex).getText();
			String rxtextinp = dataTable.getData("General_Data", "rxidentext");
			if(rxtext.equalsIgnoreCase(rxtextinp))
			{
				report.updateTestLog("Rx Benefit  Mgr identification Text", "Rx Benefit  manager identification Text are  displayed in Back of ID card", Status.PASS);						
			}
			else
			{
				report.updateTestLog("Rx Benefit  Mgr identification Text", "Rx Benefit  manager identification Text are not displayed in Back of ID card", Status.FAIL);			
			}	
		}

		//String entityTagline = dataTable.getData("General_Data", "entityTagline");
		int actualTaglinetext=driver.findElements(MyWellmark_OR.tagLine).size();
		if(actualTaglinetext==1)
		{
			report.updateTestLog("Entity Tagline", "Entity Tagline is  displayed in Back of ID card", Status.PASS);						
		}
		else
		{
			report.updateTestLog("Entity Taglinet", "Entity Tagline is  not displayed in Back of ID card", Status.FAIL);			
		}
	}
	public void idcardfrontlayout_synergy()
	{	
		List<WebElement> idcardlinks=driver.findElements(MyWellmark_OR.IDcardsLink);
		if(idcardlinks.size()!=0)
		{
			idcardlinks.get(0).click();	
			idcardlinks.get(0).sendKeys(Keys.ARROW_DOWN);
			idcardlinks.get(0).sendKeys(Keys.ARROW_DOWN);
			idcardlinks.get(0).sendKeys(Keys.ARROW_DOWN);
		}
		int frontlogo=driver.findElements(MyWellmark_OR.idcardfrontlogo).size();
		int backlogo=driver.findElements(MyWellmark_OR.idcardbacklogo).size();
		if(frontlogo==1&&backlogo==1)
		{
			report.updateTestLog("BCBS Logo", " Blue Cross Blue shield Logo is displayed in the Front and back side of the ID card", Status.PASS);

		}
		else
		{
			report.updateTestLog("BCBS Logo", " Blue Cross Blue shield Logo is displayed in the Front and back side of the ID card", Status.FAIL);
		}
		String plancodedisp=driver.findElement(MyWellmark_OR.plancode).getText();
		String plancode = dataTable.getData("General_Data", "plancode");
		if(plancodedisp.equalsIgnoreCase(plancode))
		{
			report.updateTestLog("Plan Code", "Plan Code is  displayed in front of the ID card", Status.PASS);					
		}
		else
		{
			report.updateTestLog("Benefit Info", "Plan Code is   not displayed in front of the ID card", Status.FAIL);
		}		
		String benefittext=driver.findElement(MyWellmark_OR.benefitinfo).getText();
		String benefit = dataTable.getData("General_Data", "benefitinfo");
		if(benefittext.equalsIgnoreCase(benefit))
		{
			report.updateTestLog("Benefit Info", "Benefit Information content is  displayed in front of the ID card", Status.PASS);					
		}
		else
		{
			report.updateTestLog("Benefit Info", "Benefit Information content is  not displayed in front of the ID card", Status.FAIL);
		}		
		String rxbin = dataTable.getData("General_Data", "rxbin");
		String rxpcn = dataTable.getData("General_Data", "rxpcn");
		String rxgrp = dataTable.getData("General_Data", "rxgrp");
		String rxbindisp= driver.findElement(MyWellmark_OR.idcardBIN).getText();
		String rxpcndisp= driver.findElement(MyWellmark_OR.idcardPCN).getText();
		String rxgrpdisp= driver.findElement(MyWellmark_OR.idcardGrp).getText();
		if (rxbin.equalsIgnoreCase(rxbindisp)&&rxpcn.equalsIgnoreCase(rxpcndisp)&&rxgrp.equalsIgnoreCase(rxgrpdisp))
		{
			report.updateTestLog("Rx Details", " RxBIN, RxPCN and RxGrp Details are displayed  in Front of ID card ", Status.PASS);

		}
		else
		{
			report.updateTestLog("Rx Details", " RxBIN, RxPCN and RxGrp Details are not displayed  in Front of ID card", Status.FAIL);
		}
		int nosuitcaseimage=driver.findElements(MyWellmark_OR.suitCaseCheck).size();
		if(nosuitcaseimage==1)
		{
			report.updateTestLog("Suit Case Image","No suitcase image is displayed in the Front side of the ID card", Status.PASS);

		}
		else
		{
			report.updateTestLog("Suit Case Image", "Suitcase image displayed in the Front  side of the ID card", Status.FAIL);
		}
		String Groupno=driver.findElement(MyWellmark_OR.idcardgroupno).getText();
		String wid=driver.findElement(MyWellmark_OR.idno).getText();
		dataTable.putData("General_Data", "Group_Number", Groupno);
		dataTable.putData("General_Data", "Wellmark_Id", wid);
		String memname=driver.findElement(MyWellmark_OR.idcardname).getText();
		dataTable.putData("General_Data", "PolicyHolder_Name", memname);			
	}
	public void invokeEVBI()
	{
		String evbiurl=dataTable.getData("General_Data", "EVBI_Url");
		String LoginPageTitle=dataTable.getData("General_Data", "EVBI_PageTitle");
		driver.manage().deleteAllCookies();
		driver.navigate().to(evbiurl);
		String PageTitleLoaded = driver.getTitle();
		if (PageTitleLoaded.equals(LoginPageTitle)) {
			report.updateTestLog("Invoke Application - EVBI", "Invoke Application Successful", Status.PASS);
		} 
		else {
			report.updateTestLog("Invoke Application - EVBI", "Invoke Application Unsuccessful", Status.FAIL);
		}
		String userName=dataTable.getData("General_Data", "EVBI_UserName");
		String usercred[]=userName.split(";");
		driverUtil.waitFor(2000);
		driver.findElement(MyWellmark_OR.txtUsername).sendKeys(usercred[0]);
		driver.findElement(MyWellmark_OR.txtPassword).sendKeys(usercred[1]);
		performAction(MyWellmark_OR.btnLogin, "SCROLLANDCLICK","" );
		driverUtil.waitFor(2000);
		if (MyWellmark_OR.welcomeevbi != null) {
			report.updateTestLog("Login Application", "Login Successful", Status.PASS);
		} else {
			report.updateTestLog("Login Application", "Login not Successful", Status.FAIL);
		}
	}
	public void validateEVBI_MemberDetails()
	{
		String memberIdText=dataTable.getData("General_Data", "Wellmark_Id");
		String memberName=dataTable.getData("General_Data", "PolicyHolder_Name");
		String groupNumber=dataTable.getData("General_Data", "Group_Number");
		String wellmarkId=dataTable.getData("General_Data", "Wellmark_Id");
		String customerServiceNumber=dataTable.getData("General_Data", "CustomerServiceNumber");
		String memberId=memberIdText.replaceAll("[/D]{3}", "");	
		int viewEliLink = driver.findElements(MyWellmark_OR.link_viewEligBen).size();
		if (viewEliLink==1) {
			performAction(MyWellmark_OR.link_viewEligBen, "SCROLLANDCLICK", "");
			waitFor(10, MyWellmark_OR.membreno);
		}
		performAction(MyWellmark_OR.membreno,"SENDKEYS",memberId);
		performAction(MyWellmark_OR.searchbutton,"click","");
		waitFor(10, MyWellmark_OR.table_EVBIactive);
		int tablesize=driver.findElements(MyWellmark_OR.link_ActiveContracts).size();
		for (int i=2;i<=tablesize;i++)
		{
			String policyhldtext=driver.findElement(By.xpath("//td/font[contains(text(),'Active Contracts for Search Date')]/following::tbody[1]/tr["+i+"]/td[5]")).getText();
			if(policyhldtext.equalsIgnoreCase("Policy Holder"))
			{
				WebElement emplink =driver.findElement(By.xpath("//td/font[contains(text(),'Active Contracts for Search Date')]/following::tbody[1]/tr["+i+"]/td[1]/a"));
				int empSize=driver.findElements(By.xpath("//td/font[contains(text(),'Active Contracts for Search Date')]/following::tbody[1]/tr["+i+"]/td[1]/a")).size();
				if(empSize==1)
				{
					emplink.click();
					if (waitFor(30, MyWellmark_OR.lbl_EnrInfo)==false) {
						driver.navigate().refresh();
						waitFor(30, MyWellmark_OR.lbl_EnrInfo);
					}

					break;
				}
				else
					report.updateTestLog("Member Link", "Member Link is not visible", Status.FAIL);
			}
		}
		//driver.findElement(By.xpath("(//td/font[contains(text(),'Active Contracts for Search Date')]/following::a[contains(text(),'"+memberName+"')])[1]")).click();
		//driverUtil.waitFor(15000);			
		String memberName_EVBI=driver.findElement(MyWellmark_OR.membername).getText().trim();
		String wellmarkId_EVBI=driver.findElement(MyWellmark_OR.policyholderid).getText().replace(" ", "");
		String groupNumberText_EVBI=driver.findElement(MyWellmark_OR.groupno).getText().trim();
		String customerServiceNumber_EVBI=driver.findElement(MyWellmark_OR.customerno).getText().trim();
		String groupNumber_EVBI=groupNumberText_EVBI.split("-")[0];

		if(customerServiceNumber.equalsIgnoreCase(customerServiceNumber_EVBI)){
			report.updateTestLog("Customer Service Number Check", "Customer Service number present in the myWellmark   matches with EVBI", Status.PASS);
		}
		else {
			report.updateTestLog("Customer Service Number Check", "Customer Service number present in the myWellmark  doesnt matches with EVBI", Status.FAIL);
		}
		if(memberName.equalsIgnoreCase(memberName_EVBI)){
			report.updateTestLog("Member Name", "Member Name present in the myWellmark   matches with EVBI", Status.PASS);
		}
		else {
			report.updateTestLog("Member Name", "Member Name present in the myWellmark  doesnt matches with EVBI", Status.FAIL);
		}
		if(wellmarkId.equalsIgnoreCase(wellmarkId_EVBI)){
			report.updateTestLog("WellmarkId", "WellmarkId present in the myWellmark   matches with EVBI", Status.PASS);
		}
		else {
			report.updateTestLog("WellmarkId", "WellmarkId present in the myWellmark  doesnt matches with EVBI", Status.FAIL);
		}
		if(groupNumber.equalsIgnoreCase(groupNumber_EVBI)){
			report.updateTestLog("Group Number", "Group Number present in the myWellmark   matches with EVBI", Status.PASS);
		}
		else {
			report.updateTestLog("Group Number", "Group Number present in the myWellmark  doesnt matches with EVBI", Status.FAIL);
		}
	}
	public String findSubscriber() throws ClassNotFoundException, SQLException{
		String query = dataTable.getData("General_Data", "TestCase_Query");
		ArrayList<String> subscriberList = new ArrayList<String>();
		ResultSet result1 = executeQuery(query);
		String subsId = null;
		while(result1.next()){
			subscriberList.add(result1.getString("SBSB_ID"));
		}
		String mangoDBQuery = dataTable.getData("General_Data", "MangoDB_Query");
		for(int i=0;i<subscriberList.size();i++){
			mangoDBQuery.replace("<<SBSB_ID>>", subscriberList.get(i));
			ResultSet result2 = executeQuery(mangoDBQuery);
			while(result2.next()){
				subsId = result2.getString("SBSB_ID").trim();
				if(subsId.equals(subscriberList.get(i).trim())){
					break;
				}
			}
		}
		return subsId;
	}
	public void dentalIdCard_FrontSideValidation(){
		if(driver.isElementVisible(MyWellmark_OR.dental_IdCardFrontLogo)){
			report.updateTestLog("BCBS Logo", " Blue Cross Blue shield Logo is displayed in the Front side of the ID card", Status.PASS);
		}
		else
		{
			report.updateTestLog("BCBS Logo", " Blue Cross Blue shield Logo is not displayed in the Front side of the ID card", Status.FAIL);
		}
		String memberName=driver.findElement(MyWellmark_OR.dental_IdCardName).getText();
		if(memberName!=null){
			dataTable.putData("General_Data", "PolicyHolder_Name", memberName);
			report.updateTestLog("PolicyHolderName", "PolicyHolderName is displayed in the Front side of the ID card", Status.PASS);
		}
		else
		{
			report.updateTestLog("PolicyHolderName", "PolicyHolderName is not displayed in the Front side of the ID card", Status.FAIL);
		}
		String wellmark_Id=driver.findElement(MyWellmark_OR.dental_IdNo).getText();
		if(wellmark_Id!=null){
			dataTable.putData("General_Data", "Wellmark_Id", wellmark_Id);
			report.updateTestLog("Wellmark ID", "Wellmark ID is displayed in the Front side of the ID card", Status.PASS);
		}
		else
		{
			report.updateTestLog("Wellmark ID", "Wellmark ID is not displayed in the Front side of the ID card", Status.FAIL);
		}
		String groupNumber=driver.findElement(MyWellmark_OR.dental_IdCardGroupNo).getText();
		if(groupNumber!=null){
			dataTable.putData("General_Data", "Group_Number", groupNumber);
			report.updateTestLog("Group Number", "Group Number is displayed in the Front side of the ID card", Status.PASS);
		}
		else
		{
			report.updateTestLog("Group Number", "Group Number is not displayed in the Front side of the ID card", Status.FAIL);
		}
		String planCodeDisplayed=driver.findElement(MyWellmark_OR.dental_IdCardPlanCode).getText();
		String plancode = dataTable.getData("General_Data", "plancode");
		if(planCodeDisplayed.equalsIgnoreCase(plancode)){
			report.updateTestLog("Plan Code", "Plan Code is displayed in the Front side of the ID card", Status.PASS);
		}
		else
		{
			report.updateTestLog("Plan Code", "Plan Code is not displayed in the Front side of the ID card", Status.FAIL);
		}
		String benefitInfo=driver.findElement(MyWellmark_OR.dental_BenefitInfo).getText();
		if(benefitInfo!=null){
			report.updateTestLog("Benefit Information", "Benefit Information is displayed in the Front side of the ID card", Status.PASS);
		}
		else
		{
			report.updateTestLog("Benefit Information", "Benefit Information is not displayed in the Front side of the ID card", Status.FAIL);
		}
		if(driver.isElementNotVisible(MyWellmark_OR.dental_SuitCaseImage)){
			report.updateTestLog("SuitCase Image", "SuitCase Image is not displayed in the Front side of the ID card", Status.PASS);
		}
		else
		{
			report.updateTestLog("SuitCase Image", "SuitCase Image is displayed in the Front side of the ID card", Status.PASS);
		}
	}
	public void dentalIdCard_BackSideValidation(){
		if(driver.isElementVisible(MyWellmark_OR.dental_IdCardBackLogo)){
			report.updateTestLog("BCBS Logo", " Blue Cross Blue shield Logo is displayed in the Back side of the ID card", Status.PASS);
		}
		else
		{
			report.updateTestLog("BCBS Logo", " Blue Cross Blue shield Logo is not displayed in the Back side of the ID card", Status.FAIL);
		}
		if(driver.isElementVisible(MyWellmark_OR.dental_Website)){
			report.updateTestLog("Wellmark URL", "Wellmark URL is displayed in the Back side of the ID card", Status.PASS);
		}
		else
		{
			report.updateTestLog("Wellmark URL", "Wellmark URL is not displayed in the Back side of the ID card", Status.FAIL);
		}
		if(driver.isElementVisible(MyWellmark_OR.dental_CustNo)){
			String customerServiceNumber = driver.findElement(MyWellmark_OR.dental_CustNo).getText();
			dataTable.putData("General_Data", "CustomerServiceNumber", customerServiceNumber);
			report.updateTestLog("Customer Service Number", "Customer Service Number is displayed in the Back side of the ID card", Status.PASS);
		}
		else
		{
			report.updateTestLog("Customer Service Number", "Customer Service Number is not displayed in the Back side of the ID card", Status.FAIL);
		} 
		if(driver.isElementVisible(MyWellmark_OR.dental_InsTextMembers) && driver.isElementVisible(MyWellmark_OR.dental_InsTextProviders)){
			report.updateTestLog("Instruction text", " Instruction text for Members/Providers is displayed in the Back side of the ID card", Status.PASS);
		}
		else
		{
			report.updateTestLog("Instruction text", " Instruction text for Members/Providers is not displayed in the Back side of the ID card", Status.FAIL);
		}
		if(driver.isElementVisible(MyWellmark_OR.dental_TagLine)){
			report.updateTestLog("Entity TagLine", "Entity TagLine is displayed in the Back side of the ID card", Status.PASS);
		}
		else
		{
			report.updateTestLog("Entity TagLine", "Entity TagLine is not displayed in the Back side of the ID card", Status.FAIL);
		} 
	}
	public String randomIdentifier() {
		final String lexicon = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		final java.util.Random rand = new java.util.Random();
		// consider using a Map<String,Boolean> to say whether the identifier is being used or not 
		final Set<String> identifiers = new HashSet<String>();
		StringBuilder builder = new StringBuilder();
		while(builder.toString().length() == 0) {
			int length = rand.nextInt(5)+5;
			for(int i = 0; i < length; i++) {
				builder.append(lexicon.charAt(rand.nextInt(lexicon.length())));
			}
			if(identifiers.contains(builder.toString())) {
				builder = new StringBuilder();
			}
		}
		return builder.toString();
	}

	public void openDBConnection(String dbURL,String uName,String pswd){

		try {
			//load oracle jdbc driver
			Class.forName("oracle.jdbc.driver.OracleDriver");
			//create connection to db
			con=DriverManager.getConnection(dbURL, uName, pswd);
			//create statement object
			stmt=con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
		} catch (Exception e) {
			report.updateTestLog("Error in DB connection",e.getMessage()+" "+e.getClass(), Status.FAIL);
			try {
				//close connection
				con.close();
			} catch (Exception e1) {
				report.updateTestLog("Error closing connection to DB",e1.getMessage()+" "+e1.getClass(), Status.FAIL);
			}			
		}		
	}

	public ResultSet getRecordSet(String query){
		try{
			//execute the sql query n store results in resultset
			rs=stmt.executeQuery(query);			
		} catch (Exception e) {
			report.updateTestLog("Error in DB query",e.getMessage()+" "+e.getClass(), Status.FAIL);
			try {
				//close connection
				con.close();
			} catch (Exception e1) {
				report.updateTestLog("Error closing connection to DB",e1.getMessage()+" "+e1.getClass(), Status.FAIL);
			}			
		}			
		return rs;
	}

	public void closeDBConnection(){
		try {
			//close connection
			con.close();
		} catch (Exception e1) {
			report.updateTestLog("Error closing connection to DB",e1.getMessage(), Status.FAIL);
		}
	}
	/**
	 * Description    :   Function to Connect FacetsDB
	 * Return Value   :   Connection
	 * Created By     :   Gandhimathi
	 * Created Date   :   11/27/2017 
	 * @return
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 */
	public Connection connectToFacetsDB() throws SQLException, ClassNotFoundException{
		// Create a variable for the connection string.   63.145.102.62,11001
		String DBServer = dataTable.getData("General_Data","DBServer");
		String DBName = dataTable.getData("General_Data","DBName");
		String DBUsername = dataTable.getData("General_Data","DBUsername");
		String DBPassword = dataTable.getData("General_Data","DBPassword");
		String connectionUrl = DBServer+";databaseName=" + DBName+";user="+DBUsername+";password="+DBPassword;
		// Declare the JDBC objects.  
		Connection con = null;  
		try {  
			// Establish the connection.  
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");  
			con = DriverManager.getConnection(connectionUrl); 
		}  

		catch (ClassNotFoundException e) {  
			throw e;  
		}  
		return con;
	}

	public Connection connectToFacetsDB_Mongo(String curTCName_Mongo) throws SQLException, ClassNotFoundException, NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException{
		// Create a variable for the connection string.   63.145.102.62,11001
		String DBServer = getmongoData(curTCName_Mongo, "General_Data", "DBServer");
		String DBName = getmongoData(curTCName_Mongo, "General_Data", "DBName");
		String DBUsername = getmongoData(curTCName_Mongo, "General_Data", "DBUsername");
		String DBPassword = getmongoData(curTCName_Mongo, "General_Data", "DBPassword"); 
		String connectionUrl = DBServer+";databaseName=" + DBName+";user="+DBUsername+";password="+DBPassword;
		// Declare the JDBC objects.  
		Connection con = null;  
		try {  
			// Establish the connection.  
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");  
			con = DriverManager.getConnection(connectionUrl); 
		}  

		catch (ClassNotFoundException e) {  
			throw e;  
		}  
		return con;
	}

	// Create and execute an SQL statement that returns some data. 
	public ResultSet executeQuery(String sql) throws SQLException, ClassNotFoundException{
		Statement stmt = null;  
		ResultSet rs = null;  
		Connection con = null;
		try{
			con = connectToFacetsDB(); 
			stmt = con.createStatement();  
			rs = stmt.executeQuery(sql);  
		}  
		catch (SQLException e) {  
			throw e;  
		} 
		return rs;
	}

	// Create and execute an SQL statement that returns some data. 
	public ResultSet executeQuery_facets(String sql) throws SQLException, ClassNotFoundException{
		Statement stmt = null;  
		ResultSet rs = null;  
		Connection con = null;
		try{
			con = connectToFacetsDB(); 
			stmt = con.createStatement();  
			rs = stmt.executeQuery(sql);  
		}  
		catch (SQLException e) {  
			throw e;  
		} 
		return rs;
	}
	public ResultSet executeQuery_facets_Mongo(String curTCName_Mongo,String sql) throws SQLException, ClassNotFoundException, NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException{
		Statement stmt = null;  
		ResultSet rs = null;  
		Connection con = null;
		try{
			con = connectToFacetsDB_Mongo(curTCName_Mongo); 
			stmt = con.createStatement();  
			rs = stmt.executeQuery(sql);  
		}  
		catch (SQLException e) {  
			throw e;  
		} 
		return rs;
	}


	/*** Aravinth - START ***/
	public boolean findElement(By element){
		try {
			int elementProp = driver.findElements(element).size();
			if (elementProp==1) {
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;

	}

	public boolean waitFor(int WaitTime, By element_optional){
		boolean WebElementPresence = false;

		if (element_optional == null) {
			driver.manage().timeouts().implicitlyWait(WaitTime, TimeUnit.MILLISECONDS);
		} else {
			//WebElement element = driver.findElement(element_optional);
			try{
				FluentWait<WebDriver>fluwait = new FluentWait<WebDriver>(driver.getWebDriver())
						.withTimeout(WaitTime, TimeUnit.SECONDS)
						.pollingEvery(3, TimeUnit.SECONDS)
						.ignoring(NoSuchElementException.class);

				fluwait.until(ExpectedConditions.visibilityOf(driver.findElement(element_optional)));
				if (findElement(element_optional)) {
					WebElementPresence = true;
				}

			}catch(Exception e){
				WebElementPresence = false;
			}

		}
		return WebElementPresence;


	}

	public Collection<String> getAllMemberDetails(String sid){
		String query = dataTable.getData("General_Data", "ExtractQuery");
		String dbServer = dataTable.getData("General_Data", "DBServer");
		String dbUsername = dataTable.getData("General_Data", "DBUsername");
		String dbPassword = dataTable.getData("General_Data", "DBPassword");
		String dbName = dataTable.getData("General_Data", "DBName");

		query = query.replace("<<SBSB_ID>>", sid);
		openDBConnection(dbServer +  
				"databaseName=" + dbName,dbUsername,dbPassword);
		ResultSet rs = getRecordSet(query);



		try {
			while(rs.next()) {
				sbsbid = rs.getString("SBSB_ID").trim();
				lastname = rs.getString("MEME_LAST_NAME").trim();
				firstname = rs.getString("MEME_FIRST_NAME").trim();
				ssn = rs.getString("MEME_SSN").trim();
				dob = rs.getString("MEME_BIRTH_DT").trim();
				zipcode = rs.getString("SBAD_ZIP").trim();
				phone = rs.getString("SBAD_PHONE").trim();

				//Store all the user information
				//Adding SID as KEY and all values as VALUE
				myMultimap.put(sbsbid, firstname + " " + lastname);
				//If we want, we can even add the rest of elements to the same SID as well

				//Getting values
				SIDmap = myMultimap.get(sid);

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return SIDmap;

	}

	public Collection<String> getActiveContracts(String sid){
		HtmlUnitDriver unitDriver = new HtmlUnitDriver();
		/*driver.manage().deleteAllCookies();
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\CN06299\\ApplicationRepos\\MyWellmark\\commonComponents\\libraries\\chromedriver.exe");
		WebDriver driver_asdf = new ChromeDriver();
		WebDriver unitDriver = driver_asdf;*/

		String evbiurl=dataTable.getData("General_Data", "EVBI_Url");
		//String LoginPageTitle="Log In Page | Wellmark Blue Cross and Blue Shield";
		unitDriver.navigate().to(evbiurl);
		unitDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		String userName=dataTable.getData("General_Data", "EVBI_UserName");
		String usercred[]=userName.split(";");
		unitDriver.findElement(MyWellmark_OR.txtUsername).sendKeys(usercred[0]);
		unitDriver.findElement(MyWellmark_OR.txtPassword).sendKeys(usercred[1]);
		unitDriver.findElement(MyWellmark_OR.btnLogin).click();
		unitDriver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		unitDriver.findElement(MyWellmark_OR.membreno).sendKeys(sid);
		unitDriver.findElement(MyWellmark_OR.searchbutton).click();
		unitDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		//Get Active Member names
		List<WebElement> memNames = unitDriver.findElements(MyWellmark_OR.lbl_ActiveMems);
		System.out.println(memNames.size());
		//Clears the corresponding cell
		dataTable.putData("General_Data", "PolicyHolder_Name", "");
		int x = 1;
		for (WebElement webElement : memNames) {
			String txt_memName = webElement.getText().trim();
			String txt_memSID = unitDriver.findElement(MyWellmark_OR.lbl_ActiveMem_SID).getText().trim();
			String txt_memPH = unitDriver.findElement(By.xpath("(//table[@rules='all' and .//td[contains(.,'Active')]]//following-sibling::tbody//tr//td[5])[" + x + "]")).getText().trim();
			int ttlmems = dataTable.getData("General_Data", "PolicyHolder_Name").split(";").length;
			myMultimap.put(txt_memSID, txt_memName);

			//Getting values
			SIDmap = myMultimap.get(sid);
			if (ttlmems != 2) {
				if (txt_memPH.equalsIgnoreCase("Policy Holder")) {
					dataTable.putData("General_Data", "PolicyHolder_Name", txt_memName);
				} else {
					String oldData = dataTable.getData("General_Data", "PolicyHolder_Name").trim() + 
							";" + txt_memName;
					dataTable.putData("General_Data", "PolicyHolder_Name", oldData);
				}
			}
			x++;
		}
		//Kill all UNIT DRIVER process
		unitDriver.manage().deleteAllCookies();
		unitDriver.quit();
		return SIDmap;

	}

	@SuppressWarnings("null")
	public void searchPolicy_NonPolicyDetails(){

		String[] memberName_Split = null;
		String subsId = dataTable.getData("General_Data", "SSN/SID");
		String memberName=dataTable.getData("General_Data", "PolicyHolder_Name").trim();

		String[] splitbtnPol_NonPol = memberName.split(";");

		int viewEliLink = driver.findElements(MyWellmark_OR.link_viewEligBen).size();
		if (viewEliLink==1) {
			performAction(MyWellmark_OR.link_viewEligBen, "SCROLLANDCLICK", "");
			waitFor(10, MyWellmark_OR.membreno);
		}
		performAction(MyWellmark_OR.membreno,"SENDKEYS",subsId);
		performAction(MyWellmark_OR.searchbutton,"click","");
		waitFor(20, MyWellmark_OR.lbl_ActiveMem_Header);

		String Rem_Ded_Ind_EVBI_Arradd = null;
		String Satfd_Ded_Ind_EVBI_Arradd = null;
		String Limit_Ded_Ind_EVBI_Arradd = null;
		String Rem_OOP_Ind_EVBI_Arradd = null;
		String Satfd_OOP_Ind_EVBI_Arradd = null;
		String Limit_OOP_Ind_EVBI_Arradd = null;

		ArrayList<String> Rem_Ded_Ind_EVBI = new ArrayList<>();
		ArrayList<String> Satfd_Ded_Ind_EVBI = new ArrayList<>();
		ArrayList<String> Limit_Ded_Ind_EVBI = new ArrayList<>();
		ArrayList<String> Rem_OOP_Ind_EVBI = new ArrayList<>();
		ArrayList<String> Satfd_OOP_Ind_EVBI = new ArrayList<>();
		ArrayList<String> Limit_OOP_Ind_EVBI = new ArrayList<>();

		for (int z = 0; z < splitbtnPol_NonPol.length; z++) {

			String getHoldernames = splitbtnPol_NonPol[z].trim();
			memberName_Split = getHoldernames.split(" ");

			//Clicks on appropriate member w.r.to the member given in datatable
			performAction(By.xpath("//table[@rules='all' and .//td[contains(.,'Active')]]//following-sibling::tbody//tr//td[1]//a[contains(.,'" + memberName_Split[0].trim() + "')][contains(.,'" + memberName_Split[1].trim() + "')]"), "SCROLLANDCLICK", "");
			waitFor(30, MyWellmark_OR.lbl_ViewEligBen);

			//Individual_Deductibles
			Rem_Ded_Ind_EVBI_Arradd = driver.findElement(MyWellmark_OR.lbl_Rem_Ded_Ind_EVBI).getText().trim();
			Satfd_Ded_Ind_EVBI_Arradd = driver.findElement(MyWellmark_OR.lbl_Satfd_Ded_Ind_EVBI).getText().trim();
			Limit_Ded_Ind_EVBI_Arradd = driver.findElement(MyWellmark_OR.lbl_Limit_Ded_Ind_EVBI).getText().trim();

			//Individual_OOP
			Rem_OOP_Ind_EVBI_Arradd = driver.findElement(MyWellmark_OR.lbl_Rem_OOP_Ind_EVBI).getText().trim();
			Satfd_OOP_Ind_EVBI_Arradd = driver.findElement(MyWellmark_OR.lbl_Satfd_OOP_Ind_EVBI).getText().trim();
			Limit_OOP_Ind_EVBI_Arradd = driver.findElement(MyWellmark_OR.lbl_Limit_OOP_INd_EVBI).getText().trim();

			/*//Family_Deductibles
			String Rem_Ded_Fam = driver.findElement(By.xpath("(//table//th[contains(.,'Contract Accumulations')]/ancestor::table[@cellpadding='2']//tr[contains(.,'Deductible')]//td[contains(.,'Family')]//following-sibling::td)[7]")).getText().trim();
			String Satfd_Ded_Fam = driver.findElement(By.xpath("(//table//th[contains(.,'Contract Accumulations')]/ancestor::table[@cellpadding='2']//tr[contains(.,'Deductible')]//td[contains(.,'Family')]//following-sibling::td)[6]")).getText().trim();
			String Limit_Ded_Fam = driver.findElement(By.xpath("(//table//th[contains(.,'Contract Accumulations')]/ancestor::table[@cellpadding='2']//tr[contains(.,'Deductible')]//td[contains(.,'Family')]//following-sibling::td)[5]")).getText().trim();

			//Family_OOP
			String Rem_OOP_Fam = driver.findElement(By.xpath("(//table//th[contains(.,'Contract Accumulations')]/ancestor::table[@cellpadding='2']//tr[contains(.,'Out')]//td[contains(.,'Family')]//following-sibling::td)[7]")).getText().trim();
			String Satfd_OOP_Fam = driver.findElement(By.xpath("(//table//th[contains(.,'Contract Accumulations')]/ancestor::table[@cellpadding='2']//tr[contains(.,'Out')]//td[contains(.,'Family')]//following-sibling::td)[6]")).getText().trim();
			String Limit_OOP_Fam = driver.findElement(By.xpath("(//table//th[contains(.,'Contract Accumulations')]/ancestor::table[@cellpadding='2']//tr[contains(.,'Out')]//td[contains(.,'Family')]//following-sibling::td)[5]")).getText().trim();
			 */


			//Add all to Collections
			Rem_Ded_Ind_EVBI.add(Rem_Ded_Ind_EVBI_Arradd);
			Satfd_Ded_Ind_EVBI.add(Satfd_Ded_Ind_EVBI_Arradd);
			Limit_Ded_Ind_EVBI.add(Limit_Ded_Ind_EVBI_Arradd);
			Rem_OOP_Ind_EVBI.add(Rem_OOP_Ind_EVBI_Arradd);
			Satfd_OOP_Ind_EVBI.add(Satfd_OOP_Ind_EVBI_Arradd);
			Limit_OOP_Ind_EVBI.add(Limit_OOP_Ind_EVBI_Arradd);

			//Navigate back to get non policy holder as well

			performAction(MyWellmark_OR.lnk_ReturntoSearchResults_EVBI, "SCROLLANDCLICK", "");
			driverUtil.waitFor(1000);



		}

		//Log back to MyWellmark URL
		driver.manage().deleteAllCookies();
		invokeApplication();
		enterCredentials();


		//Navigating to that dropdown in Ded & Max page
		//Clicks on Coverage link
		performAction(MyWellmark_OR.link_Sidenav_Coverage, "SCROLLANDCLICK", "");
		//Selects Medical tab if not
		if (findElement(MyWellmark_OR.link_Med_Cov)==false) {
			performAction(MyWellmark_OR.link_Med_Cov, "SCROLLANDCLICK", "");
		}

		if (findElement(MyWellmark_OR.link_Med_Ded_Max)==true) {
			performAction(MyWellmark_OR.link_Med_Ded_Max, "SCROLLANDCLICK", "");
			waitFor(10, MyWellmark_OR.lbl_DedPage);
		}

		//Iterating for UI values fir Policy and Non Policy Holders
		String Rem_Ded_Ind_UI_Arradd = null;
		String Satfd_Ded_Ind_UI_Arradd = null;
		String Limit_Ded_Ind_UI_Arradd = null;
		String Rem_OOP_Ind_UI_Arradd = null;
		String Satfd_OOP_Ind_UI_Arradd = null;
		String Limit_OOP_Ind_UI_Arradd = null;

		ArrayList<String> Rem_Ded_Ind_UI = new ArrayList<>();
		ArrayList<String> Satfd_Ded_Ind_UI = new ArrayList<>();
		ArrayList<String> Limit_Ded_Ind_UI = new ArrayList<>();
		ArrayList<String> Rem_OOP_Ind_UI = new ArrayList<>();
		ArrayList<String> Satfd_OOP_Ind_UI = new ArrayList<>();
		ArrayList<String> Limit_OOP_Ind_UI = new ArrayList<>();

		for (int y = 0; y < splitbtnPol_NonPol.length; y++) {

			String getHoldernames = splitbtnPol_NonPol[y].trim();
			memberName_Split = getHoldernames.split(" ");

			//Checks for Deductibles and Max drpdown
			if (findElement(MyWellmark_OR.drp_DedMax)==true) {
				int memberName_Split_length = memberName_Split[0].trim().length();
				String only_FN_Proper = memberName_Split[0].substring(0, 1).toUpperCase() + memberName_Split[0].substring(1, memberName_Split_length).toLowerCase();
				//System.out.println(only_FN_Proper);

				//selectValueFromDropdownForGivenTextContains(by, textToBeSelected);
				//Selecting the same policy/non policy holder member in drop down
				selectValueFromDropdownForGivenText(MyWellmark_OR.drp_DedMax, only_FN_Proper.trim());
				waitFor(10, MyWellmark_OR.lbl_DedFor);
			}


			//Cross verifying Amount Remaining and Amount Satisfied
			//Individual_Ded_UI
			Rem_Ded_Ind_UI_Arradd = driver.findElement(MyWellmark_OR.lbl_Rem_Ded_Ind_UI).getText().replace("Amount Remaining:", "").trim();
			Satfd_Ded_Ind_UI_Arradd = driver.findElement(MyWellmark_OR.lbl_Satfd_Ded_Ind_UI).getText().trim();
			Limit_Ded_Ind_UI_Arradd = driver.findElement(MyWellmark_OR.lbl_Limit_Ded_Ind_UI).getText().replace("Deductible Limit:", "").trim();

			//Individual_OOP_UI
			Rem_OOP_Ind_UI_Arradd = driver.findElement(MyWellmark_OR.lbl_Rem_OOP_Ind_UI).getText().replace("Amount Remaining:", "").trim();
			Satfd_OOP_Ind_UI_Arradd = driver.findElement(MyWellmark_OR.lbl_Satfd_OOP_Ind_UI).getText().trim();
			Limit_OOP_Ind_UI_Arradd = driver.findElement(MyWellmark_OR.lbl_Limit_OOP_INd_UI).getText().replace("Out-of-Pocket Maximum:", "").trim();

			//Adding all to collections
			Rem_Ded_Ind_UI.add(Rem_Ded_Ind_UI_Arradd);
			Satfd_Ded_Ind_UI.add(Satfd_Ded_Ind_UI_Arradd);
			Limit_Ded_Ind_UI.add(Limit_Ded_Ind_UI_Arradd);
			Rem_OOP_Ind_UI.add(Rem_OOP_Ind_UI_Arradd);
			Satfd_OOP_Ind_UI.add(Satfd_OOP_Ind_UI_Arradd);
			Limit_OOP_Ind_UI.add(Limit_OOP_Ind_UI_Arradd);

		}



		if (Rem_Ded_Ind_UI.equals(Rem_Ded_Ind_EVBI)) {
			report.updateTestLog("Individual_Amount Remaining", "Amount matched successful", Status.PASS);
		} else {
			report.updateTestLog("Individual_Amount Remaining", "Amount mismatched", Status.FAIL);
		}
		if (Satfd_Ded_Ind_UI.equals(Satfd_Ded_Ind_EVBI)) {
			report.updateTestLog("Individual_Amount Satisfied", "Amount matched successful", Status.PASS);
		} else {
			report.updateTestLog("Individual_Amount Satisfied", "Amount mismatched", Status.FAIL);
		}
		if (Limit_Ded_Ind_UI.equals(Limit_Ded_Ind_EVBI)) {
			report.updateTestLog("Individual_Deductible Limit", "Amount matched successful", Status.PASS);
		} else {
			report.updateTestLog("Individual_Deductible Limit", "Amount mismatched", Status.FAIL);
		}
		if (Rem_OOP_Ind_UI.equals(Rem_OOP_Ind_EVBI)) {
			report.updateTestLog("Individual_OOP_Amount Remaining", "Amount matched successful", Status.PASS);
		} else {
			report.updateTestLog("Individual_OOP_Amount Remaining", "Amount mismatched", Status.FAIL);
		}
		if (Satfd_OOP_Ind_UI.equals(Satfd_OOP_Ind_EVBI)) {
			report.updateTestLog("Individual_OOP_Amount Satisfied", "Amount matched successful", Status.PASS);
		} else {
			report.updateTestLog("Individual_OOP_Amount Satisfied", "Amount mismatched", Status.FAIL);
		}
		if (Limit_OOP_Ind_UI.equals(Limit_OOP_Ind_EVBI)) {
			report.updateTestLog("Individual_OOPMaximum", "Amount matched successful", Status.PASS);
		} else {
			report.updateTestLog("Individual_OOPMaximum", "Amount mismatched", Status.FAIL);
		}

		//Toggling OON button to view them
		performAction(MyWellmark_OR.toggle_OutNetwrk, "SCROLLANDCLICK", "");
		driverUtil.waitFor(1000);
		int OON_contents = driver.findElements(MyWellmark_OR.lbl_OONContents).size();
		if (OON_contents==2) {
			report.updateTestLog("OON Coverage", "OON Benefits got displayed on clicking OON toggle button", Status.PASS);
		}else{
			report.updateTestLog("OON Coverage", "OON Benefits not displayed", Status.FAIL);
		}

		//Member with no deductible - Script pending due to lack of data

		//Member with no OOP - Script pending due to lack of data



	}

	public void gotoCoverageLink(){
		//Clicks on Coverage link
		performAction(MyWellmark_OR.link_Sidenav_Coverage, "SCROLLANDCLICK", "");
		//Checks for Medical tab
		if (findElement(MyWellmark_OR.tab_Med_Cov)==true) {
			report.updateTestLog("Coverage_Medical Tab", "Medical Tab is displayed as default page in Benefit landing page", Status.PASS);
		} else {
			report.updateTestLog("Coverage_Medical Tab", "Medical Tab is not displayed in Benefit landing page", Status.FAIL);
		}
	}

	public void validate_ttlmem_Med_Ded_Max(){

		String subsId = dataTable.getData("General_Data", "SSN/SID");

		//Selects Medical tab if not
		if (findElement(MyWellmark_OR.link_Med_Cov)==false) {
			performAction(MyWellmark_OR.link_Med_Cov, "SCROLLANDCLICK", "");
		}
		//Checks for Ded & Maximum option only under Medical tab
		if (findElement(MyWellmark_OR.link_Med_Ded_Max)==true) {
			performAction(MyWellmark_OR.link_Med_Ded_Max, "SCROLLANDCLICK", "");
			waitFor(10, MyWellmark_OR.lbl_DedPage);
			report.updateTestLog("Deductible&Maximum_Medical Page", "Navigated to Deductibles & Maximum page successful", Status.PASS);
			//Checks for Deductibles and Max drpdown
			if (findElement(MyWellmark_OR.drp_DedMax)==true) {
				//Getting Policy holder information
				int ttl_MemDetails_DB = getActiveContracts(subsId).size(); //Used HTMLUNITDRIVER
				//Comparing Members with DB
				int ttl_MemDetails_UI = driver.findElements(MyWellmark_OR.drp_Med_Ded_Max).size()-1; //Minus 1 for default Family;
				if (ttl_MemDetails_UI == ttl_MemDetails_DB) {
					report.updateTestLog("Total Members", "Total number of members displayed in UI gets matched", Status.PASS);
					List<WebElement> UI_Ded_Max_Name = driver.findElements(MyWellmark_OR.drp_Med_Ded_Max);
					int j = 0;
					for (String string : SIDmap) {
						String[] onlyFN_Comp = string.split(" ");
						if ((onlyFN_Comp[0].trim()).equals(UI_Ded_Max_Name.get(j).getText().trim().toUpperCase())) {
							report.updateTestLog("Total Members_Name Match", "Total number of members and their names displayed in UI gets matched", Status.PASS);
						}else{
							report.updateTestLog("Total Members_Name Match", "Total number of members and their names displayed in UI not matched", Status.FAIL);
						}

						j++;
					}

				}else{
					report.updateTestLog("Total Members", "Total number of members displayed in UI not matched", Status.FAIL);
				}
			}else{
				report.updateTestLog("Deductibles & Maximums dropdown", "Deductibles & Maximums dropdown is displayed as expected", Status.FAIL);
			}
		}
	}

	public void validate_default_InNetwork_toggle(){
		//Checks for In Network and Out of network toggle button
		waitFor(10, MyWellmark_OR.link_View_Ded_Details);
		int togglebtnSize = driver.findElements(MyWellmark_OR.toggle_Med_Ded).size();
		if (togglebtnSize==2) {
			report.updateTestLog("In network and Out of network toggle", "In network and Out of network toggle button is present", Status.PASS);
			if (findElement(MyWellmark_OR.toggle_act_InNetwrk)==true) {
				report.updateTestLog("In network_By Default", "By Default In network contract accumulations selection is found", Status.PASS);
			} else {
				report.updateTestLog("In network_By Default", "By Default In network contract accumulations selection not found", Status.FAIL);
			}
		} else {
			report.updateTestLog("In network and Out of network toggle", "In network and Out of network toggle button not present", Status.FAIL);
		}
	}

	public void validate_DedDetails_Link(){
		//Checks for View Deductible Details link and access it
		if (findElement(MyWellmark_OR.link_View_Ded_Details)==true) {
			performAction(MyWellmark_OR.link_View_Ded_Details, "SCROLLANDCLICK", "");
			waitFor(10, MyWellmark_OR.modal_Ded_Details);
			if (findElement(MyWellmark_OR.modal_Ded_Details)==true) {
				report.updateTestLog("Deductible Details Modal", "Deductible Details modal window display successful", Status.PASS);
			} else {
				report.updateTestLog("Deductible Details Modal", "Deductible Details modal window display Unsuccessful", Status.FAIL);
			}
		} else {
			report.updateTestLog("Deductible Details Link", "Deductible Details link not present", Status.FAIL);
		}
		performAction(MyWellmark_OR.btn_DedDetails, "SCROLLANDCLICK", "");
		waitFor(10, MyWellmark_OR.link_View_Ded_Details);
	}

	public void validate_OOPMax_Link(){
		//Checks for OOP Maximum link and access it
		if (findElement(MyWellmark_OR.link_View_OOP_Max)==true) {
			performAction(MyWellmark_OR.link_View_OOP_Max, "SCROLLANDCLICK", "");
			waitFor(10, MyWellmark_OR.modal_OOPMax_Details);
			if (findElement(MyWellmark_OR.modal_OOPMax_Details)==true) {
				report.updateTestLog("OOP Maximum Details Modal", "OOP Maximum Details modal window display successful", Status.PASS);
			} else {
				report.updateTestLog("OOP Maximum Details Modal", "OOP Maximum Details modal window display Unsuccessful", Status.FAIL);
			}
		} else {
			report.updateTestLog("OOP Maximum Details Link", "OOP Maximum Details link not present", Status.FAIL);
		}

		performAction(MyWellmark_OR.btn_OOPMax, "SCROLLANDCLICK", "");
		waitFor(10, MyWellmark_OR.link_View_Ded_Details);
	}

	public void validate_NoDedCheck(){

		driver.manage().deleteAllCookies();
		invokeApplication();
		enterCredentials_NoDed();

		//Navigate to Coverage page
		gotoCoverageLink();

		//Checks for Ded & Maximum option only under Medical tab
		if (findElement(MyWellmark_OR.link_Med_Ded_Max)==true) {
			performAction(MyWellmark_OR.link_Med_Ded_Max, "SCROLLANDCLICK", "");
			waitFor(10, MyWellmark_OR.lbl_DedPage);
			report.updateTestLog("Deductible&Maximum_Medical Page", "Navigated to Deductibles & Maximum page successful", Status.PASS);
		}
		if (findElement(MyWellmark_OR.lbl_NoDed_DedMax)==true) {
			report.updateTestLog("No Deductibles", "Member with no deductibles displays the message", Status.PASS);
		} else {
			report.updateTestLog("No Deductibles", "Error message for no deductible not present,"
					+ "since the member has Deductible", Status.PASS);
		}
	}

	public void validate_NoOOPCheck(){

		driver.manage().deleteAllCookies();
		invokeApplication();
		enterCredentials_NoOOP();

		//Navigate to Coverage page
		gotoCoverageLink();

		//Checks for Ded & Maximum option only under Medical tab
		if (findElement(MyWellmark_OR.link_Med_Ded_Max)==true) {
			performAction(MyWellmark_OR.link_Med_Ded_Max, "SCROLLANDCLICK", "");
			waitFor(10, MyWellmark_OR.lbl_DedPage);
			report.updateTestLog("Deductible&Maximum_Medical Page", "Navigated to Deductibles & Maximum page successful", Status.PASS);
		}
		if (findElement(MyWellmark_OR.lbl_NoOOP_DedMax)==true) {
			report.updateTestLog("No OOP", "Member with no Out of pocket maximums displays the message", Status.PASS);
		} else {
			report.updateTestLog("No OOP", "Error message for no Out of pocket maximums not present,"
					+ "since the member has Out of pocket maximums", Status.PASS);
		}

	}

	public void validate_FindCare_Page(){
		//Clicks on Find Care tab
		performAction(MyWellmark_OR.link_Sidenav_FindCare, "SCROLLANDCLICK", "");
		waitFor(20, MyWellmark_OR.lbl_FindCare);

		String[]Estimatebtns = new String[]{"Medical Costs","Drug Costs"};
		int k = 0;

		List<WebElement> ttlEstimateCost_btns = driver.findElements(MyWellmark_OR.btn_CostEsti);
		for (WebElement webElement : ttlEstimateCost_btns) {
			//Medical Costs button
			if (k == 0) {
				if (webElement.getText().split("\\n")[0].trim().equalsIgnoreCase(Estimatebtns[k])) {
					report.updateTestLog("Medical Costs button", "Medical Costs button is displayed in the cost estimator widget"
							, Status.PASS);
				} else {
					report.updateTestLog("Medical Costs button", "Medical Costs button not found in the cost estimator widget"
							, Status.FAIL);
				}
			}

			if (k == 1) {
				//Drug Costs button
				if (webElement.getText().split("\\n")[0].trim().equalsIgnoreCase(Estimatebtns[k])) {
					report.updateTestLog("Drug Costs button", "Drug Costs button is displayed in the cost estimator widget"
							, Status.PASS);
				} else {
					report.updateTestLog("Drug Costs button", "Drug Costs button not found in the cost estimator widget"
							, Status.FAIL);
				}	
			}

			k++;

		}
	}

	public void closeallChildWindowTabs(){
		//Getting total windows
		ArrayList<String> ttltabs = new ArrayList<>(driver.getWindowHandles());
		int ttl_tabs = ttltabs.size();
		//Exclusing since int=0 being the Default window
		for (int i = 1; i < ttl_tabs; i++) {
			driver.switchTo().window(ttltabs.get(i));
			driver.close();
		}
		driver.switchTo().window(ttltabs.get(0));
		driverUtil.waitFor(2000);

	}

	public void validate_HealthSparqPage_MedicalCosts(){

		/***PAGE INPUT REFERENCE - ARAVINTH
		 1. HomePage
		 2. FindCare
		 3. FindCare_MedCosts
		 ***/

		String NavPageRef = dataTable.getData("General_Data", "NavPageReference");

		//Verifying Healthsparq page_Medical Cost
		String healthsparq_LeavnPage = dataTable.getData("General_Data", "Paragraph");

		//Checks for the input reference and navigates as per respective behavior
		if (NavPageRef.equals("HomePage")) {
			performAction(MyWellmark_OR.link_Sidenav_Home, "SCROLLANDCLICK", "");
			performAction(MyWellmark_OR.link_Find_Provider, "SCROLLANDCLICK", "");
		} else if(NavPageRef.equals("FindCare")){
			performAction(MyWellmark_OR.link_Sidenav_FindCare, "SCROLLANDCLICK", "");
			performAction(MyWellmark_OR.link_Find_Provider_FindCarePage, "SCROLLANDCLICK", "");
		}else if(NavPageRef.equals("FindCare_MedCosts")){
			performAction(MyWellmark_OR.link_Sidenav_FindCare, "SCROLLANDCLICK", "");
			performAction(MyWellmark_OR.btn_CostEst_Medical, "SCROLLANDCLICK", "");
		}

		String healthsparq_UI_txt = driver.findElement(MyWellmark_OR.lbl_LeavnPageWellmark).getText().trim();
		//Paragraph Verfication
		if (healthsparq_LeavnPage.equals(healthsparq_UI_txt)) {
			report.updateTestLog("Leaving Page", "Interstitial message gets displayed", Status.PASS);
		} else {
			report.updateTestLog("Leaving Page", "Interstitial message not displayed", Status.FAIL);
		}
		//Buttons Verification
		if (findElement(MyWellmark_OR.btn_LeavnPage_Contn)==true) {
			if (findElement(MyWellmark_OR.btn_Leavnpage_Cancel)==true) {
				report.updateTestLog("Leaving Page", "Continue and Cancel button gets displayed in the modal window", Status.PASS);
			}
		} else {
			report.updateTestLog("Leaving Page", "Continue and Cancel button not displayed", Status.FAIL);
		}

		//Clicks on Continue button to navigate to Healthsparq URL
		performAction(MyWellmark_OR.btn_LeavnPage_Contn, "SCROLLANDCLICK", "");
		//waitFor(20, By.xpath("//section[@id='eula-container']"));
		driverUtil.waitFor(20000);
		//Switching between tabs
		ArrayList<String> tabSwitch = new ArrayList<>(driver.getWindowHandles());
		//int ttl_tabs = tabSwitch.size();
		driver.switchTo().window(tabSwitch.get(1));
		
		//On getting Terms of Use page, it skips
		int chk_Agree_Cntn = driver.findElements(MyWellmark_OR.btn_Search_provider_cntn).size();
		if (chk_Agree_Cntn==1) {
			performAction(MyWellmark_OR.btn_Search_provider_cntn, "SCROLLANDCLICK", "");
			driverUtil.waitFor(5000);
		}
		
		//Get Current window name
		String Cur_win_Name = driver.getCurrentUrl();
		String Ref_win_Name = dataTable.getData("General_Data", "DoctorUrl");
		if (Cur_win_Name.equals(Ref_win_Name)) {
			report.updateTestLog("Healthsparq URL", "Navigated to Healthsparq URL successful", Status.PASS);
		} else {
			report.updateTestLog("Healthsparq URL", "Navigated to Healthsparq URL Unsuccessful", Status.FAIL);
		}




	}

	public void validate_CVSPage_DrugCosts(){
		/***PAGE INPUT REFERENCE - ARAVINTH
		 1. HomePage
		 2. FindCare
		 3. FindCare_MedCosts
		 ***/
		String NavPageRef = dataTable.getData("General_Data", "NavPageReference");
		//Verifying CVS page_Medical Cost
		String cvs_LeavnPage = dataTable.getData("General_Data", "PharmacyParagraph");
		//Checks for the input reference and navigates as per respective behavior
		if (NavPageRef.equals("HomePage")) {
			performAction(MyWellmark_OR.link_Sidenav_Home, "SCROLLANDCLICK", "");
			performAction(MyWellmark_OR.link_Find_Pharmacy_HomePage, "SCROLLANDCLICK", "");
		} else if(NavPageRef.equals("FindCare")){
			performAction(MyWellmark_OR.link_Sidenav_FindCare, "SCROLLANDCLICK", "");
			performAction(MyWellmark_OR.link_Find_Pharmacy_FindCarePage, "SCROLLANDCLICK", "");
		}else if(NavPageRef.equals("FindCare_MedCosts")){
			performAction(MyWellmark_OR.link_Sidenav_FindCare, "SCROLLANDCLICK", "");
			performAction(MyWellmark_OR.btn_CostEst_Drug, "SCROLLANDCLICK", "");
		}

		String CVS_UI_txt = driver.findElement(MyWellmark_OR.lbl_LeavnPageWellmark).getText().trim();
		//Paragraph Verfication
		if (cvs_LeavnPage.equals(CVS_UI_txt)) {
			report.updateTestLog("Leaving Page", "Interstitial message gets displayed", Status.PASS);
		} else {
			report.updateTestLog("Leaving Page", "Interstitial message not displayed", Status.FAIL);
		}
		//Buttons Verification
		if (findElement(MyWellmark_OR.btn_LeavnPage_Contn)==true) {
			if (findElement(MyWellmark_OR.btn_Leavnpage_Cancel)==true) {
				report.updateTestLog("Leaving Page", "Continue and Cancel button gets displayed in the modal window", Status.PASS);
			}
		} else {
			report.updateTestLog("Leaving Page", "Continue and Cancel button not displayed", Status.FAIL);
		}

		//Clicks on Continue button to navigate to CVS URL
		performAction(MyWellmark_OR.btn_LeavnPage_Contn, "SCROLLANDCLICK", "");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		//Switching between tabs
		ArrayList<String> tabSwitch = new ArrayList<>(driver.getWindowHandles());
		//int ttl_tabs = tabSwitch.size();
		driver.switchTo().window(tabSwitch.get(1));
		//Get Current window name
		String Cur_win_Name = driver.getCurrentUrl();
		String Ref_win_Name = dataTable.getData("General_Data", "PharmacyUrl");
		if (Cur_win_Name.equals(Ref_win_Name)) {
			report.updateTestLog("CVS URL", "Navigated to CVS Page successful", Status.PASS);
		} else {
			report.updateTestLog("CVS URL", "Navigated to CVS Page Unsuccessful", Status.FAIL);
		}

	}

	public void validate_FacilityLink(){


		performAction(MyWellmark_OR.link_Find_facility, "SCROLLANDCLICK", "");
		waitFor(20, MyWellmark_OR.btn_LeavnPage_Contn);

		//Buttons Verification
		if (findElement(MyWellmark_OR.btn_LeavnPage_Contn)==true) {
			if (findElement(MyWellmark_OR.btn_Leavnpage_Cancel)==true) {
				report.updateTestLog("Leaving Page", "Continue and Cancel button gets displayed in the modal window", Status.PASS);
			}
		} else {
			report.updateTestLog("Leaving Page", "Continue and Cancel button not displayed", Status.FAIL);
		}

		//Clicks on Continue button to navigate to Find Facilty Page
		performAction(MyWellmark_OR.btn_LeavnPage_Contn, "SCROLLANDCLICK", "");
		driverUtil.waitFor(8000);
		//Switching between tabs
		ArrayList<String> tabSwitch = new ArrayList<>(driver.getWindowHandles());
		//int ttl_tabs = tabSwitch.size();
		driver.switchTo().window(tabSwitch.get(1));






	}

	public void all_widgets_Check_Homepage(){
		//Checks for all the widgets in home page
		int ttlwidgets = driver.findElements(MyWellmark_OR.lbl_Homepg_widgets).size();
		int claim_widget = driver.findElements(MyWellmark_OR.lbl_Homepg_widget_Claims).size();
		int ttlSearchLinks = driver.findElements(MyWellmark_OR.lbl_Homepg_SearchLinks).size();

		if (claim_widget==1) {
			ttlwidgets = ttlwidgets + claim_widget;
		}else{
			report.updateTestLog("Latest Claims Widget", "Latest Claims Widget not available", Status.FAIL);
		}
		//Verifies all widgets
		if (ttlwidgets == 4) {
			report.updateTestLog("Home Page Widgets", "All the home page widgets appears successful", Status.PASS);
		}else if(ttlSearchLinks==1){
			int chkDentalSearchLink = driver.findElements(MyWellmark_OR.lbl_Homepg_DentalSearchLink).size();
			if (chkDentalSearchLink==1) {
				report.updateTestLog("Home Page Widget For Dental Only", "Only Dental Only Search link is available", Status.PASS);
			}
			
		}else{
			report.updateTestLog("Home Page Widgets", "Widgets missing in Home Page", Status.FAIL);
		}
	}

	public void all_findCareLinks_Check_Homepage(){
		//Verifies available links in Home page
		String[] findCare_widgetLinks = new String[]{"Find a,Provider",
				"Find a,Facility", "Find a,Pharmacy", "Find A,Dentist"};
		for (String string : findCare_widgetLinks) {
			String fHalf = string.split(",")[0];
			String sHalf = string.split(",")[1];
			By widget_FindCare = By.xpath("//div[@class='find-care-content']//span[contains(.,'" + fHalf + "')][contains(.,'" + sHalf + "')]");
			if (findElement(widget_FindCare)) {
				report.updateTestLog("Link Name: " + string, "Link found under Find Care Widget", Status.PASS);
			} else {
				report.updateTestLog("Link Name: " + string, "Link not found under Find Care Widget", Status.FAIL);
			}
		}
	}

	public void searchforProvider(){
		//If Declaration page found, Clicks on Continue and move to Search providers page
		/*if (findElement(MyWellmark_OR.btn_Search_provider_cntn)) {
			performAction(MyWellmark_OR.btn_Search_provider_cntn, "SCROLLANDCLICK", "");
		}
		waitFor(20, MyWellmark_OR.txt_Search_provider);*/
		//Search for Provider
		String prov_Name = dataTable.getData("General_Data", "Provider_Name");
		performAction(MyWellmark_OR.txt_Search_provider, "SENDKEYS", prov_Name);
		performAction(MyWellmark_OR.btn_Search_Common, "SCROLLANDCLICK", "");
		waitFor(20, By.xpath("//section[@id='results-wrapper']//a[contains(.,'" + prov_Name + "')]"));
		if (findElement(By.xpath("//section[@id='results-wrapper']//a[contains(.,'" + prov_Name + "')]"))) {
			report.updateTestLog("Provider Name: " + prov_Name, "Provider found successful", Status.PASS);	
		}else{
			report.updateTestLog("Provider Name: " + prov_Name, "Provider not found", Status.FAIL);	
		}
	}

	public void searchforFacility(){
		//If Declaration page found, Clicks on Continue and move to Search providers page
		if (findElement(MyWellmark_OR.btn_Search_provider_cntn)) {
			performAction(MyWellmark_OR.btn_Search_provider_cntn, "SCROLLANDCLICK", "");
		}
		waitFor(20, MyWellmark_OR.txt_Search_facility);
		String fac_Name = dataTable.getData("General_Data", "Facilty Name");
		performAction(MyWellmark_OR.txt_Search_facility, "SENDKEYS", fac_Name);
		performAction(MyWellmark_OR.btn_Search_Common, "SCROLLANDCLICK", ""); 
		waitFor(20, By.xpath("//section[@id='results-wrapper']//a[contains(.,'" + fac_Name + "')]"));

		if (findElement(By.xpath("//section[@id='results-wrapper']//a[contains(.,'" + fac_Name + "')]"))) {
			report.updateTestLog("Facility Name: " + fac_Name, "Facility found successful", Status.PASS);	
		}else{
			report.updateTestLog("Facility Name: " + fac_Name, "Facility not found", Status.FAIL);	
		}
	}

	public void seeAllClaims_ClaimsPage(){
		//Navigate to the element
		performAction(MyWellmark_OR.lnk_SeeAllClaims_HomePage, "SCROLLDOWN", "");
		performAction(MyWellmark_OR.lnk_SeeAllClaims_HomePage, "SCROLLANDCLICK", "");

		waitFor(30, MyWellmark_OR.lbl_ClaimsPage);
		if (findElement(MyWellmark_OR.lbl_ClaimsPage)==true) {
			report.updateTestLog("Claims page", "Navigated to Claims page successful", Status.PASS);
		} else {
			report.updateTestLog("Claims page", "Navigated to Claims page Unsuccessful", Status.FAIL);
		}
	}

	public void viewCoverage_CoveragePage(){
		//Validating your coverage educational content in home page
		int educont_1 = driver.findElements(MyWellmark_OR.lbl_ViewCov).size();
		int educont_2 = driver.findElements(MyWellmark_OR.lbl_ViewCov_points).size();

		if (educont_1 + educont_2 == 2) {
			report.updateTestLog("Educational content_Benefit widget", "Educational content is displayed as expected", Status.PASS);
		} else {
			report.updateTestLog("Educational content_Benefit widget", "Educational content is displayed as expected", Status.FAIL);
		}

		//Clicks on View Benefits link
		performAction(MyWellmark_OR.lnk_ViewCoverage_HomePage, "SCROLLANDCLICK", "");
		waitFor(20, MyWellmark_OR.lbl_CoveragePage);
		if (findElement(MyWellmark_OR.lbl_CoveragePage)==true) {
			report.updateTestLog("Coverage page", "Navigated to Coverage page successful", Status.PASS);
		} else {
			report.updateTestLog("Coverage page", "Navigated to Coverage page Unsuccessful", Status.FAIL);
		}
	}

	public void enterCredentials_NoDed(){
		//Enter Credentials for No Deductible
		String userName_NoDed=dataTable.getData("General_Data", "AdditionalUserName_NoDed");
		String passWord=dataTable.getData("General_Data", "Password");
		//Login to Application
		driver.findElement(MyWellmark_OR.txtUsername).sendKeys(userName_NoDed);
		driver.findElement(MyWellmark_OR.txtPassword).sendKeys(passWord);
		if (findElement(MyWellmark_OR.btn_Relogin_Login)==false) {
			performAction(MyWellmark_OR.btnLogin, "SCROLLANDCLICK","" );
			driverUtil.waitFor(8000);
			//waitFor(30, MyWellmark_OR.obj_LatestClaims);
		}else{
			performAction(MyWellmark_OR.btn_Relogin_Login, "CLICK", "");
			//driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driverUtil.waitFor(8000);
			//waitFor(30, MyWellmark_OR.obj_LatestClaims);
		}
	}

	public void enterCredentials_NoOOP(){
		//Enter Credentials for No Deductible
		String userName_NoOOP=dataTable.getData("General_Data", "AdditionalUserName_NoOOP");
		String passWord=dataTable.getData("General_Data", "Password");
		//Login to Application
		driver.findElement(MyWellmark_OR.txtUsername).sendKeys(userName_NoOOP);
		driver.findElement(MyWellmark_OR.txtPassword).sendKeys(passWord);
		if (findElement(MyWellmark_OR.btn_Relogin_Login)==false) {
			performAction(MyWellmark_OR.btnLogin, "SCROLLANDCLICK","" );
			driverUtil.waitFor(10000);
			//waitFor(30, MyWellmark_OR.obj_LatestClaims);
		}else{
			performAction(MyWellmark_OR.btn_Relogin_Login, "CLICK", "");
			//driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driverUtil.waitFor(10000);
			//waitFor(30, MyWellmark_OR.obj_LatestClaims);
		}
	}

	public void cookieDelete(){
		driver.manage().deleteAllCookies();
	}

	public void fieldChecks_DedMax(){
		//Checks for Fields
		if (findElement(MyWellmark_OR.lbl_DedMax_AmtRem)==true
				&& findElement(MyWellmark_OR.lbl_DedMax_AmtSat)) {
			report.updateTestLog("Amount remaining and Amount Satisfied", "Amount remaining and Amount Satisfied fields displays successful", Status.PASS);
		} else {
			report.updateTestLog("Amount remaining and Amount Satisfied", "Amount remaining and Amount Satisfied fields displays Unsuccessful", Status.FAIL);
		}
	}

	public void verifyFindCostsToggle(){
		int ttlSearchLinks = driver.findElements(MyWellmark_OR.lbl_Homepg_SearchLinks).size();
		if (ttlSearchLinks==1) {
			int chkDentalSearchLink = driver.findElements(MyWellmark_OR.lbl_Homepg_DentalSearchLink).size();
			if (chkDentalSearchLink==1) {
				report.updateTestLog("HomePage_FindCosts toggle_For Dental", "Find Costs toggle button not present in the Home page for Dental Only", Status.PASS);
			}
		} else {
			//Checks for Find Costs toggle button
			if (findElement(MyWellmark_OR.tglbtn_FindCosts_HomePage)) {
				report.updateTestLog("HomePage_FindCosts toggle", "Find Costs toggle button is present in the Home page", Status.PASS);
			}else{
				report.updateTestLog("HomePage_FindCosts toggle", "Find Costs toggle button missing in the Home page", Status.FAIL);
			}
		}
		
	}

	public void navFindCarePage(){
		//Navigates to Find Care page
		performAction(MyWellmark_OR.link_Sidenav_FindCare, "SCROLLANDCLICK", "");
		waitFor(20, MyWellmark_OR.lbl_FindCare);
	}

	public void navHomePage(){
		//Navigating back to the home page and check for Latest Claims
		performAction(MyWellmark_OR.link_Sidenav_Home, "SCROLLANDCLICK", "");
		waitFor(30, MyWellmark_OR.lbl_HomePage);
	}

	public void verifyLatestClaims(){
		driverUtil.waitFor(1000);
		//waitFor(30, MyWellmark_OR.obj_LatestClaims); 
		if (findElement(MyWellmark_OR.obj_LatestClaims)) {
			report.updateTestLog("Latest Claims overview", "Latest Claims overview is displayed in the Home Page", Status.PASS);
		} else {
			report.updateTestLog("Latest Claims overview", "Latest Claims overview not displayed", Status.FAIL);
		}
	}

	public void verifyIDCardHomePage(){
		driverUtil.waitFor(2000);
		if (findElement(MyWellmark_OR.obj_IDCard)==false) {
			report.updateTestLog("ID Card panel_DentalCoverage", "ID Card panel not present in Homepage", Status.PASS);
		} else {
			report.updateTestLog("ID Card panel_DentalCoverage", "ID Card panel present in Homepage", Status.FAIL);
		}
	}

	public ResultSet executeQuery_websecurity(String sql) throws SQLException, ClassNotFoundException{
		Statement stmt_ws = null;  
		ResultSet rs_ws = null;  
		Connection con_ws = null;
		try{
			con_ws = connectTowebsecurityDB(); 
			stmt_ws = con_ws.createStatement();  
			rs_ws = stmt_ws.executeQuery(sql);  
		}  
		catch (SQLException e) {  
			throw e;  
		} 
		return rs_ws;
	}
	public ResultSet executeQuery_websecurity_Mongo(String curTCName_Mongo, String sql) throws SQLException, ClassNotFoundException, NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException{
		Statement stmt_ws = null;  
		ResultSet rs_ws = null;  
		Connection con_ws = null;
		try{
			con_ws = connectTowebsecurityDB_Mongo(curTCName_Mongo); 
			stmt_ws = con_ws.createStatement();  
			rs_ws = stmt_ws.executeQuery(sql);  
		}  
		catch (SQLException e) {  
			throw e;  
		} 
		return rs_ws;
	}

	public Connection connectTowebsecurityDB() throws SQLException, ClassNotFoundException{
		// Create a variable for the connection string.   63.145.102.62,11001
		String DBServer = dataTable.getData("General_Data", "WebSecurityServer");
		String DBName = dataTable.getData("General_Data", "WebSecurityName");
		String DBUsername = dataTable.getData("General_Data", "WebSecurityUsername");
		String DBPassword = dataTable.getData("General_Data", "WebSecurityPassword");
		String connectionUrl = "jdbc:sqlserver://"+DBServer+";databaseName=" + DBName+";user="+DBUsername+";password="+DBPassword;
		// Declare the JDBC objects.  
		Connection con_ws = null;  
		try {  
			// Establish the connection.  
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");  
			con_ws = DriverManager.getConnection(connectionUrl); 
		}  

		catch (ClassNotFoundException e) {  
			throw e;  
		}  
		return con_ws;
	}

	public Connection connectTowebsecurityDB_Mongo(String curTCName_Mongo) throws SQLException, ClassNotFoundException, NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException{
		// Create a variable for the connection string.   63.145.102.62,11001
		String DBServer = getmongoData(curTCName_Mongo, "General_Data", "WebSecurityServer");
		String DBName = getmongoData(curTCName_Mongo, "General_Data", "WebSecurityName");
		String DBUsername = getmongoData(curTCName_Mongo, "General_Data", "WebSecurityUsername");
		String DBPassword = getmongoData(curTCName_Mongo, "General_Data", "WebSecurityPassword");
		String connectionUrl = "jdbc:sqlserver://"+DBServer+";databaseName=" + DBName+";user="+DBUsername+";password="+DBPassword;
		// Declare the JDBC objects.  
		Connection con_ws = null;  
		try {  
			// Establish the connection.  
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");  
			con_ws = DriverManager.getConnection(connectionUrl); 
		}  

		catch (ClassNotFoundException e) {  
			throw e;  
		}  
		return con_ws;
	}

	/*public void login_withDB() throws ClassNotFoundException, SQLException{

		String subsId = null;

		do {
			Mongo mongo = new Mongo(scriptHelper);
			subsIdvl = mongo.validateSubscriberID_FacetsandMongoDB();
			subsId=subsIdvl[0];
			websecurityuserid=subsIdvl[1];
			extractdata(subsId);
			dataTable.putData("General_Data", "Username", websecurityuserid);
			//Getting Registration URL			
			//String mem_RegURL = dataTable.getData("General_Data", "MemReg_URL");
			//driver.manage().deleteAllCookies();
			//driver.get(mem_RegURL);
			driverUtil.waitFor(5000);
			invokeApplication();
			enterCredentials();
			//selectType();
			//register member in UI
			//registerMember();
		}while (!findElement(MyWellmark_OR.obj_LatestClaims));

	}*/

	public void memRegistration_withDB_Mongo(String FacetsSID) throws ClassNotFoundException, SQLException{

		String subsId = null;

		do {

			subsId = FacetsSID;
			extractdata(subsId);

			//Getting Registration URL			
			String mem_RegURL = dataTable.getData("General_Data", "MemReg_URL");
			driver.manage().deleteAllCookies();
			driver.get(mem_RegURL);
			driverUtil.waitFor(5000);
			selectType();
			//register member in UI
			registerMember(subsId);
		} while (findElement(MyWellmark_OR.lbl_mem_exist_Alert)==true);


		registerMemberStep2(subsId);
		driver.manage().deleteAllCookies();
		//driver.close();

	}

	public void memberRegistration() throws ClassNotFoundException, SQLException{
		String subsId = null;

		do {

			subsId = dataTable.getData("General_Data", "SSN/SID");
			extractdata(subsId);

			//Getting Registration URL			
			String mem_RegURL = dataTable.getData("General_Data", "MemReg_URL");
			driver.manage().deleteAllCookies();
			driver.get(mem_RegURL);
			driverUtil.waitFor(5000);
			selectType();
			//register member in UI
			registerMember(subsId);
		} while (findElement(MyWellmark_OR.lbl_mem_exist_Alert)==true);


		registerMemberStep2(subsId);
		driver.manage().deleteAllCookies();

	}

	public void verifyAllFooterNames(){
		String[] footerNames = dataTable.getData("General_Data", "instext").split(";");
		ArrayList<WebElement>fNames_UI = new ArrayList<>(driver.findElements(MyWellmark_OR.link_Footer_DoMore));
		int k = 0;

		//Get String from collection
		for (WebElement webElement : fNames_UI) {
			String fName = webElement.getText().split("\\n")[0].trim();
			if (fName.equals(footerNames[k])) {
				report.updateTestLog("Footer Name_" + fName, "Footer name gets matached", Status.PASS);
			} else {
				report.updateTestLog("Footer Name_" + fName, "Footer name gets mismatached", Status.FAIL);
			}
			k++;
		}
	}

	public void footerValidation_ContactUs(){
		//Clicks on Footer_Contact Us
		performAction(MyWellmark_OR.link_Footer_ContactUs, "SCROLLANDCLICK", "");
		waitFor(10, MyWellmark_OR.lbl_ContactUs);
		if (findElement(MyWellmark_OR.lbl_ContactUs)==true) {
			report.updateTestLog("Contact Us Page", "Navigated to Contact Us page successful", Status.PASS);
		}else{
			report.updateTestLog("Contact Us Page", "Navigated to Contact Us page Unsuccessful", Status.FAIL);
		}

		navHomePage();
	}

	public void footerValidation_IdentityProtection(){
		//Clicks on Identity Protection
		performAction(MyWellmark_OR.link_Footer_IdentityProt, "SCROLLANDCLICK", "");
		waitFor(10, MyWellmark_OR.lbl_IdentityProt);
		if (findElement(MyWellmark_OR.lbl_IdentityProt)==true) {
			report.updateTestLog("Identity Protection Page", "Navigated to Identity Protection page successful", Status.PASS);
		}else{
			report.updateTestLog("Identity Protection Page", "Navigated to Identity Protection page Unsuccessful", Status.FAIL);
		}

		waitFor(10, MyWellmark_OR.btn_LeavnPage_Contn);

		//Clicks Continue on Leaving page
		performAction(MyWellmark_OR.btn_LeavnPage_Contn, "SCROLLANDCLICK", "");
		ArrayList<String> ttlwindows = new ArrayList<>(driver.getWindowHandles());
		driver.switchTo().window(ttlwindows.get(1));
		if (findElement(MyWellmark_OR.btn_MyIDCare_EnrollNow)==true) {
			report.updateTestLog("Enroll/Login_Identity Protection", "Navigated to Enroll/Login_Identity Protection page successful", Status.PASS);
		} else {
			report.updateTestLog("Enroll/Login_Identity Protection", "Navigated to Enroll/Login_Identity Protection page Unsuccessful", Status.FAIL);
		}

		closeallChildWindowTabs();
	}

	public void footerValidation_Glossary(){
		//Clicks on Glossary Link
		performAction(MyWellmark_OR.link_Footer_Glossary, "SCROLLANDCLICK", "");

		ArrayList<String> ttlwindows_Glossary = new ArrayList<>(driver.getWindowHandles());
		driver.switchTo().window(ttlwindows_Glossary.get(1));
		if (findElement(MyWellmark_OR.lbl_GlossaryTerms)==true) {
			report.updateTestLog("Glossary of terms page", "Navigated to Glossary of terms page successful", Status.PASS);
		} else {
			report.updateTestLog("Glossary of terms page", "Navigated to Glossary of terms page Unsuccessful", Status.FAIL);
		}

		closeallChildWindowTabs();
	}

	public void footerValidation_GetAdobeReader(){
		//Clicks on Get Adobe Reader link
		performAction(MyWellmark_OR.link_Footer_AdobeReader, "SCROLLANDCLICK", "");

		//Clicks on COntinue on Interstinal dialog window
		waitFor(10, MyWellmark_OR.btn_LeavnPage_Contn);
		performAction(MyWellmark_OR.btn_LeavnPage_Contn, "SCROLLANDCLICK", "");

		ArrayList<String> ttlwindows_Adobe = new ArrayList<>(driver.getWindowHandles());
		driver.switchTo().window(ttlwindows_Adobe.get(1));
		if (findElement(MyWellmark_OR.btn_AdobeReader)==true) {
			report.updateTestLog("Get Adobe Reader page", "Navigated to Get Adobe Reader page page successful", Status.PASS);
		} else {
			report.updateTestLog("Get Adobe Reader page", "Navigated to Get Adobe Reader page page Unsuccessful", Status.FAIL);
		}

		closeallChildWindowTabs();
	}

	public void cancelPlanMsg(){
		//Cancelled plan message
		String cancel_msg_UI = "";

		String cancel_msg = dataTable.getData("General_Data", "Paragraph");
		List<WebElement> cancel_msg_obj = driver.findElements(MyWellmark_OR.lbl_CancelledPlanMsg);

		for (WebElement webElement : cancel_msg_obj) {
			cancel_msg_UI = cancel_msg_UI + webElement.getText().trim();
			cancel_msg_UI.trim();
		}

		if (cancel_msg_UI.equals(cancel_msg)) {
			report.updateTestLog("Cancelled Plan message", "Message gets displayed when member belongs to Cancelled Policy", Status.PASS);
		}else{
			report.updateTestLog("Cancelled Plan message", "Unable to view the message for Cancelled Policy", Status.FAIL);
		}
	}

	public void cancel_NoIDWidget(){
		//Checks for No ID card widget gets displayed
		if (findElement(MyWellmark_OR.lbl_IDCard_Widget)==false) {
			report.updateTestLog("ID Card Widget", "No ID Card Widget gets displayed for Cancelled policy", Status.PASS);
		} else {
			report.updateTestLog("ID Card Widget", "ID Card Widget gets displayed for Cancelled policy", Status.FAIL);
		}
	}

	public void cancel_CoverageWidget(){
		//Checks for your coverage widget gets displayed
		if (findElement(MyWellmark_OR.lbl_MyBenPanel)==false) {
			report.updateTestLog("Your Coverage Widget", "No Your Coverage Widget gets displayed for Cancelled policy", Status.PASS);
		} else {
			report.updateTestLog("Your Coverage Widget", "Your Coverage Widget gets displayed for Cancelled policy", Status.FAIL);
		}
	}

	public void verify_FindCareWidget(){
		if (findElement(MyWellmark_OR.link_Sidenav_FindCare)==true) {
			report.updateTestLog("Home Page_Find Care Section", "Find Care section is present in the Home page", Status.PASS);
		} else {
			report.updateTestLog("Home Page_Find Care Section", "Find Care section not present in the Home page", Status.FAIL);
		}
	}

	public void verify_ClaimsWidget(){
		if (findElement(MyWellmark_OR.link_Sidenav_Claims)==true) {
			report.updateTestLog("Home Page_CLaims Section", "Claims section is present in the Home page", Status.PASS);
		} else {
			report.updateTestLog("Home Page_CLaims Section", "Claims section not present in the Home page", Status.FAIL);
		}
	}

	public void verify_ClaimListDateDiff(){
		//SimpleDateFormat myformat = new SimpleDateFormat("E, dd MMM yyyy HH:mm:ss z"); //Tue, 02 Jan 2018 18:07:59 IST
		List<WebElement> ClaimContainer = driver.findElements(MyWellmark_OR.lbl_ClaimsDate);
		Set<String> existYear = new TreeSet<>();
		for (WebElement webElement : ClaimContainer) {
			String claimYear = webElement.getText().split(",")[1].trim();
			if (claimYear.equals("2018")||claimYear.equals("2017")||claimYear.equals("2016")||claimYear.equals("2015")||
					claimYear.equals("2014")||claimYear.equals("2013")||claimYear.equals("2012")||claimYear.equals("2011")) {
				existYear.add("Yes");
			} else {
				existYear.add("No");
			}
		}

		//Checks for the count
		if (ClaimContainer.size()>0) {
			if (!existYear.contains("No")) {
				report.updateTestLog("Last 24 months claims", "Member have claims for last 24 months", Status.PASS);
				performAction(MyWellmark_OR.lnk_SeeAllClaims_HomePage, "SCROLLANDCLICK", "");
				waitFor(20, MyWellmark_OR.lbl_ClaimsPage);
				report.updateTestLog("Claims List Page", "Navigated to claims list page successful", Status.PASS);
				performAction(MyWellmark_OR.link_Sidenav_Home, "SCROLLANDCLICK", "");
				if (driver.isElementvisible(MyWellmark_OR.modal_OnlineEOB_HmePg, 5)==true) {
					performAction(MyWellmark_OR.modal_OnlineEOB_HmePg, "SCROLLANDCLICK", "");
					driverUtil.waitFor(1000);
				}
				waitFor(20, MyWellmark_OR.lnk_SeeAllClaims_HomePage);
			}
		} else {
			report.updateTestLog("Last 24 months claims", "For no claims within 24 hours, system displays appropriate message", Status.PASS);
		}
	}

	public void relatedInfo_GetNames(){
		page_Name = driver.findElement(By.xpath("//h1")).getText().trim();
		relatedInfo_text = driver.findElements(MyWellmark_OR.link_RelatedInfo);
		for (WebElement webElement : relatedInfo_text) {
			String name_RelatedText = webElement.getText().trim();
			contents_RelatedInfoUI.add(name_RelatedText);
		}
		
		relatedInfo_apprNameList(page_Name, contents_RelatedInfoUI);
	}

	public void relatedInfo_apprNameList(String page_Name2, ArrayList<String> contents_RelatedInfoUI2){
		switch(page_Name){
		case "Deductibles & Maximums":						
			String[] linkNamesUI_Ded = new String[]{"Copays and Coinsurance", "Benefits Used"};
			if (contents_RelatedInfoUI.contains(linkNamesUI_Ded[0])
					&& contents_RelatedInfoUI.contains(linkNamesUI_Ded[1])) {
				report.updateTestLog("Related Info_" + page_Name, 
						"Related Info links " + linkNamesUI_Ded[0] + " " + linkNamesUI_Ded[1] + " is present", Status.PASS);
			} else {
				report.updateTestLog("Related Info_" + page_Name, 
						"Related Info links " + linkNamesUI_Ded[0] + " " + linkNamesUI_Ded[1] + " not found", Status.FAIL);
			}
			break; 

		case "Copays & Coinsurance":	
			String[] linkNamesUI_CC = new String[]{"Deductibles and Maximums", "Benefits Used"};
			if (contents_RelatedInfoUI.contains(linkNamesUI_CC[0])
					&& contents_RelatedInfoUI.contains(linkNamesUI_CC[1])) {
				report.updateTestLog("Related Info_" + page_Name, 
						"Related Info links " + linkNamesUI_CC[0] + " " + linkNamesUI_CC[1] + " is present", Status.PASS);
			} else {
				report.updateTestLog("Related Info_" + page_Name, 
						"Related Info links " + linkNamesUI_CC[0] + " " + linkNamesUI_CC[1] + " not found", Status.FAIL);
			}
			break;

		case "Benefits Used":	
			String[] linkNamesUI_BU = new String[]{"Copays and Coinsurance", "Deductibles and Maximums"};
			if (contents_RelatedInfoUI.contains(linkNamesUI_BU[0])
					&& contents_RelatedInfoUI.contains(linkNamesUI_BU[1])) {
				report.updateTestLog("Related Info_" + page_Name, 
						"Related Info links " + linkNamesUI_BU[0] + " " + linkNamesUI_BU[1] + " is present", Status.PASS);
			} else {
				report.updateTestLog("Related Info_" + page_Name, 
						"Related Info links " + linkNamesUI_BU[0] + " " + linkNamesUI_BU[1] + " not found", Status.FAIL);
			}
			break;

		}
	}


	/*public void verifyall_RelatedInfoLinks(){

		verifyAll_relatedInfo_text = driver.findElements(MyWellmark_OR.link_RelatedInfo);

		for (WebElement element : verifyAll_relatedInfo_text) {
			performAction(element, "SCROLLANDCLICK", "", "");
			driverUtil.waitFor(1000);
			verifyAll_page_Name = driver.findElement(By.xpath("//h1")).getText().trim();

			relatedInfo_GetNames();
			relatedInfo_apprNameList();

		}
	}*/

	public void switchToPharmacy_CoveragePage(){

		//Clicks on Coverage link if not
		if (findElement(MyWellmark_OR.link_Sidenav_Coverage)==true) {
			performAction(MyWellmark_OR.link_Sidenav_Coverage, "SCROLLANDCLICK", "");
		}

		//Checks for Pharmacy tab
		if (findElement(MyWellmark_OR.tab_Phar_Cov)==true) {
			report.updateTestLog("Coverage_Pharmacy Tab", "Pharmacy Tab is displayed in Benefit landing page", Status.PASS);
		} else {
			report.updateTestLog("Coverage_Pharmacy Tab", "Pharmacy Tab is not displayed in Benefit landing page", Status.FAIL);
		}
		
		//Switch to Pharmacy tab
		navToDed_MaxPage_Pharm();


	}


	public void switchToDental_CoveragePage(){

		//Clicks on Coverage link if not
		if (findElement(MyWellmark_OR.link_Sidenav_Coverage)==true) {
			performAction(MyWellmark_OR.link_Sidenav_Coverage, "SCROLLANDCLICK", "");
		}

		//Checks for Dental tab
		if (findElement(MyWellmark_OR.tab_Den_Cov)==true) {
			report.updateTestLog("Coverage_Dental Tab", "Dental Tab is displayed in Benefit landing page", Status.PASS);
		} else {
			report.updateTestLog("Coverage_Dental Tab", "Dental Tab is not displayed in Benefit landing page", Status.FAIL);
		}
		
		//Switch to Dental tab
		navToDed_MaxPage_Den();

	}


	public String getmongoData(String currentTestcase, String datasheetName, String fieldName) throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException{
		String datatablePath = System.getProperty("user.dir")+"/Datatables/";
		String datatableName = "C85_Main";
		String dataReferenceIdentifier = "#";
		ExcelDataAccess testDataAccess_Mongo = new ExcelDataAccess(datatablePath,
				datatableName);
		testDataAccess_Mongo.setDatasheetName(datasheetName);
		int rowNum = testDataAccess_Mongo.getRowNum(currentTestcase, 0, 1); 
		String dataValue = testDataAccess_Mongo.getValue(rowNum, fieldName);

		if (dataValue.startsWith(dataReferenceIdentifier)) {
			CraftDataTable c1 = scriptHelper.getDataTable();
			dataValue = c1.getCommonData(fieldName, dataValue);

		}

		return dataValue;

	}

	public void putmongoData(String currentTestcase,String datasheetName, String fieldName, String dataValue){
		String datatablePath = System.getProperty("user.dir")+"/Datatables/";
		String datatableName = "C85_Main";
		ExcelDataAccess testDataAccess_Mongo = new ExcelDataAccess(datatablePath,
				datatableName);
		testDataAccess_Mongo.setDatasheetName(datasheetName);

		int rowNum = testDataAccess_Mongo.getRowNum(currentTestcase, 0, 1);

		synchronized (CraftDataTable.class) {
			testDataAccess_Mongo.setValue(rowNum, fieldName, dataValue);
		}

	}

	public void runMan_Mongo() throws IOException{
		driver.quit();
		String dataFileName = "Run Manager.xlsm";
		String globalPropFile = "Global Settings.properties";
		String dataTablepath = System.getProperty("user.dir");	
		FileInputStream file = new FileInputStream(new File(dataTablepath+"/" + dataFileName));
		FileInputStream propfile = new FileInputStream(new File(dataTablepath+"/commonComponents/" + globalPropFile));
		Properties prop = new Properties();
		prop.load(propfile);


		XSSFWorkbook wb = new XSSFWorkbook(file);
		XSSFSheet sh = wb.getSheet(prop.getProperty("RunConfiguration"));

		//Get number of rows
		int ttlrows = sh.getPhysicalNumberOfRows();
		System.out.println(ttlrows);

		//Get number of columns
		int ttlcol = sh.getRow(0).getPhysicalNumberOfCells();
		System.out.println(ttlcol);

		//Get index value of Test case column and Execute Column
		int tc_Index = 0;
		int flag_Index = 0;

		indexColumn:
			for (int x = 0; x <= ttlcol; x++) {
				if (sh.getRow(0).getCell(x).getStringCellValue().trim().equals("TestCase")) {
					tc_Index = sh.getRow(0).getCell(x).getColumnIndex();
				} else if(sh.getRow(0).getCell(x).getStringCellValue().trim().equals("Execute")) {
					flag_Index = sh.getRow(0).getCell(x).getColumnIndex();
				}

				//Breaks the iteration if the respective columns found
				if (tc_Index>0 && flag_Index>0) {
					break indexColumn;
				}
			}

		//Take flagged test cases
		for (int y = 1; y < ttlrows; y++) {
			String flagYes = sh.getRow(y).getCell(flag_Index).getStringCellValue().trim();
			if (flagYes.equalsIgnoreCase("yes")) {
				String flagTC = sh.getRow(y).getCell(tc_Index).getStringCellValue().trim();
				if (!flagTC.equalsIgnoreCase("ExtractandFillData")) {
					colFlagTC.add(flagTC);
				}

			}
		}
		wb.close();
	}

	public void prerequisite_TestDataSetup() throws IOException, ClassNotFoundException, SQLException, NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException{

		String dataFileName = "C85_Main.xls";
		String dataTablepath = System.getProperty("user.dir");	
		FileInputStream file = new FileInputStream(new File(dataTablepath+"/Datatables/" + dataFileName));
		HSSFWorkbook wb = new HSSFWorkbook(file);
		HSSFSheet sh = wb.getSheet("General_Data");
		//Get number of rows
		int ttlrows = sh.getPhysicalNumberOfRows();
		System.out.println(ttlrows);
		//Get number of columns
		HSSFRow xlRow = sh.getRow(0);
		int ttlcol = xlRow.getLastCellNum();
		System.out.println(ttlcol);
		for (int i = 1; i < ttlrows; i++) {
		//for (int i = 43; i < 44; i++) {
			//Get test case name
			curTCName_Mongo = sh.getRow(i).getCell(0).getStringCellValue().trim();
			/*if (!curTCName_Mongo.equalsIgnoreCase("ExtractandFillData")
					&& !curTCName_Mongo.contains("UIGradCare_link")
					&& !curTCName_Mongo.contains("Future_Effective_Policy")
					&& !curTCName_Mongo.contains("Hyvee_narrow_network")
					&& !curTCName_Mongo.contains("Future_effective_member")
					&& !curTCName_Mongo.contains("Benefits_View Medical Coinsurance")) {*/
				/*** Connect with Mongo - Datatable - START*///
				String subsId = null;
				Mongo mongo = new Mongo(scriptHelper);
				subsIdvl = mongo.validateSubscriberID_FacetsandMongoDB(curTCName_Mongo);
				subsId=subsIdvl[0];
				websecurityuserid=subsIdvl[1];
				putmongoData(curTCName_Mongo, "General_Data", "Username", websecurityuserid);
				putmongoData(curTCName_Mongo, "General_Data", "SSN/SID", subsId);
				System.out.println(i + ". Updated for " + curTCName_Mongo + " with " + websecurityuserid);
				/*** Connect with Mongo - Datatable - END*///
			//}



		}


	}
	
	
	public void navToDed_MaxPage_Med(){
		//Selects Medical tab if not
		if (findElement(MyWellmark_OR.link_Med_Cov)==false) {
			performAction(MyWellmark_OR.link_Med_Cov, "SCROLLANDCLICK", "");
		}
		//Checks for Ded & Maximum option only under Medical tab
		if (findElement(MyWellmark_OR.link_Med_Ded_Max)==true) {
			performAction(MyWellmark_OR.link_Med_Ded_Max, "SCROLLANDCLICK", "");
			waitFor(10, MyWellmark_OR.lbl_DedPage);
			report.updateTestLog("Deductible&Maximum_Medical Page", "Navigated to Deductibles & Maximum page successful", Status.PASS);
		}
	}
	
	public void navToDed_MaxPage_Pharm(){
		//Selects Pharmacy tab if not
		if (findElement(MyWellmark_OR.link_Pharm_Cov)==false) {
			performAction(MyWellmark_OR.link_Pharm_Select, "SCROLLANDCLICK", "");
			
		}
		//Checks for Ded & Maximum option only under Medical tab
		if (findElement(MyWellmark_OR.link_Pharm_Ded_Max)==true) {
			performAction(MyWellmark_OR.link_Pharm_Ded_Max, "SCROLLANDCLICK", "");
			waitFor(10, MyWellmark_OR.lbl_DedPage);
			report.updateTestLog("Deductible&Maximum_Medical Page", "Navigated to Deductibles & Maximum page successful", Status.PASS);
		}
	}
	
	public void navToDed_MaxPage_Den(){
		//Selects Dental tab if not
		if (findElement(MyWellmark_OR.link_Den_Cov)==false) {
			performAction(MyWellmark_OR.link_Den_Select, "SCROLLANDCLICK", "");
			
		}
		//Checks for Ded & Maximum option only under Medical tab
		if (findElement(MyWellmark_OR.link_Den_Ded_Max)==true) {
			performAction(MyWellmark_OR.link_Den_Ded_Max, "SCROLLANDCLICK", "");
			waitFor(10, MyWellmark_OR.lbl_DedPage);
			report.updateTestLog("Deductible&Maximum_Medical Page", "Navigated to Deductibles & Maximum page successful", Status.PASS);
		}
	}
	
	/*public Boolean waitasExplicit(By element, int timeout){
		Boolean state = false;
		WebDriverWait wait = new WebDriverWait(driver, 0);
		
		
		try {
			wait.until(ExpectedConditions.presenceOfElementLocated(element));
			state = true;
		} catch (Exception e) {
			state = false;
		}
		
		return state;
		
	}*/
	

	/*** Aravinth - END ***/

}
