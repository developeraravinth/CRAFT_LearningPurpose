package commonComponents.com.cognizant.framework;

import commonComponents.RestAPI.infrastructure.*;
import commonComponents.RestAPI.infrastructure.Entity.Fields.Field;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import commonComponents.RestAPI.alm.*;

public class TestExecutionStatusUpdate {

	AlmConnector alm;
	RestConnector conn;
	String RUN_ID;
	String TEST_INSTANCE_ID = null;
	String TEST_CONFIG_ID=null;
	String TC_RUN_NAME = "Automation_Run";

	// Framework parameters
	static String TEST_SET_ID= null;
	static String TEST_CASE = null;
	static String TC_RUN_STATUS = null;  
	static String TC_RUN_DURATION = null; 


	public static  void ExecuteinALM(String testcase,String runstatus,String runduration)
//String testsetid, String testcase,String runstatus,String runduration)
	{
		try {
			//TEST_SET_ID = testsetid;
			TEST_CASE = testcase;
			TC_RUN_STATUS = runstatus;
			TC_RUN_DURATION = runduration;

			TestExecutionStatusUpdate tcstatusupdate = new TestExecutionStatusUpdate();
			tcstatusupdate.RestAPIALMdriver();

		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (URISyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	public void loginAlm() throws Exception
	{
		alm = new AlmConnector();
		conn = RestConnector.getInstance();
		conn.init(new HashMap<String, String>(), Constants.HOST,Constants.DOMAIN, Constants.PROJECT);
		alm.login(Constants.USERNAME,Constants.PASSWORD);
	}

	public void testUriEncoding() throws URISyntaxException,MalformedURLException {
		final String add = "";
		URL url = new URL(add);

		URI uri = new URI(url.getProtocol(), url.getHost(), url.getPath(),
				url.getQuery(), null);

		System.out.println(uri.toASCIIString());
	}

	public void RestAPIALMdriver() throws MalformedURLException, URISyntaxException, Exception
	{
		loginAlm();
		// Update Test case status in Test Lab - Execution Grid
		UpdateTestInstanceStatus();
		// Update Test step status in Test Runs
		Update_RunStepStatus();
		//Update Automation Run Name
		Update_RunName(RUN_ID);
		// Update Run Duration
		Update_RunDuration(RUN_ID);

		alm.logout();
		alm = null;
	}

	public String GetTestConfigID() throws Exception,URISyntaxException,MalformedURLException {	

		List<String> strconfigid = null;
		String strConfigIDvalue=null;
		conn.getQCSession();

		HashMap<String, String> str_TEST_ID = Testlab_GetTestCaseDetails();

		TEST_INSTANCE_ID = str_TEST_ID.get(TEST_CASE);

		/*
		 * Get the Test Instance with Test-Set ID & Configuration Test ID .
		 */
		String entitytype = "test-instance";
		String testinstanceURl = conn.buildEntityCollectionUrl(entitytype);
		String testinstanceURLquery = "query=%7Bcycle-id["+TEST_SET_ID+"];id["+TEST_INSTANCE_ID+"]%7D";

		Map<String, String> requestHeaders = new HashMap<String, String>();
		requestHeaders.put("Content-Type", "application/xml");
		requestHeaders.put("Accept", "application/xml");

		Response res = conn.httpGet(testinstanceURl,testinstanceURLquery, requestHeaders);

		// xml -> class instance

		String postedEntityReturnedXml = res.toString();

		String strtoreplace = readstring();
		String strTotalResults = null;		
		String[] tokens = postedEntityReturnedXml.split("<");

		for (String t : tokens)
		{
			if (t.contains("Entities TotalResults"))
			{
				Pattern p = Pattern.compile("\"([^\"]*)\"");
				Matcher m = p.matcher(t);
				while (m.find()) {
					strTotalResults=m.group(1);
					break;
				}
			}
		}
		strtoreplace =strtoreplace.replace("1", strTotalResults);
		postedEntityReturnedXml = postedEntityReturnedXml.replace(strtoreplace, "");
		postedEntityReturnedXml = postedEntityReturnedXml.replace("</Entities>", "");
		postedEntityReturnedXml = postedEntityReturnedXml.replace("<singleElementCollection>false</singleElementCollection>", "");

		Entity entity = EntityMarshallingUtils.marshal(Entity.class,postedEntityReturnedXml);

		//* To print all names available in entity test instance.

		List<Field> fields = entity.getFields().getField();
		for (Field field : fields) 
		{
			if ((field.getName()).equals("test-config-id"))
			{
				strconfigid =field.getValue();
				strConfigIDvalue =strconfigid.get(0);
				break;
			}	
		}
		return strConfigIDvalue;
	}

	public String strTotalResults() throws Exception,URISyntaxException,MalformedURLException
	{

		conn.getQCSession();

		/*
		 * Get the Test Instance with Test-Set ID & Configuration Test ID .
		 */
		String entitytype = "test-instance";
		String testinstanceURl = conn.buildEntityCollectionUrl(entitytype);
		String testinstanceURLquery = "query=%7Bcycle-id["+TEST_SET_ID+"]%7D";


		Map<String, String> requestHeaders = new HashMap<String, String>();
		requestHeaders.put("Content-Type", "application/xml");
		requestHeaders.put("Accept", "application/xml");

		Response res = conn.httpGet(testinstanceURl,testinstanceURLquery, requestHeaders);

		// xml -> class instance

		String postedEntityReturnedXml = res.toString();

		//String strtoreplace = readstring();
		String strTotalResults = null;		
		String[] tokens = postedEntityReturnedXml.split("<");

		for (String t : tokens)
		{
			if (t.contains("Entities TotalResults"))
			{
				Pattern p = Pattern.compile("\"([^\"]*)\"");
				Matcher m = p.matcher(t);
				while (m.find()) {
					strTotalResults=m.group(1);
					break;
				}
			}
		}
		return strTotalResults;
	}

	public HashMap <String, String> Testlab_GetTestCaseDetails() throws Exception,URISyntaxException,MalformedURLException {	

		String strresults = strTotalResults();
		int j = Integer.parseInt(strresults);

		List<String> strtcname = null;
		String strtcnamevalue=null;

		List<String> strmagicID = null;
		String strmagicIDvalue=null;

		HashMap< String, String> strgeekval =  new HashMap<>();

		conn.getQCSession();

		for (int i = 1; i<=j;i++)
		{

			/*
			 * Get the Test Instance with Test-Set ID & Configuration Test ID .
			 */
			String entitytype = "test-instance";
			String testinstanceURl = conn.buildEntityCollectionUrl(entitytype);
			String testinstanceURLquery = "query=%7Bcycle-id["+TEST_SET_ID+"];order-id["+i+"]%7D";


			Map<String, String> requestHeaders = new HashMap<String, String>();
			requestHeaders.put("Content-Type", "application/xml");
			requestHeaders.put("Accept", "application/xml");

			Response res = conn.httpGet(testinstanceURl,testinstanceURLquery, requestHeaders);

			// xml -> class instance

			String postedEntityReturnedXml = res.toString();

			String strtoreplace = readstring();
			String strTotalResults = null;		
			String[] tokens = postedEntityReturnedXml.split("<");

			for (String t : tokens)
			{
				if (t.contains("Entities TotalResults"))
				{
					Pattern p = Pattern.compile("\"([^\"]*)\"");
					Matcher m = p.matcher(t);
					while (m.find()) {
						strTotalResults=m.group(1);
						break;
					}
				}
			}

			strtoreplace =strtoreplace.replace("1", strTotalResults);
			postedEntityReturnedXml = postedEntityReturnedXml.replace(strtoreplace, "");
			postedEntityReturnedXml = postedEntityReturnedXml.replace("</Entities>", "");
			postedEntityReturnedXml = postedEntityReturnedXml.replace("<singleElementCollection>false</singleElementCollection>", "");

			Entity entity = EntityMarshallingUtils.marshal(Entity.class,postedEntityReturnedXml);

			/* * To print all names available in entity test instance.*/

			List<Field> fields = entity.getFields().getField();
			for (Field field : fields) 
			{
				if ((field.getName()).equals("id"))
				{
					strmagicID =field.getValue();
					strmagicIDvalue =strmagicID.get(0);

				}	

				if ((field.getName()).equals("name"))
				{
					strtcname =field.getValue();
					strtcnamevalue =strtcname.get(0);					

					break;
				}	

			}
			strtcnamevalue = strtcnamevalue.replaceAll("\\[.\\]", "");
			strgeekval.put(strtcnamevalue.trim(), strmagicIDvalue.trim());

		}

		return strgeekval;
	}

	public void UpdateTestInstanceStatus() throws Exception 
	{
		TEST_CONFIG_ID = GetTestConfigID();
		System.out.println("Test Instance - ID :"+TEST_INSTANCE_ID);

		// Build an URL to connect to ALM
		String entitytype = "test-instance";
		String testinstanceURl = conn.buildEntityCollectionUrl(entitytype);
		testinstanceURl += "/"+TEST_INSTANCE_ID;

		String newEntityToUpdateUrl = testinstanceURl; 
		/*String newEntityToUpdateUrl =createEntity(testinstanceURl,Constants.entityToPostXml);*/

		String updatedField = "status";
		String updatedFieldInitialUpdateValue = TC_RUN_STATUS;

		String updatedEntityXml =generateSingleFieldUpdateXml(updatedField,updatedFieldInitialUpdateValue);
		update(newEntityToUpdateUrl,updatedEntityXml).toString();
	}

	public String GetRunID() throws Exception,URISyntaxException,MalformedURLException {	
		// To get the Latest Run ID

		List<String> strmagicRunID = null;
		String strmagicRunIDvalue=null;
		conn.getQCSession();


		/*
		 * Get the Test Instance with Test-Set Id & Configuration Test ID .
		 */
		String entitytype = "run";
		String testinstanceURl = conn.buildEntityCollectionUrl(entitytype);
		String testinstanceURLquery = "query=%7Bcycle-id["+TEST_SET_ID+"];test-config-id["+TEST_CONFIG_ID+"]%7D&fields=id,test-id,state,name,status,execution-date,duration,execution-time,cycle-id&page-size=1&order-by=%7Bexecution-date[DESC];execution-time[DESC]%7D";

		Map<String, String> requestHeaders = new HashMap<String, String>();
		requestHeaders.put("Content-Type", "application/xml");
		requestHeaders.put("Accept", "application/xml");

		Response res = conn.httpGet(testinstanceURl,testinstanceURLquery, requestHeaders);

		// xml -> class instance

		String postedEntityReturnedXml = res.toString();

		String strTotalResults = null;		
		String[] tokens = postedEntityReturnedXml.split("<");

		for (String t : tokens)
		{
			if (t.contains("Entities TotalResults"))
			{
				Pattern p = Pattern.compile("\"([^\"]*)\"");
				Matcher m = p.matcher(t);
				while (m.find()) {
					strTotalResults=m.group(1);
					break;
				}
			}
		}
		String strtoreplace = readstring();
		strtoreplace =strtoreplace.replace("1", strTotalResults);

		postedEntityReturnedXml = postedEntityReturnedXml.replace(strtoreplace, "");
		postedEntityReturnedXml = postedEntityReturnedXml.replace("</Entities>", "");
		postedEntityReturnedXml = postedEntityReturnedXml.replace("<singleElementCollection>false</singleElementCollection>", "");

		Entity entity = EntityMarshallingUtils.marshal(Entity.class,postedEntityReturnedXml);

		/* * To print all names available in entity test instance.*/

		List<Field> fields = entity.getFields().getField();
		for (Field field : fields) 
		{
			if ((field.getName()).equals("id"))
			{
				strmagicRunID =field.getValue();
				strmagicRunIDvalue =strmagicRunID.get(0);
				break;
			}			
		}

		return strmagicRunIDvalue;
	}

	public void Update_RunStepStatus() throws Exception,URISyntaxException,MalformedURLException {	

		String  strRunStepID=null;
		conn.getQCSession();

		/*
		 * Get the Test Instance with Test-Set Id & Configuration Test ID .
		 */
		RUN_ID=GetRunID();
		System.out.println("Run-ID :"+RUN_ID);

		// Build an URL to connect to ALM
		String entitytype = "run";
		String testinstanceURl = conn.buildEntityCollectionUrl(entitytype);
		testinstanceURl += "/"+RUN_ID+"/"+"run-steps"+"/";

		Map<String, String> requestHeaders = new HashMap<String, String>();
		requestHeaders.put("Content-Type", "application/xml");
		requestHeaders.put("Accept", "application/xml");

		Response res = conn.httpGet(testinstanceURl,null, requestHeaders);

		// xml -> class instance

		String postedEntityReturnedXml = res.toString();
		String[] tokens = postedEntityReturnedXml.split("<");

		boolean flag=false;

		for (String i : tokens)
		{
			String valueBeforeTheExpectedValue = readstring_remove();
			if(i.equals(valueBeforeTheExpectedValue)){
				flag=true;
				continue;
			} 
			if (flag)
			{ 
				int output = extractInt(i);
				strRunStepID = Integer.toString(output);
				flag=false;
				if(!strRunStepID.equals("0")){
					System.out.println(strRunStepID);
					String newEntityToUpdateUrl = testinstanceURl+strRunStepID;

					String updatedField_runstatus = "status";
					String updatedFieldInitialUpdateValue_runstatus = TC_RUN_STATUS;

					String updatedEntityXml_RunStatus =generateSingleFieldUpdateXml_runstatus(updatedField_runstatus,updatedFieldInitialUpdateValue_runstatus);
					update(newEntityToUpdateUrl,updatedEntityXml_RunStatus).toString();

				}
			}
		}
	}

	public void Update_RunName(String strRunID ) throws Exception,URISyntaxException,MalformedURLException {	

		conn.getQCSession();

		// Build an URL to connect to ALM
		String entitytype = "run";
		String testinstanceURl = conn.buildEntityCollectionUrl(entitytype);
		testinstanceURl += "/"+strRunID;

		Map<String, String> requestHeaders = new HashMap<String, String>();
		requestHeaders.put("Content-Type", "application/xml");
		requestHeaders.put("Accept", "application/xml");

		String updatedField_runName = "name";
		String updatedFieldInitialUpdateValue_runName = TC_RUN_NAME;

		String updatedEntityXml_RunName =generateSingleFieldUpdateXml_runName(updatedField_runName,updatedFieldInitialUpdateValue_runName);
		update(testinstanceURl,updatedEntityXml_RunName).toString();
	}

	public void Update_RunDuration(String strRunID) throws Exception,URISyntaxException,MalformedURLException {	

		conn.getQCSession();

		// Build an URL to connect to ALM
		String entitytype = "run";
		String testinstanceURl = conn.buildEntityCollectionUrl(entitytype);
		testinstanceURl += "/"+strRunID;

		Map<String, String> requestHeaders = new HashMap<String, String>();
		requestHeaders.put("Content-Type", "application/xml");
		requestHeaders.put("Accept", "application/xml");

		String updatedField_duration = "duration";
		String updatedFieldInitialUpdateValue_duration = TC_RUN_DURATION;

		String updatedEntityXml_RunName =generateSingleFieldUpdateXml_runName(updatedField_duration,updatedFieldInitialUpdateValue_duration);
		update(testinstanceURl,updatedEntityXml_RunName).toString();

	}


	public int getRandomNumber(int min, int max) {
		return (int) Math.floor(Math.random() * (max - min + 1)) + min;
	}

	public static int extractInt(String str) {
		Matcher matcher = Pattern.compile("\\d+").matcher(str);

		if (!matcher.find())
			throw new NumberFormatException("For input string [" + str + "]");

		return Integer.parseInt(matcher.group());
	}

	public String createEntity(String collectionUrl, String postedEntityXml)
			throws Exception {

		Map<String, String> requestHeaders = new HashMap<String, String>();
		requestHeaders.put("Content-Type", "application/xml");
		requestHeaders.put("Accept", "application/xml");

		// As can be seen in the implementation below, creating an entity
		//is simply posting its xml into the correct collection.
		Response response = conn.httpPost(collectionUrl,
				postedEntityXml.getBytes(), requestHeaders);

		Exception failure = response.getFailure();
		if (failure != null) {
			throw failure;
		}

		/*
	         Note that we also get the xml of the newly created entity.
	         at the same time we get the url where it was created in a
	         location response header.
		 */
		String entityUrl =response.getResponseHeaders().get("Location").iterator().next();

		return entityUrl;
	}
	/**
	 * @param field
	 *            the field name to update
	 * @param value
	 *            the new value to use
	 * @return an xml that can be used to update an entity's single
	 *          given field to given value
	 */
	private static String generateSingleFieldUpdateXml(String field,String value) {
		return "<Entity Type=\"test-instance\"><Fields>"
				+ Constants.generateFieldXml(field, value)
				+ "</Fields></Entity>";
	}

	private static String generateSingleFieldUpdateXml_runstatus(String field,String value) {
		return "<Entity Type=\"run-step\"><Fields>"
				+ Constants.generateFieldXml(field, value)
				+ "</Fields></Entity>";
	}

	private static String generateSingleFieldUpdateXml_runName(String field,String value) {
		return "<Entity Type=\"run\"><Fields>"
				+ Constants.generateFieldXml(field, value)
				+ "</Fields></Entity>";
	}

	private Response update(String entityUrl, String updatedEntityXml)throws Exception 
	{

		Map<String, String> requestHeaders = new HashMap<String, String>();
		requestHeaders.put("Content-Type", "application/xml");
		requestHeaders.put("Accept", "application/xml");

		Response putResponse =conn.httpPut(entityUrl, updatedEntityXml.getBytes(), requestHeaders);

		if (putResponse.getStatusCode() != HttpURLConnection.HTTP_OK) {
			throw new Exception(putResponse.toString());
		}
		return putResponse;
	}

	public String readstring() throws IOException
	{
		BufferedReader br = null;
		FileReader fr = null;
		String filepath =System.getProperty("user.dir");

		String FILENAME = filepath+"//commonComponents"+"//StringinXml.txt";
		String sCurrentLine = null;

		try {
			fr = new FileReader(FILENAME);
			br = new BufferedReader(fr);

			sCurrentLine = br.readLine();

		} catch (FileNotFoundException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return sCurrentLine;
	}
	public String readstring_remove() throws IOException

	{
		BufferedReader br = null;
		FileReader fr = null;
		String filepath =System.getProperty("user.dir");

		String FILENAME = filepath+"//commonComponents"+"//RemoveString.txt";
		String sCurrentLine = null;

		try {
			fr = new FileReader(FILENAME);
			br = new BufferedReader(fr);

			sCurrentLine = br.readLine();

		} catch (FileNotFoundException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return sCurrentLine;
	}
}
