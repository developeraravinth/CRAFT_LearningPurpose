package commonComponents.com.cognizant.framework;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Properties;

import commonComponents.com.cognizant.framework.selenium.ResultSummaryManager;


public class BackUpFolder {
	
	 private static volatile String reportPathpipeline;
	 private String dateStamp;
	 
	 private static final BackUpFolder BACKUPFOLDER = new BackUpFolder();
	 
	 private BackUpFolder() {
			// To prevent external instantiation of this class
		}

	 public static BackUpFolder getInstance() {
		return BACKUPFOLDER;
	 }
	 public void CreatebackUpFolder() {
	        try {
	            BackUpFolder backUpFolder = new BackUpFolder();
	            Properties properties = Settings.getInstance();
				String dateStamp =
						Util.getCurrentFormattedTime(properties.getProperty("DateFormatString"))
						.replace(" ", "_").replace(":", "-");
								
				
	            FrameworkParameters frameworkParameters =FrameworkParameters.getInstance();

				if(frameworkParameters.getRelativePath() == null) {
					throw new FrameworkException("FrameworkParameters.relativePath is not set!");
				}
				if(frameworkParameters.getRunConfiguration() == null) {
					throw new FrameworkException("FrameworkParameters.runConfiguration is not set!");
				}
				
				reportPathpipeline =
						frameworkParameters.getRelativePath() +
						Util.getFileSeparator() + "Results" +
						//Util.getFileSeparator() + frameworkParameters.getRunConfiguration() + 
						Util.getFileSeparator() + "Pipeline";
				
				boolean reportPathExists = new File(reportPathpipeline).isDirectory();
				if (reportPathExists) {					
					File locFile = new File(reportPathpipeline);
		            File tarFile = new File(reportPathpipeline + dateStamp);
		            backUpFolder.copyDirectory(locFile, tarFile);
		            backUpFolder.deleteFolder(locFile);
				}else{
					new File(reportPathpipeline).mkdirs();
				}
				reportPathExists = new File(reportPathpipeline).isDirectory();
				if (!reportPathExists)
				{
					new File(reportPathpipeline).mkdirs();
				}

				
	        } catch (IOException e) {
				e.printStackTrace();
				throw new FrameworkException(
						"Error while creating backup folder in the results for pipeline");
	        }
	    }

    public void copy(File sourceLocation, File targetLocation) throws IOException {
        if (sourceLocation.isDirectory()) {
            copyDirectory(sourceLocation, targetLocation);
        } else {
            copyFile(sourceLocation, targetLocation);
        }
    }

    private void copyDirectory(File source, File target) throws IOException {
        if (!target.exists()) {
            target.mkdir();
        }
        for (String f : source.list()) {
            copy(new File(source, f), new File(target, f));
        }
    }
       
    public void deleteFolder(File folder) {
        File[] files = folder.listFiles();
        if(files!=null) { //some JVMs return null for empty dirs
            for(File f: files) {
                if(f.isDirectory()) {
                    deleteFolder(f);
                } else {
                    f.delete();
                }
            }
        }
        folder.delete();
    }

    private void copyFile(File source, File target) throws IOException {
        try (
                InputStream in = new FileInputStream(source);
                OutputStream out = new FileOutputStream(target)) {
            byte[] buf = new byte[1024];
            int length;
            while ((length = in.read(buf)) > 0) {
                out.write(buf, 0, length);
            }
        }
    }

   
}