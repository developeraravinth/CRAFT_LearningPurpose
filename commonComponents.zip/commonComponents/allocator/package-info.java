/**
 * Package designed to support batch execution of test cases, as well as execution from HP ALM/QC
 * @author Cognizant
 */
package commonComponents.allocator;