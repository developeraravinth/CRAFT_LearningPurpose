package commonComponents.allocator;

import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.Platform;

import commonComponents.com.cognizant.framework.BackUpFolder;
import commonComponents.com.cognizant.framework.ExcelDataAccessforxlsm;
import commonComponents.com.cognizant.framework.FrameworkParameters;
import commonComponents.com.cognizant.framework.IterationOptions;
import commonComponents.com.cognizant.framework.ReportSettings;
import commonComponents.com.cognizant.framework.Settings;
import commonComponents.com.cognizant.framework.selenium.*;

/**
 * Class to manage the batch execution of test scripts within the framework
 * 
 * @author Cognizant
 */
public class Allocator {
	private FrameworkParameters frameworkParameters = FrameworkParameters
			.getInstance();
	private Properties properties;
	private Properties mobileProperties;
	private ResultSummaryManager resultSummaryManager = ResultSummaryManager
			.getInstance();
	private BackUpFolder backUpFolder=BackUpFolder.getInstance();//Added for Junit report

	/**
	 * The entry point of the test batch execution <br>
	 * Exits with a value of 0 if the test passes and 1 if the test fails
	 * 
	 * @param args
	 *            Command line arguments to the Allocator (Not applicable)
	 */
	public static void main(String[] args) {
		Allocator allocator = new Allocator();
		allocator.driveBatchExecution();
	}

	private void driveBatchExecution() {
		resultSummaryManager.setRelativePath();
		properties = Settings.getInstance();
		mobileProperties = Settings.getMobilePropertiesInstance();
		String runConfiguration;
		if (System.getProperty("RunConfiguration") != null) {
			runConfiguration = System.getProperty("RunConfiguration");
		} else {
			runConfiguration = properties.getProperty("RunConfiguration");
		}
		resultSummaryManager.initializeTestBatch(runConfiguration);
		backUpFolder.CreatebackUpFolder();

		int nThreads = Integer.parseInt(properties
				.getProperty("NumberOfThreads"));
		resultSummaryManager.initializeSummaryReport(nThreads);

		resultSummaryManager.setupErrorLog();

		int testBatchStatus = executeTestBatch(nThreads);

		resultSummaryManager.wrapUp(false);
		resultSummaryManager.launchResultSummary();
		

		System.exit(testBatchStatus);
	}
	/***** When working with SeeTest/Perfecto Parellel  *****/
	/*private int executeTestBatch(int nThreads) {
        List<SeleniumTestParameters> testInstancesToRun = getRunInfo(frameworkParameters
                     .getRunConfiguration());
        ExecutorService parallelExecutor = Executors
                     .newFixedThreadPool(nThreads);
        ParallelRunner testRunner = null;
        int i=0;
  while(i<testInstancesToRun.size())
  {
         System.out.println("I:"+i);
         int size=i+nThreads;
         //System.out.println("First For");
         for(int currentTestInstance=size-nThreads;currentTestInstance<size;currentTestInstance++)
         {
        testRunner = new ParallelRunner(
                     testInstancesToRun.get(currentTestInstance));
          parallelExecutor.execute(testRunner);
         
         if(frameworkParameters.getStopExecution()) {
               break;
         }
         }

  parallelExecutor.shutdown();
  while(!parallelExecutor.isTerminated()) {
               try {
                     Thread.sleep(3000);
               } catch (InterruptedException e) {
                     e.printStackTrace();
               }
        } 
  System.out.println("Waitng for thread to stop");
  i=size;
  }
  if (testRunner == null) {
               return 0; // All tests flagged as "No" in the Run Manager
        } else {
               return testRunner.getTestBatchStatus();
        }
 }*/

	
	private int executeTestBatch(int nThreads) {
		List<SeleniumTestParameters> testInstancesToRun = getRunInfo(frameworkParameters
				.getRunConfiguration());
		ExecutorService parallelExecutor = Executors
				.newFixedThreadPool(nThreads);
		ParallelRunner testRunner = null;

		for (int currentTestInstance = 0; currentTestInstance < testInstancesToRun
				.size(); currentTestInstance++) {
			testRunner = new ParallelRunner(
					testInstancesToRun.get(currentTestInstance));
			parallelExecutor.execute(testRunner);

			if (frameworkParameters.getStopExecution()) {
				break;
			}
		}

		parallelExecutor.shutdown();
		while (!parallelExecutor.isTerminated()) {
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		if (testRunner == null) {
			return 0; // All tests flagged as "No" in the Run Manager
		} else {
			return testRunner.getTestBatchStatus();
		}
	}
	
	
	private List<SeleniumTestParameters> getRunInfo(String sheetName){
		   String[][] testinstances=getvaluefromSheet(frameworkParameters.getRelativePath() + "\\Run Manager.xlsm", sheetName);
		   List<SeleniumTestParameters> testInstancesToRun = new ArrayList<SeleniumTestParameters>();
		   int count=0;
		   int Overallcount=0;
		   String Debugmd="";
		 
		   int ColnumTestCase=0,ColnumTestInstance=0,colnumTestScenario=0,ColnumDescription=0,ColnumIterationMode=0,ColnumStartIteration=0,ColnumEndIteration=0,ColnumExecutionMode=0;
		   int ColnumMobileToolName=0, ColnumMobileExecutionPlatform=0,ColnumMobileOSVersion=0,ColnumDeviceName=0,ColnumBrowser=0,ColnumBrowserVersion=0,ColnumPlatform=0,ColnumSeeTestPort=0,Colnumexecute=0;
		   if (!"".equals(properties.getProperty("DebugMode"))) {
			   Debugmd=properties.getProperty("DebugMode");
		   }else
		   {
			   Debugmd="NO";
		   }
		   for(int intr = 0; intr<testinstances.length; intr++)
	       {
			   for(int intc = 0; intc<testinstances[intr].length; intc++)
	           {
	               
	               if (intr==0) {
					   String Columnheader=testinstances[intr][intc];
					   if (Columnheader!= null){
						   if (Columnheader.equalsIgnoreCase("TestScenario")){
							   colnumTestScenario=intc;}
						   if (Columnheader.equalsIgnoreCase("TestCase")){
							   ColnumTestCase=intc;}
						   if (Columnheader.equalsIgnoreCase("TestInstance")){ColnumTestInstance=intc;}
						   if (Columnheader.equalsIgnoreCase("Execute")){Colnumexecute=intc;}
						   if (Columnheader.equalsIgnoreCase("Description")){ ColnumDescription=intc;}
						   if (Columnheader.equalsIgnoreCase("IterationMode")){ ColnumIterationMode=intc;}
						   if (Columnheader.equalsIgnoreCase("StartIteration")){ ColnumStartIteration=intc;}
						   if (Columnheader.equalsIgnoreCase("EndIteration")){ ColnumEndIteration=intc;}
						   if (Columnheader.equalsIgnoreCase("ExecutionMode")){ ColnumExecutionMode=intc;}
						   if (Columnheader.equalsIgnoreCase("MobileToolName")){ ColnumMobileToolName=intc;}
						   if (Columnheader.equalsIgnoreCase("MobileExecutionPlatform")){ ColnumMobileExecutionPlatform=intc;}
						   if (Columnheader.equalsIgnoreCase("MobileOSVersion")){ ColnumMobileOSVersion=intc;}
						   if (Columnheader.equalsIgnoreCase("DeviceName")){ ColnumDeviceName=intc;}
						   if (Columnheader.equalsIgnoreCase("Browser")){ ColnumBrowser=intc; }
						   if (Columnheader.equalsIgnoreCase("BrowserVersion")){ ColnumBrowserVersion=intc;}
						   if (Columnheader.equalsIgnoreCase("Platform")){ ColnumPlatform=intc;}
						   if (Columnheader.equalsIgnoreCase("SeeTestPort")){ ColnumSeeTestPort=intc;}	
					   }
	               }else
	               {
	            	   String executeFlag = testinstances[intr][Colnumexecute];
	            	   if ("Yes".equalsIgnoreCase(executeFlag)) {
	            		   count++; 
		            	   String currentScenario=testinstances[intr][colnumTestScenario];
		            	   String currentTestcase=testinstances[intr][ColnumTestCase];
		            	   SeleniumTestParameters testParameters = new SeleniumTestParameters(currentScenario, currentTestcase);
		            	   
		            	   testParameters.setCurrentTestInstance("Instance" + testinstances[intr][ColnumTestInstance]);
		            	   testParameters.setCurrentTestDescription(testinstances[intr][ColnumDescription]);
		            	   String iterationMode = testinstances[intr][ColnumIterationMode];
		            	   if (iterationMode!=null) {
			   					testParameters.setIterationMode(IterationOptions
			   							.valueOf(iterationMode));
			   				} else {
			   					testParameters
			   							.setIterationMode(IterationOptions.RUN_ALL_ITERATIONS);
			   				}		            	   
		            	   String startIteration = testinstances[intr][ColnumStartIteration];
			   				if (startIteration!=null) {
			   					testParameters.setStartIteration(Integer
			   							.parseInt(startIteration));
			   				}
			   				String endIteration = testinstances[intr][ColnumEndIteration];
			   				if (endIteration!=null) {
			   					testParameters.setEndIteration(Integer
			   							.parseInt(endIteration));
			   				}
	
			   				String executionMode = testinstances[intr][ColnumExecutionMode];
			   				if (executionMode!=null) {
			   					testParameters.setExecutionMode(ExecutionMode
			   							.valueOf(executionMode));
			   				} else {
			   					testParameters.setExecutionMode(ExecutionMode
			   							.valueOf(properties.getProperty("DefaultExecutionMode")));
			   				}
	
			   				String toolName = testinstances[intr][ColnumMobileToolName];
			   				if (toolName!=null) {
			   					testParameters.setMobileToolName(MobileToolName
			   							.valueOf(toolName));
			   				} else {
			   					testParameters.setMobileToolName(MobileToolName
			   							.valueOf(mobileProperties
			   									.getProperty("DefaultMobileToolName")));
			   				}
	
			   				String executionPlatform = testinstances[intr][ColnumMobileExecutionPlatform];
			   				if (executionPlatform!=null) {
			   					testParameters
			   							.setMobileExecutionPlatform(MobileExecutionPlatform
			   									.valueOf(executionPlatform));
			   				} else {
			   					testParameters
			   							.setMobileExecutionPlatform(MobileExecutionPlatform.valueOf(mobileProperties
			   									.getProperty("DefaultMobileExecutionPlatform")));
			   				}
	
			   				String mobileOSVersion = testinstances[intr][ColnumMobileOSVersion];
			   				if (mobileOSVersion!=null) {
			   					testParameters.setmobileOSVersion(mobileOSVersion);
			   				}
	
			   				String deviceName = testinstances[intr][ColnumDeviceName];
			   				if (deviceName!=null) {
			   					testParameters.setDeviceName(deviceName);
			   				} else {
			   					testParameters.setDeviceName(mobileProperties
			   							.getProperty("DefaultDevice"));
			   				}
	
			   				String browser = testinstances[intr][ColnumBrowser];
			   				if (browser!=null) {
			   					testParameters.setBrowser(Browser.valueOf(browser));
			   				} else {
			   					testParameters.setBrowser(Browser.valueOf(properties
			   							.getProperty("DefaultBrowser")));
			   				}
			   				String browserVersion = testinstances[intr][ColnumBrowserVersion];
			   				if (browserVersion!=null) {
			   					testParameters.setBrowserVersion(browserVersion);
			   				}
			   				String platform = testinstances[intr][ColnumPlatform];
			   				if (platform!=null) {
			   					testParameters.setPlatform(Platform.valueOf(platform));
			   				} else {
			   					testParameters.setPlatform(Platform.valueOf(properties
			   							.getProperty("DefaultPlatform")));
			   				}
			   				String seeTestPort = testinstances[intr][ColnumSeeTestPort];
			   				if (seeTestPort!=null) {
			   					testParameters.setSeeTestPort(seeTestPort);
			   				} else {
			   					testParameters.setSeeTestPort(properties
			                                           .getProperty("SeeTestDefaultPort"));
			   				}
			   				testParameters.setDebugMode(Debugmd);
			   				testInstancesToRun.add(testParameters);
			   				break;
	            	   }
	               }
	           }
	           Overallcount++;
	       }
		   System.out.println("OverallTestCase count:~ " + (Overallcount - 1) + " : Flagged for Execution:~ " + count);
		   System.out.println("RunConfiguration:~ " + properties.getProperty("RunConfiguration"));
		   System.out.println("Environment:~ " + properties.getProperty("Environment"));		   
		   System.out.println("NumberOfThreads:~ " + properties.getProperty("NumberOfThreads"));
		   System.out.println("ConsolidateScreenshotsInWordDoc:~ " + properties.getProperty("ConsolidateScreenshotsInWordDoc"));
		   System.out.println("ConsolidateScreenshotsInPDF:~ " + properties.getProperty("ConsolidateScreenshotsInPDF"));
		   System.out.println("HtmlReport:~ " + properties.getProperty("HtmlReport"));
		   
		   return testInstancesToRun;
	   }
		

	   public static String[][] getvaluefromSheet(String Filepath,String strSheenname) {
	       String[][] value = null;

	       try {
	           FileInputStream inputStream = new FileInputStream(Filepath);
	           XSSFWorkbook workbook = new XSSFWorkbook(inputStream);

	               XSSFSheet sheet = workbook.getSheet(strSheenname);		               

	               // get number of rows from sheet
	               int rows = sheet.getPhysicalNumberOfRows();

	               // get number of cell from row
	               int cells = sheet.getRow(0).getPhysicalNumberOfCells();

	               value = new String[rows][cells];
	               
	               // Get iterator to all the rows in current sheet 
	               Iterator<Row> rowIterator = sheet.iterator(); 		              
	               int rowiter=0;
	               
	               while (rowIterator.hasNext()) { 
	                   Row row = rowIterator.next();
	               // For each row, iterate through each columns 
	                   Iterator<Cell> cellIterator = row.cellIterator(); 
	                   int coliter=0;
	                   while (cellIterator.hasNext()) {
	                       Cell cell = cellIterator.next(); 
	                       switch (cell.getCellType()) { 
	                       case Cell.CELL_TYPE_STRING: 
	                           String cellvalue = cell.getStringCellValue();
	                           value[rowiter][coliter]=cellvalue;
	                           break; 
	                       case Cell.CELL_TYPE_NUMERIC: 
	                           int n = (int) cell.getNumericCellValue();
	                           value[rowiter][coliter]=String.valueOf(n);
	                           break; 
	                       case Cell.CELL_TYPE_BOOLEAN:
	                           boolean b = cell.getBooleanCellValue();
	                           value[rowiter][coliter]=String.valueOf(b);
	                           break; 
	                       		default : 
	                           } 
	                       coliter++;
	                       }
	                   rowiter++;		           	               

	               	}
			    } catch (Exception e) {
			        e.printStackTrace();
			    }
	       
	    return value;
	  }
	/**private List<SeleniumTestParameters> getRunInfo(String sheetName) { //Commented to read the runmanager fast
		ExcelDataAccessforxlsm runManagerAccess = new ExcelDataAccessforxlsm(
				frameworkParameters.getRelativePath(), "Run Manager");
		runManagerAccess.setDatasheetName(sheetName);

		int nTestInstances = runManagerAccess.getLastRowNum();
		List<SeleniumTestParameters> testInstancesToRun = new ArrayList<SeleniumTestParameters>();

		for (int currentTestInstance = 1; currentTestInstance <= nTestInstances; currentTestInstance++) {
			String executeFlag = runManagerAccess.getValue(currentTestInstance,
					"Execute");

			if ("Yes".equalsIgnoreCase(executeFlag)) {
				String currentScenario = runManagerAccess.getValue(
						currentTestInstance, "TestScenario");
				String currentTestcase = runManagerAccess.getValue(
						currentTestInstance, "TestCase");
				SeleniumTestParameters testParameters = new SeleniumTestParameters(
						currentScenario, currentTestcase);

				testParameters.setCurrentTestInstance("Instance"
						+ runManagerAccess.getValue(currentTestInstance,
								"TestInstance"));
				testParameters.setCurrentTestDescription(runManagerAccess
						.getValue(currentTestInstance, "Description"));

				String iterationMode = runManagerAccess.getValue(
						currentTestInstance, "IterationMode");
				if (!"".equals(iterationMode)) {
					testParameters.setIterationMode(IterationOptions
							.valueOf(iterationMode));
				} else {
					testParameters
							.setIterationMode(IterationOptions.RUN_ALL_ITERATIONS);
				}

				String startIteration = runManagerAccess.getValue(
						currentTestInstance, "StartIteration");
				if (!"".equals(startIteration)) {
					testParameters.setStartIteration(Integer
							.parseInt(startIteration));
				}
				String endIteration = runManagerAccess.getValue(
						currentTestInstance, "EndIteration");
				if (!"".equals(endIteration)) {
					testParameters.setEndIteration(Integer
							.parseInt(endIteration));
				}

				String executionMode = runManagerAccess.getValue(
						currentTestInstance, "ExecutionMode");
				if (!"".equals(executionMode)) {
					testParameters.setExecutionMode(ExecutionMode
							.valueOf(executionMode));
				} else {
					testParameters.setExecutionMode(ExecutionMode
							.valueOf(properties
									.getProperty("DefaultExecutionMode")));
				}

				String toolName = runManagerAccess.getValue(
						currentTestInstance, "MobileToolName");
				if (!"".equals(toolName)) {
					testParameters.setMobileToolName(MobileToolName
							.valueOf(toolName));
				} else {
					testParameters.setMobileToolName(MobileToolName
							.valueOf(mobileProperties
									.getProperty("DefaultMobileToolName")));
				}

				String executionPlatform = runManagerAccess.getValue(
						currentTestInstance, "MobileExecutionPlatform");
				if (!"".equals(executionPlatform)) {
					testParameters
							.setMobileExecutionPlatform(MobileExecutionPlatform
									.valueOf(executionPlatform));
				} else {
					testParameters
							.setMobileExecutionPlatform(MobileExecutionPlatform.valueOf(mobileProperties
									.getProperty("DefaultMobileExecutionPlatform")));
				}

				String mobileOSVersion = runManagerAccess.getValue(
						currentTestInstance, "MobileOSVersion");
				if (!"".equals(mobileOSVersion)) {
					testParameters.setmobileOSVersion(mobileOSVersion);
				}

				String deviceName = runManagerAccess.getValue(
						currentTestInstance, "DeviceName");
				if (!"".equals(deviceName)) {
					testParameters.setDeviceName(deviceName);
				} else {
					testParameters.setDeviceName(mobileProperties
							.getProperty("DefaultDevice"));
				}

				String browser = runManagerAccess.getValue(currentTestInstance,
						"Browser");
				if (!"".equals(browser)) {
					testParameters.setBrowser(Browser.valueOf(browser));
				} else {
					testParameters.setBrowser(Browser.valueOf(properties
							.getProperty("DefaultBrowser")));
				}
				String browserVersion = runManagerAccess.getValue(
						currentTestInstance, "BrowserVersion");
				if (!"".equals(browserVersion)) {
					testParameters.setBrowserVersion(browserVersion);
				}
				String platform = runManagerAccess.getValue(
						currentTestInstance, "Platform");
				if (!"".equals(platform)) {
					testParameters.setPlatform(Platform.valueOf(platform));
				} else {
					testParameters.setPlatform(Platform.valueOf(properties
							.getProperty("DefaultPlatform")));
				}
				String seeTestPort = runManagerAccess.getValue(
                        currentTestInstance, "SeeTestPort");
				if (!"".equals(seeTestPort)) {
					testParameters.setSeeTestPort(seeTestPort);
				} else {
					testParameters.setSeeTestPort(properties
                                        .getProperty("SeeTestDefaultPort"));
				}
				
				if (!"".equals(properties.getProperty("DebugMode"))) {
					testParameters.setDebugMode(properties
							.getProperty("DebugMode"));
				} else {
					testParameters.setDebugMode("NO");
				}
				
				testInstancesToRun.add(testParameters);
			}
		}

		return testInstancesToRun;
	}**/
}